# CLAUDE.md

Guidance for Claude Code working in this repo. Read this first — it maps the codebase so you can jump straight to the right file instead of searching.

## What this is

StorySchool — an AI-powered educational web app that explains CBSE topics (Grades 5–10) as comedy stories, narrated by "Professor Giggles," with a recurring tutor "Finn the Fox." Stories stream live; quizzes/flashcards/mind maps/adventures/puzzles are AI-generated. FastAPI backend + a single vanilla-JS template + SQLite cache. Two AI providers (OpenAI, Anthropic) behind one abstraction, switchable at runtime.

## Commands

```bash
pytest tests/ -v
```
Run the app locally (needs one provider key set — see below):
```bash
python main.py
```
Serves on `http://127.0.0.1:8000`. Docker: `docker compose up --build`.

Set at least one key before running or importing `main`:
- PowerShell: `$env:OPENAI_API_KEY="..."` (or `$env:ANTHROPIC_API_KEY="..."` + `$env:AI_PROVIDER="anthropic"`)
- bash: `OPENAI_API_KEY=... python main.py`

CI (`.github/workflows/ci.yml`): Python 3.12, `pip install -r requirements.txt`, `pytest tests/ -v` on push to `main`/`feature/**` and PRs to `main`.

## Architecture (the mental model)

```
Browser (templates/index.html, one file)
   │  REST + SSE (EventSource)
FastAPI (main.py)  ──►  SQLite cache (storyschool_cache.db)
   │  complete_json / complete_text / stream_text  (tier = "story" | "fast")
ai_config.py  ──►  openai_provider.py  |  anthropic_provider.py
```

- **`main.py`** (~4850 lines) owns: DB schema + cache helpers, all prompt builders, and every FastAPI route. This is where routes and prompts live.
- **`ai_config.py`** is the SDK-agnostic AI orchestration layer: model/provider selection, all structured-output JSON `SCHEMAS`, and the public `complete_json` / `complete_text` / `stream_text` helpers.
- **`openai_provider.py`** / **`anthropic_provider.py`** each wrap exactly one vendor SDK. **Never import both SDKs in one file** — that separation is deliberate; keep vendor calls inside these two modules only.
- **Feature modules** (`gamification.py`, `spaced_rep.py`, etc.) are mostly stateless logic/catalog helpers. They define behavior; `main.py` wires them to routes and persistence.

## Calling the AI (do it this way)

All LLM calls go through `ai_config.py` tier helpers — never touch a provider SDK from `main.py` or feature modules:

```python
from ai_config import complete_json, complete_text, stream_text

data = complete_json("fast", "quiz", instructions, input_messages)      # structured JSON
text = complete_text("story", instructions, input_messages)              # blocking text
async for etype, payload in stream_text("story", instructions, msgs):    # SSE streaming
    # etype ∈ {"token", "thinking", "completed", "error"}
```

- **Tier** is `"story"` (creative, streamed — `MODEL_STORY`) or `"fast"` (structured JSON + chat — `MODEL_FAST`). The tier resolves to a concrete model for the active provider; call sites never name a model.
- `input_messages` is `[{"role": "...", "content": "<str>"}]`; `instructions` becomes OpenAI `instructions` / Anthropic `system`. No per-provider message reshaping needed.
- **To add a new structured output:** add a JSON schema to `SCHEMAS` in `ai_config.py` (must use `required` + `additionalProperties: False` for OpenAI strict mode), then call `complete_json(tier, "<schema_name>", ...)`. Mixed-type schemas (e.g. `subject_gate`, `question_set`) satisfy strict mode by including every field in `required` and using sentinels — empty `options`/`keywords` arrays and `correct_index: -1` for non-MCQ items.
- Provider/model selection is **process-global and in-memory** (seeded from env, changed via `update_settings()` / the `⚙️ AI` UI / `POST /api/ai/settings`, resets on restart). Not per-request.

Env vars: `AI_PROVIDER` (default `openai`), `OPENAI_MODEL_STORY`/`_FAST` (`gpt-4o`/`gpt-4o-mini`), `ANTHROPIC_MODEL_STORY`/`_FAST` (`claude-sonnet-5`/`claude-haiku-4-5`), plus `ANTHROPIC_MAX_TOKENS_TEXT|JSON|STREAM` and `OPENAI_REASONING`/`ANTHROPIC_REASONING`. `validate_active_provider()` runs at import: it falls back to any keyed provider and raises only if none is set.

## Where things live

### `main.py` layout
| Lines (approx) | Contents |
|---|---|
| 1–234 | Imports (stdlib, FastAPI, feature modules, `ai_config` helpers), logging, `app = FastAPI(...)` + `Jinja2Templates` (lines 228–229) |
| 235–460 | SQLite schema (`CACHE_DB`, all `CREATE TABLE`s) + `get_cached_*` / `store_cached_*` helpers |
| ~460–2030 | Prompt builders & business logic (story/adventure/story-world prompts, `_build_story_user_message`, `_build_doc_story_user_message`, `QUESTION_SET_PROMPT`, `own_words_prompt`, etc.) |
| 2033–4844 | All FastAPI routes |

### Key routes (grep `@app.` for the full list)
| Path | Line | Notes |
|---|---|---|
| `GET /api/ai/models` | 2427 | Resolved tier routing + active `provider` |
| `GET`/`POST /api/ai/settings` | 2455 / 2467 | Read/set provider + tier models; 400 on unconfigured provider or empty model |
| `GET /api/explain/stream` | 4077 | SSE story stream (`thinking`/`token`/`done`) |
| `POST /api/explain` | 4170 | Non-streaming story (cache-backed) |
| `POST /api/document/generate` | 4225 | Multipart upload → story or `question_set` from the uploaded chapter/bank; user picks `action`; text extracted via `document_ingest`; **not cached** |
| `POST /api/flashcards` `POST /api/mindmap` `POST /api/quiz` | 4324 / 4363 / 4406 | `complete_json` "fast" tier |
| `POST /api/adventure/stream` | 4670 | SSE CYOA chapter (`token`/`chapter`/`done`) |
| `POST /api/story-world/start` | 3633 | Generates the interactive Story World (`story_world` schema — largest) |
| `POST /api/ask-doubt` `/stream` | 4789 / 4750 | Doubt chat (blocking / SSE) |
| `GET`/`POST /api/subject-gate/*` | 2982+ | Optional checkpoint exams (offered after every 3 topics, 80% to clear; topics are **not** locked) |
| `GET`/`POST /api/spaced/*` | 2824+ | Spaced repetition (1/3/7/14-day) |

### Feature modules (open the one matching the feature)
| Module | Responsibility |
|---|---|
| `syllabus.py` | CBSE syllabus (Grades 5–10), genres, languages |
| `ncert.py` | Topic → NCERT chapter + PDF link |
| `study_videos.py` | Curated YouTube study links |
| `child_profile.py` / `interest_engine.py` | Learner profile + preference model (personalizes AI) |
| `story_world.py` / `story_challenges.py` | Story World engine: scenes, embedded challenges, answer checking |
| `choices_consequences.py` / `reflection_system.py` | Branching choices + metacognition prompts |
| `child_story_creator.py` / `know_more.py` | Child-authored stories; curiosity follow-ups |
| `spaced_rep.py` / `subject_gate.py` | Review scheduling; optional subject checkpoints (`topic_is_unlocked()` always True — locks removed; the checkpoint is a non-gating bonus) |
| `gamification.py` / `companion.py` / `hint_system.py` | XP/ranks/badges; companion unlocks; 5-level hints |
| `adaptive_learning.py` / `mistake_learning.py` / `assessment_engine.py` | Difficulty adaptation; error→practice; hidden assessment |
| `multimodal_learning.py` / `accessibility.py` / `emotional_engagement.py` | Learning modes; a11y prefs; engagement hooks |
| `parent_controls.py` / `parent_dashboard.py` | Guardrails; parent insights |
| `tutor_character.py` / `project_adventures.py` | Finn the Fox (Socratic tutor); multi-day project quests |
| `document_ingest.py` | Server-side text extraction for uploads (`.pdf` via `pypdf`, `.docx` via `python-docx`, `.txt` stdlib); `ALLOWED_EXTS`, `MAX_UPLOAD_BYTES`, `MAX_CHARS`, `extract_text()` / `clean_text()`. Pure/offline. Feeds `POST /api/document/generate` |

### Frontend
`templates/index.html` — single Jinja2 template (~10,700 lines) with inline CSS + JS, no build step. Libraries via CDN (marked.js, Mermaid 11). The `⚙️ AI` top-bar button drives the provider/model picker. Panels follow the `toggle*Panel()` / `closeOtherPanels()` pattern; server state loads via `fetch` on open.

## Data & persistence

Everything persists in **`storyschool_cache.db`** (SQLite, at the repo root; volume-mounted in Docker). Tables: `story_cache`, `flashcard_cache`, `mindmap_cache`, `quiz_cache`, `quiz_mastery`, `learning_progress`, `learner_profile`, `child_profile`, `spaced_items`, `subject_gate_results`, `subject_gate_exams`, `story_world_sessions`. Per-learner state is keyed by a `learner_id` (query param or body). No migrations framework — tables are `CREATE TABLE IF NOT EXISTS` at startup in `main.py`. **Document-upload outputs (`/api/document/generate`) are intentionally NOT cached** — each upload is ad-hoc and the story/quiz cache keys don't encode document identity, so caching would poison normal results.

## Conventions & gotchas

- **SDK isolation:** OpenAI and Anthropic SDKs must never appear in the same file. Only `openai_provider.py` and `anthropic_provider.py` import vendor SDKs.
- **`tests/conftest.py`** seeds a fake `OPENAI_API_KEY` before any test imports `main` (which validates a key at import). `setdefault` never overrides a real key. Tests monkeypatch `main.complete_json` etc. — keep those names stable.
- **`Dockerfile` uses `COPY *.py ./`** on purpose: `main` imports ~36 sibling modules. Adding a new top-level module needs no Dockerfile change, but a module in a subfolder would.
- **Frontend Jinja2 pitfall:** JS containing `{{`/`{%` must be inside `{% raw %}`/escaped, or Jinja will try to parse it (see git history).
- **Streaming contract:** providers yield `("token"|"thinking"|"completed"|"error", payload)`; SSE routes translate these to `thinking`/`token`/`done` (+ `chapter` for adventure) events. Cache-hit paths bypass the LLM entirely — don't break them when editing stream routes.
- Platform is **Windows**; the shell is Git Bash. Prefer forward slashes and `$VAR`.

## Verifying changes

`pytest tests/ -v` (183+ tests, all offline — no live API calls; provider switching to an unkeyed provider is expected to 400). For a real generation check, run with a key set and exercise the relevant route (story stream, quiz JSON, doubt, adventure, document upload).
