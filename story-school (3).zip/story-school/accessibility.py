"""Accessibility preferences — foundation for inclusive learning."""

from __future__ import annotations

import copy
from typing import Any, Optional

FONT_FAMILIES: dict[str, dict[str, str]] = {
    "default": {
        "name": "Default",
        "emoji": "🔤",
        "body": "'Nunito', sans-serif",
        "heading": "'Fredoka One', cursive",
    },
    "dyslexia": {
        "name": "Dyslexia-friendly",
        "emoji": "📖",
        "body": "'OpenDyslexic', 'Comic Sans MS', 'Trebuchet MS', Verdana, sans-serif",
        "heading": "'OpenDyslexic', 'Comic Sans MS', 'Trebuchet MS', Verdana, sans-serif",
    },
    "sans_large": {
        "name": "Large sans",
        "emoji": "🔠",
        "body": "Verdana, 'Trebuchet MS', 'Segoe UI', sans-serif",
        "heading": "Verdana, 'Trebuchet MS', 'Segoe UI', sans-serif",
    },
    "serif_readable": {
        "name": "Readable serif",
        "emoji": "📰",
        "body": "Georgia, 'Times New Roman', serif",
        "heading": "Georgia, 'Times New Roman', serif",
    },
}

TEXT_SIZE_SCALES: list[dict[str, Any]] = [
    {"scale": 0.85, "label": "85%"},
    {"scale": 1.0, "label": "100%"},
    {"scale": 1.15, "label": "115%"},
    {"scale": 1.3, "label": "130%"},
    {"scale": 1.5, "label": "150%"},
]

SUPPORTED_LANGUAGES = (
    "english", "hindi", "kannada", "sanskrit",
)

UI_THEME_IDS = (
    "default", "ocean", "forest", "sunset", "midnight", "candy", "aurora", "sand",
)

UI_THEMES: list[dict[str, str]] = [
    {"id": "default", "name": "StorySchool Purple", "emoji": "🎓", "preview": "linear-gradient(135deg,#667eea,#764ba2)"},
    {"id": "ocean", "name": "Ocean Breeze", "emoji": "🌊", "preview": "linear-gradient(135deg,#0ea5e9,#0369a1)"},
    {"id": "forest", "name": "Forest Grove", "emoji": "🌲", "preview": "linear-gradient(135deg,#22c55e,#15803d)"},
    {"id": "sunset", "name": "Sunset Glow", "emoji": "🌅", "preview": "linear-gradient(135deg,#fb923c,#db2777)"},
    {"id": "midnight", "name": "Midnight Sky", "emoji": "🌙", "preview": "linear-gradient(135deg,#0f172a,#312e81)"},
    {"id": "candy", "name": "Candy Pop", "emoji": "🍬", "preview": "linear-gradient(135deg,#f472b6,#ec4899)"},
    {"id": "aurora", "name": "Northern Lights", "emoji": "✨", "preview": "linear-gradient(135deg,#2dd4bf,#7c3aed)"},
    {"id": "sand", "name": "Warm Sand", "emoji": "🏜️", "preview": "linear-gradient(135deg,#fbbf24,#d97706)"},
]


def default_accessibility_preferences() -> dict:
    return {
        "font_family": "default",
        "text_size_scale": 1.0,
        "high_contrast": False,
        "reduced_motion": False,
        "dyslexia_friendly": False,
        "extra_line_spacing": False,
        "extra_letter_spacing": False,
        "audio_narration": True,
        "captions_enabled": True,
        "keyboard_navigation": True,
        "screen_reader_enhanced": True,
        "color_independent_ui": True,
        "reading_assistance": False,
        "reading_line_highlight": False,
        "simplified_language": False,
        "difficulty_assistance": False,
        "focus_visible_always": True,
        "preferred_content_language": None,
        "respect_system_reduced_motion": True,
        "ui_theme": "default",
    }


def _nearest_scale(value: float) -> float:
    scales = [s["scale"] for s in TEXT_SIZE_SCALES]
    return min(scales, key=lambda s: abs(s - value))


def normalize_accessibility_preferences(data: Optional[dict]) -> dict:
    base = default_accessibility_preferences()
    if not data:
        return base

    font = str(data.get("font_family") or "default").strip().lower()
    base["font_family"] = font if font in FONT_FAMILIES else "default"

    try:
        scale = float(data.get("text_size_scale", 1.0))
        base["text_size_scale"] = _nearest_scale(scale)
    except (TypeError, ValueError):
        pass

    for key in (
        "high_contrast",
        "reduced_motion",
        "dyslexia_friendly",
        "extra_line_spacing",
        "extra_letter_spacing",
        "audio_narration",
        "captions_enabled",
        "keyboard_navigation",
        "screen_reader_enhanced",
        "color_independent_ui",
        "reading_assistance",
        "reading_line_highlight",
        "simplified_language",
        "difficulty_assistance",
        "focus_visible_always",
        "respect_system_reduced_motion",
    ):
        if key in data:
            base[key] = bool(data[key])

    # Legacy migration from old bar toggles
    if data.get("fontScale"):
        try:
            base["text_size_scale"] = _nearest_scale(float(data["fontScale"]))
        except (TypeError, ValueError):
            pass
    if data.get("highContrast"):
        base["high_contrast"] = True
    if data.get("dyslexia"):
        base["dyslexia_friendly"] = True
        if base["font_family"] == "default":
            base["font_family"] = "dyslexia"

    lang = data.get("preferred_content_language")
    if lang is None or lang == "":
        base["preferred_content_language"] = None
    else:
        lang_key = str(lang).strip().lower()
        base["preferred_content_language"] = (
            lang_key if lang_key in SUPPORTED_LANGUAGES else None
        )

    if base["dyslexia_friendly"] and base["font_family"] == "default":
        base["font_family"] = "dyslexia"
        base["extra_line_spacing"] = True
        base["extra_letter_spacing"] = True

    theme = str(data.get("ui_theme") or "default").strip().lower()
    base["ui_theme"] = theme if theme in UI_THEME_IDS else "default"

    return base


def accessibility_catalog() -> dict:
    return {
        "font_families": {
            k: {"name": v["name"], "emoji": v["emoji"]}
            for k, v in FONT_FAMILIES.items()
        },
        "text_sizes": TEXT_SIZE_SCALES,
        "languages": list(SUPPORTED_LANGUAGES),
        "ui_themes": UI_THEMES,
        "defaults": default_accessibility_preferences(),
        "features": [
            {"id": "font_family", "label": "Adjustable font"},
            {"id": "text_size_scale", "label": "Adjustable text size"},
            {"id": "high_contrast", "label": "High contrast"},
            {"id": "reduced_motion", "label": "Reduced animation"},
            {"id": "dyslexia_friendly", "label": "Dyslexia-friendly options"},
            {"id": "audio_narration", "label": "Audio narration"},
            {"id": "captions_enabled", "label": "Captions"},
            {"id": "keyboard_navigation", "label": "Keyboard navigation"},
            {"id": "screen_reader_enhanced", "label": "Screen-reader support"},
            {"id": "color_independent_ui", "label": "Color-independent information"},
            {"id": "reading_assistance", "label": "Reading assistance"},
            {"id": "difficulty_assistance", "label": "Adjustable difficulty support"},
            {"id": "preferred_content_language", "label": "Language support"},
            {"id": "ui_theme", "label": "Color theme"},
        ],
    }


def accessibility_prompt_block(prefs: Optional[dict]) -> str:
    """AI instructions when reading or language assistance is enabled."""
    p = normalize_accessibility_preferences(prefs)
    lines = []
    if p.get("simplified_language") or p.get("reading_assistance"):
        lines.append(
            "ACCESSIBILITY — READING: Use short sentences, plain vocabulary, "
            "and recap each idea. Avoid idioms and dense paragraphs."
        )
    if p.get("difficulty_assistance"):
        lines.append(
            "ACCESSIBILITY — DIFFICULTY: Scaffold gently; one new concept at a time "
            "with a concrete example before abstract terms."
        )
    if p.get("preferred_content_language") and p["preferred_content_language"] != "english":
        lines.append(
            f"ACCESSIBILITY — LANGUAGE: Prefer clear {p['preferred_content_language']} "
            "where the lesson language allows; keep key terms explained."
        )
    if not lines:
        return ""
    return "\n".join(lines) + "\n"


def effective_content_language(
    prefs: Optional[dict],
    child_language: Optional[str] = None,
    selected_language: Optional[str] = None,
) -> str:
    p = normalize_accessibility_preferences(prefs)
    if p.get("preferred_content_language"):
        return p["preferred_content_language"]
    if selected_language:
        return selected_language
    if child_language:
        return child_language
    return "english"


def css_variables_for_prefs(prefs: Optional[dict]) -> dict[str, str]:
    """CSS custom properties for the client."""
    p = normalize_accessibility_preferences(prefs)
    font = FONT_FAMILIES.get(p["font_family"], FONT_FAMILIES["default"])
    vars_out = {
        "--base-font-scale": str(p["text_size_scale"]),
        "--body-font": font["body"],
        "--heading-font": font["heading"],
    }
    if p.get("extra_line_spacing"):
        vars_out["--a11y-line-height"] = "1.85"
    else:
        vars_out["--a11y-line-height"] = "1.6"
    if p.get("extra_letter_spacing"):
        vars_out["--a11y-letter-spacing"] = "0.04em"
        vars_out["--a11y-word-spacing"] = "0.06em"
    else:
        vars_out["--a11y-letter-spacing"] = "0"
        vars_out["--a11y-word-spacing"] = "0"
    return vars_out


def body_classes_for_prefs(prefs: Optional[dict]) -> list[str]:
    p = normalize_accessibility_preferences(prefs)
    classes = []
    if p.get("high_contrast"):
        classes.append("high-contrast")
    if p.get("dyslexia_friendly") or p.get("font_family") == "dyslexia":
        classes.append("dyslexia-friendly")
    if p.get("reduced_motion"):
        classes.append("reduced-motion")
    if p.get("color_independent_ui"):
        classes.append("a11y-color-safe")
    if p.get("reading_line_highlight"):
        classes.append("a11y-reading-highlight")
    if p.get("reading_assistance"):
        classes.append("a11y-reading-assist")
    if p.get("focus_visible_always"):
        classes.append("a11y-focus-visible")
    if p.get("screen_reader_enhanced"):
        classes.append("a11y-sr-enhanced")
    theme = p.get("ui_theme") or "default"
    if theme != "default" and theme in UI_THEME_IDS:
        classes.append(f"ui-theme-{theme}")
    if theme == "midnight":
        classes.append("ui-theme-dark")
    return classes
