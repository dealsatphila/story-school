"""Phase 2 — adaptive difficulty from learner signals."""

from __future__ import annotations

import json
import re
import time
from typing import Any, Optional

from syllabus import DIFFICULTY_LEVELS

DIFFICULTY_ORDER = ("easy", "medium", "hard")
CHALLENGE_TIERS = (1, 2, 3, 4, 5)

CHALLENGE_TIER_GUIDANCE: dict[int, str] = {
    1: (
        "Tier 1 — very gentle: tiny whole numbers (under 5), visual groups "
        "(e.g. '3 groups of 2 stars'), count-together language, no jargon."
    ),
    2: (
        "Tier 2 — easy practice: simple one-step facts like 3×4 or 2×5, "
        "still concrete and visual when possible."
    ),
    3: (
        "Tier 3 — grade-typical: problems like 10×4 or 6×7, standard for this grade."
    ),
    4: (
        "Tier 4 — stretch: harder like 12×8, may combine two operations in the story."
    ),
    5: (
        "Tier 5 — challenge: word problems, multi-step like 24×15, real-world context."
    ),
}

MASTERY_LABELS = [
    (0.0, "Getting started"),
    (0.35, "Building skills"),
    (0.55, "Growing confident"),
    (0.75, "Strong grasp"),
    (0.9, "Mastered"),
]


def concept_key(grade: int, subject: str, topic: str, concept_tag: str = "general") -> str:
    return f"{grade}|{subject}|{topic}|{concept_tag}"


def infer_concept_tag(subject: str, topic: str) -> str:
    subj = (subject or "").lower()
    text = f"{subject} {topic}".lower()
    if "math" in subj or "mathematics" in subj:
        if any(w in text for w in ("multiply", "multiplication", "times", "product", "×")):
            return "multiplication"
        if any(w in text for w in ("fraction", "numerator", "denominator")):
            return "fractions"
        if any(w in text for w in ("divide", "division")):
            return "division"
        if any(w in text for w in ("add", "addition", "sum")):
            return "addition"
        if any(w in text for w in ("subtract", "subtraction", "difference")):
            return "subtraction"
        if any(w in text for w in ("percent", "percentage")):
            return "percentages"
        if any(w in text for w in ("geometry", "angle", "triangle", "area")):
            return "geometry"
    if "science" in subj:
        if any(w in text for w in ("force", "motion", "energy")):
            return "forces"
        if any(w in text for w in ("plant", "animal", "living")):
            return "classification"
    if any(w in subj for w in ("english", "language", "hindi")):
        if any(w in text for w in ("grammar", "verb", "noun")):
            return "grammar"
        if any(w in text for w in ("spell", "vocabulary")):
            return "vocabulary"
    return "general"


def default_concept_state(
    grade: int,
    subject: str,
    topic: str,
    concept_tag: str = "general",
) -> dict:
    return {
        "concept_key": concept_key(grade, subject, topic, concept_tag),
        "grade": grade,
        "subject": subject,
        "topic": topic,
        "concept_tag": concept_tag,
        "difficulty": "medium",
        "challenge_tier": 3,
        "mastery_score": 0.0,
        "total_attempts": 0,
        "correct_count": 0,
        "hint_count": 0,
        "avg_response_ms": 0.0,
        "recent_misses": 0,
        "success_streak": 0,
        "engagement_score": 0.5,
        "missed_concepts": [],
        "updated_at": time.time(),
    }


def mastery_label(score: float) -> str:
    label = MASTERY_LABELS[0][1]
    for threshold, name in MASTERY_LABELS:
        if score >= threshold:
            label = name
    return label


def _clamp_tier(tier: int) -> int:
    return max(CHALLENGE_TIERS[0], min(CHALLENGE_TIERS[-1], int(tier)))


def _shift_difficulty(current: str, delta: int) -> str:
    idx = DIFFICULTY_ORDER.index(current) if current in DIFFICULTY_ORDER else 1
    idx = max(0, min(len(DIFFICULTY_ORDER) - 1, idx + delta))
    return DIFFICULTY_ORDER[idx]


def apply_event(state: dict, event: dict) -> dict:
    """Update concept state from one learning signal."""
    st = dict(state)
    correct = bool(event.get("correct"))
    hints = int(event.get("hints") or 0)
    attempts = max(1, int(event.get("attempts") or 1))
    response_ms = int(event.get("response_ms") or 0)
    engagement = (event.get("engagement") or "").strip().lower()

    st["total_attempts"] = st.get("total_attempts", 0) + 1
    if correct:
        st["correct_count"] = st.get("correct_count", 0) + 1
        st["success_streak"] = st.get("success_streak", 0) + 1
        st["recent_misses"] = 0
    else:
        st["success_streak"] = 0
        st["recent_misses"] = st.get("recent_misses", 0) + 1
        tag = event.get("concept_tag") or st.get("concept_tag", "general")
        missed = list(st.get("missed_concepts") or [])
        if tag not in missed:
            missed.append(tag)
        st["missed_concepts"] = missed[-5:]

    st["hint_count"] = st.get("hint_count", 0) + hints

    if response_ms > 0:
        n = st["total_attempts"]
        prev = st.get("avg_response_ms") or 0
        st["avg_response_ms"] = prev + (response_ms - prev) / n

    if engagement == "completed":
        st["engagement_score"] = min(1.0, st.get("engagement_score", 0.5) + 0.05)
    elif engagement in ("skip", "abandon"):
        st["engagement_score"] = max(0.0, st.get("engagement_score", 0.5) - 0.08)

    total = st["total_attempts"]
    st["mastery_score"] = st["correct_count"] / total if total else 0.0

    tier = st.get("challenge_tier", 3)
    diff = st.get("difficulty", "medium")

    struggling = (
        not correct
        or hints > 0
        or attempts > 1
        or st["recent_misses"] >= 2
        or (response_ms > 45000 and not correct)
    )
    excelling = (
        correct
        and hints == 0
        and attempts == 1
        and st["success_streak"] >= 3
        and st["mastery_score"] >= 0.75
    )

    if struggling:
        tier = _clamp_tier(tier - 1)
        diff = _shift_difficulty(diff, -1)
    elif excelling:
        tier = _clamp_tier(tier + 1)
        if st["success_streak"] >= 5:
            diff = _shift_difficulty(diff, 1)

    st["challenge_tier"] = tier
    st["difficulty"] = diff
    st["struggling"] = struggling and st["recent_misses"] >= 1
    st["excelling"] = excelling
    st["updated_at"] = time.time()
    return st


def recommend_difficulty(state: Optional[dict], fallback: str = "medium") -> str:
    if not state:
        return normalize_difficulty(fallback)
    d = state.get("difficulty") or fallback
    return d if d in DIFFICULTY_LEVELS else "medium"


def status_message(state: dict) -> str:
    tag = state.get("concept_tag", "general")
    label = mastery_label(state.get("mastery_score", 0))
    tier = state.get("challenge_tier", 3)
    if state.get("struggling"):
        if tag == "multiplication":
            return "🎯 Practice tuned for you — we'll use smaller numbers and visual groups first."
        return f"🎯 Taking it step by step — {label.lower()} on {state.get('topic', 'this topic')}."
    if state.get("excelling"):
        return f"🚀 You're on a roll! Bigger challenges and word problems ahead."
    return f"⭐ {label} — Explorer path at tier {tier}."


def adaptive_prompt_block(state: Optional[dict]) -> str:
    if not state:
        return ""
    lines = [
        "ADAPTIVE PERSONALIZATION (follow strictly — this learner's live profile):",
        f"- Mastery: {mastery_label(state.get('mastery_score', 0))} "
        f"({int(state.get('mastery_score', 0) * 100)}% recent accuracy).",
        f"- Use difficulty: {state.get('difficulty', 'medium').upper()}.",
    ]
    tier = state.get("challenge_tier", 3)
    lines.append(f"- Challenge tier {tier}: {CHALLENGE_TIER_GUIDANCE.get(tier, '')}")
    if state.get("struggling"):
        lines.append(
            "- STRUGGLING: Simplify numbers in story challenges (e.g. 10×4 → 3×4), "
            "use visual groups, embed a brief in-story explanation BEFORE the puzzle, "
            "then an easier practice beat, then return to the plot."
        )
    if state.get("excelling"):
        lines.append(
            "- EXCELLING: Increase complexity (e.g. 12×8 → 24×15), use word problems "
            "and multi-step reasoning woven into the narrative."
        )
    missed = state.get("missed_concepts") or []
    if missed:
        lines.append(f"- Gently revisit: {', '.join(missed)}.")
    if state.get("hint_count", 0) > 2:
        lines.append("- This learner often needs hints — offer in-story scaffolding, not a separate lecture.")
    avg_ms = state.get("avg_response_ms") or 0
    if avg_ms > 30000:
        lines.append("- Allow more thinking time in the narrative; shorter text chunks between beats.")
    return "\n".join(lines)


def normalize_difficulty(key: str) -> str:
    k = (key or "medium").strip().lower()
    return k if k in DIFFICULTY_LEVELS else "medium"


# ---------------------------------------------------------------------------
# SQLite persistence
# ---------------------------------------------------------------------------

def init_adaptive_tables(conn) -> None:
    conn.execute("""
        CREATE TABLE IF NOT EXISTS adaptive_concept_state (
            learner_id TEXT NOT NULL,
            concept_key TEXT NOT NULL,
            grade INTEGER,
            subject TEXT,
            topic TEXT,
            concept_tag TEXT,
            state_json TEXT NOT NULL,
            updated_at REAL,
            PRIMARY KEY (learner_id, concept_key)
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS adaptive_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            learner_id TEXT NOT NULL,
            event_type TEXT NOT NULL,
            grade INTEGER,
            subject TEXT,
            topic TEXT,
            concept_tag TEXT,
            correct INTEGER,
            response_ms INTEGER,
            attempts INTEGER,
            hints INTEGER,
            engagement TEXT,
            payload_json TEXT,
            created_at REAL
        )
    """)
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_adaptive_events_learner "
        "ON adaptive_events(learner_id, created_at)"
    )


def load_concept_state(
    conn,
    learner_id: str,
    grade: int,
    subject: str,
    topic: str,
    concept_tag: Optional[str] = None,
) -> dict:
    tag = concept_tag or infer_concept_tag(subject, topic)
    key = concept_key(grade, subject, topic, tag)
    row = conn.execute(
        "SELECT state_json FROM adaptive_concept_state WHERE learner_id = ? AND concept_key = ?",
        (learner_id.strip(), key),
    ).fetchone()
    if row:
        return json.loads(row["state_json"])
    return default_concept_state(grade, subject, topic, tag)


def save_concept_state(conn, learner_id: str, state: dict) -> None:
    now = time.time()
    conn.execute(
        """
        INSERT INTO adaptive_concept_state (learner_id, concept_key, grade, subject, topic, concept_tag, state_json, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(learner_id, concept_key) DO UPDATE SET
            state_json = excluded.state_json,
            updated_at = excluded.updated_at
        """,
        (
            learner_id.strip(),
            state["concept_key"],
            state.get("grade"),
            state.get("subject"),
            state.get("topic"),
            state.get("concept_tag"),
            json.dumps(state),
            now,
        ),
    )


def record_event(
    conn,
    learner_id: str,
    event_type: str,
    grade: int,
    subject: str,
    topic: str,
    *,
    correct: Optional[bool] = None,
    response_ms: int = 0,
    attempts: int = 1,
    hints: int = 0,
    engagement: str = "",
    concept_tag: Optional[str] = None,
    payload: Optional[dict] = None,
) -> dict:
    tag = concept_tag or infer_concept_tag(subject, topic)
    state = load_concept_state(conn, learner_id, grade, subject, topic, tag)
    event = {
        "correct": correct,
        "response_ms": response_ms,
        "attempts": attempts,
        "hints": hints,
        "engagement": engagement,
        "concept_tag": tag,
    }
    new_state = apply_event(state, event)
    save_concept_state(conn, learner_id, new_state)
    conn.execute(
        """
        INSERT INTO adaptive_events (
            learner_id, event_type, grade, subject, topic, concept_tag,
            correct, response_ms, attempts, hints, engagement, payload_json, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            learner_id.strip(), event_type, grade, subject, topic, tag,
            1 if correct else 0 if correct is False else None,
            response_ms, attempts, hints, engagement,
            json.dumps(payload or {}), time.time(),
        ),
    )
    return new_state


def get_adaptive_status(
    conn,
    learner_id: str,
    grade: int,
    subject: str,
    topic: str,
) -> dict:
    tag = infer_concept_tag(subject, topic)
    state = load_concept_state(conn, learner_id, grade, subject, topic, tag)
    return {
        "concept_tag": tag,
        "recommended_difficulty": recommend_difficulty(state),
        "challenge_tier": state.get("challenge_tier", 3),
        "mastery_score": round(state.get("mastery_score", 0), 3),
        "mastery_label": mastery_label(state.get("mastery_score", 0)),
        "message": status_message(state),
        "struggling": bool(state.get("struggling")),
        "excelling": bool(state.get("excelling")),
        "success_streak": state.get("success_streak", 0),
        "total_attempts": state.get("total_attempts", 0),
        "prompt_block": adaptive_prompt_block(state),
    }


def list_concept_states(conn, learner_id: str, limit: int = 50) -> list[dict]:
    """All adaptive concept rows for a learner, newest first."""
    rows = conn.execute(
        """
        SELECT state_json, updated_at FROM adaptive_concept_state
        WHERE learner_id = ?
        ORDER BY updated_at DESC
        LIMIT ?
        """,
        (learner_id.strip(), limit),
    ).fetchall()
    out = []
    for row in rows:
        try:
            out.append(json.loads(row["state_json"]))
        except (json.JSONDecodeError, TypeError):
            continue
    return out
