"""Model routing, structured-output schemas, and LLM helpers for cost control."""

from __future__ import annotations

import json
import logging
import os
from typing import Any

from anthropic_provider import AnthropicProvider
from openai_provider import OpenAIProvider
from story_challenges import ACTIVITY_TYPE_NAMES, CHALLENGE_CATEGORIES

logger = logging.getLogger(__name__)

_CHALLENGE_INTERACTIONS = [
    "none", "mcq", "numeric", "text", "fill_blank",
    "matching", "ordering", "drag_drop", "memory",
]


def _model_from_env(var_name: str, default: str) -> str:
    """Read model id from env, stripping accidental surrounding quotes."""
    raw = os.environ.get(var_name, default).strip()
    if len(raw) >= 2 and raw[0] == raw[-1] and raw[0] in "\"'":
        raw = raw[1:-1].strip()
    return raw or default


# --- Provider + model configuration -----------------------------------------
# Two model tiers: STORY (creative, streamed) and FAST (structured JSON + chat).
# Defaults come from env; the active provider/model can also be changed at
# runtime via update_settings() (see /api/ai/settings).

_ENV_MODELS: dict[str, dict[str, str]] = {
    "openai": {
        # gpt-4o: reliable flagship model for creative stories
        "story": _model_from_env("OPENAI_MODEL_STORY", "gpt-4o"),
        "fast": _model_from_env("OPENAI_MODEL_FAST", "gpt-4o-mini"),
    },
    "anthropic": {
        "story": _model_from_env("ANTHROPIC_MODEL_STORY", "claude-sonnet-5"),
        "fast": _model_from_env("ANTHROPIC_MODEL_FAST", "claude-haiku-4-5"),
    },
}

_PROVIDER_CLASSES: dict[str, type] = {
    "openai": OpenAIProvider,
    "anthropic": AnthropicProvider,
}

# Suggested models per provider for the in-app picker. Any env/custom model is
# merged in by provider_catalog() so it stays selectable. Keep these to models
# that standard API keys can actually reach: the picker POST is permissive (it
# accepts any non-empty id for power users), so a suggestion that 404s on the
# key would silently break whatever tier selects it. Opus 4.8 is deliberately
# NOT listed — it is not available on standard Anthropic API keys and returns a
# 404 not_found; type it manually only if your account has access.
_MODEL_CATALOG: dict[str, list[str]] = {
    "openai": ["gpt-4o", "gpt-4o-mini", "gpt-4.1", "gpt-4.1-mini"],
    "anthropic": ["claude-opus-5", "claude-sonnet-5", "claude-haiku-4-5"],
}

_DEFAULT_PROVIDER = os.environ.get("AI_PROVIDER", "openai").strip().lower() or "openai"
if _DEFAULT_PROVIDER not in _PROVIDER_CLASSES:
    logger.warning("Unknown AI_PROVIDER %r; falling back to 'openai'", _DEFAULT_PROVIDER)
    _DEFAULT_PROVIDER = "openai"

# Runtime settings holder. Process-global: seeded from env, applies server-wide
# until changed via update_settings(), and resets to env defaults on restart.
_settings: dict[str, Any] = {
    "provider": _DEFAULT_PROVIDER,
    "models": {name: dict(models) for name, models in _ENV_MODELS.items()},
}

_provider_instances: dict[str, Any] = {}


def _provider(name: str):
    """Lazily construct and cache a provider instance."""
    if name not in _provider_instances:
        _provider_instances[name] = _PROVIDER_CLASSES[name]()
    return _provider_instances[name]


def current_provider_name() -> str:
    return _settings["provider"]


def current_model(tier: str) -> str:
    """Resolve the model id for a tier ("story"/"fast") under the active provider."""
    return _settings["models"][_settings["provider"]][tier]


def configured_providers() -> list[str]:
    """Provider ids that have an API key configured."""
    return [name for name, cls in _PROVIDER_CLASSES.items() if cls.has_key()]


def provider_catalog() -> list[dict[str, Any]]:
    """Per-provider metadata for the in-app model picker."""
    configured = set(configured_providers())
    catalog: list[dict[str, Any]] = []
    for name, cls in _PROVIDER_CLASSES.items():
        selected = _settings["models"][name]
        # Ensure any custom/env model shows up as a selectable option.
        models = list(dict.fromkeys(
            _MODEL_CATALOG[name] + [selected["story"], selected["fast"]]
        ))
        catalog.append({
            "id": name,
            "label": getattr(cls, "label", name),
            "configured": name in configured,
            "models": models,
            "selected": dict(selected),
        })
    return catalog


def get_settings() -> dict[str, Any]:
    """Current provider + its resolved tier models."""
    provider = _settings["provider"]
    return {"provider": provider, "models": dict(_settings["models"][provider])}


def update_settings(
    provider: str | None = None,
    story: str | None = None,
    fast: str | None = None,
) -> dict[str, Any]:
    """Update the active provider and/or its tier models. Raises ValueError on an
    unknown/unconfigured provider or an empty model id."""
    if provider is not None:
        provider = provider.strip().lower()
        if provider not in _PROVIDER_CLASSES:
            raise ValueError(f"Unknown provider: {provider!r}")
        if not _PROVIDER_CLASSES[provider].has_key():
            raise ValueError(f"Provider {provider!r} has no API key configured")
        _settings["provider"] = provider

    target = _settings["provider"]
    if story is not None:
        story = story.strip()
        if not story:
            raise ValueError("story model cannot be empty")
        _settings["models"][target]["story"] = story
    if fast is not None:
        fast = fast.strip()
        if not fast:
            raise ValueError("fast model cannot be empty")
        _settings["models"][target]["fast"] = fast

    return get_settings()


def validate_active_provider() -> None:
    """Ensure the active provider has a key, otherwise fall back to any configured
    provider. Raises RuntimeError if none is configured. Call at startup."""
    name = _settings["provider"]
    if _PROVIDER_CLASSES[name].has_key():
        return
    configured = configured_providers()
    if not configured:
        raise RuntimeError(
            "No AI provider API key configured. "
            "Set OPENAI_API_KEY and/or ANTHROPIC_API_KEY."
        )
    logger.warning(
        "Active AI provider %r has no API key; falling back to %r", name, configured[0],
    )
    _settings["provider"] = configured[0]


FLASHCARD_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "cards": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "question": {"type": "string"},
                    "answer": {"type": "string"},
                    "hint": {"type": "string"},
                },
                "required": ["question", "answer", "hint"],
                "additionalProperties": False,
            },
            "minItems": 6,
            "maxItems": 6,
        }
    },
    "required": ["cards"],
    "additionalProperties": False,
}

MINDMAP_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "title": {"type": "string"},
        "mermaid": {"type": "string"},
    },
    "required": ["title", "mermaid"],
    "additionalProperties": False,
}

QUIZ_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "questions": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "question": {"type": "string"},
                    "options": {
                        "type": "array",
                        "items": {"type": "string"},
                        "minItems": 4,
                        "maxItems": 4,
                    },
                    "correct_index": {"type": "integer"},
                    "explanation": {"type": "string"},
                },
                "required": ["question", "options", "correct_index", "explanation"],
                "additionalProperties": False,
            },
            "minItems": 8,
            "maxItems": 8,
        }
    },
    "required": ["questions"],
    "additionalProperties": False,
}

SUBJECT_GATE_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "questions": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "type": {"type": "string", "enum": ["mcq", "subjective", "descriptive"]},
                    "question": {"type": "string"},
                    "options": {
                        "type": "array",
                        "items": {"type": "string"},
                    },
                    "correct_index": {"type": "integer"},
                    "model_answer": {"type": "string"},
                    "keywords": {
                        "type": "array",
                        "items": {"type": "string"},
                    },
                    "explanation": {"type": "string"},
                },
                "required": [
                    "type", "question", "options", "correct_index",
                    "model_answer", "keywords", "explanation",
                ],
                "additionalProperties": False,
            },
            "minItems": 20,
            "maxItems": 20,
        }
    },
    "required": ["questions"],
    "additionalProperties": False,
}

QUESTION_SET_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "title": {"type": "string"},
        "source_pattern": {"type": "string"},
        "questions": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "type": {
                        "type": "string",
                        "enum": [
                            "mcq", "short_answer", "long_answer",
                            "fill_blank", "true_false",
                        ],
                    },
                    "question": {"type": "string"},
                    "options": {
                        "type": "array",
                        "items": {"type": "string"},
                    },
                    "correct_index": {"type": "integer"},
                    "model_answer": {"type": "string"},
                    "keywords": {
                        "type": "array",
                        "items": {"type": "string"},
                    },
                    "difficulty": {"type": "string"},
                    "explanation": {"type": "string"},
                },
                "required": [
                    "type", "question", "options", "correct_index",
                    "model_answer", "keywords", "difficulty", "explanation",
                ],
                "additionalProperties": False,
            },
            "minItems": 5,
            "maxItems": 15,
        },
    },
    "required": ["title", "source_pattern", "questions"],
    "additionalProperties": False,
}

PUZZLE_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "type": {"type": "string"},
        "title": {"type": "string"},
        "content": {"type": "string"},
        "hint": {"type": "string"},
        "answer": {"type": "string"},
    },
    "required": ["type", "title", "content", "hint", "answer"],
    "additionalProperties": False,
}

_ADVENTURE_CHOICE_ITEM = {
    "type": "object",
    "properties": {
        "id": {"type": "string"},
        "text": {"type": "string"},
        "emoji": {"type": "string"},
        "skill_tags": {
            "type": "array",
            "items": {"type": "string"},
            "minItems": 0,
            "maxItems": 2,
        },
        "preview": {"type": "string"},
    },
    "required": ["id", "text", "emoji", "skill_tags", "preview"],
    "additionalProperties": False,
}

ADVENTURE_CHAPTER_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "chapter_number": {"type": "integer"},
        "chapter_title": {"type": "string"},
        "content": {"type": "string"},
        "dilemma_setup": {"type": "string"},
        "dilemma_skills": {
            "type": "array",
            "items": {"type": "string"},
            "minItems": 0,
            "maxItems": 3,
        },
        "choices": {
            "type": "array",
            "items": _ADVENTURE_CHOICE_ITEM,
        },
        "is_final": {"type": "boolean"},
    },
    "required": [
        "chapter_number", "chapter_title", "content", "dilemma_setup", "dilemma_skills",
        "choices", "is_final",
    ],
    "additionalProperties": False,
}

ADVENTURE_META_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "chapter_number": {"type": "integer"},
        "chapter_title": {"type": "string"},
        "dilemma_setup": {"type": "string"},
        "dilemma_skills": {
            "type": "array",
            "items": {"type": "string"},
            "minItems": 0,
            "maxItems": 3,
        },
        "choices": {
            "type": "array",
            "items": _ADVENTURE_CHOICE_ITEM,
        },
        "is_final": {"type": "boolean"},
    },
    "required": [
        "chapter_number", "chapter_title", "dilemma_setup", "dilemma_skills",
        "choices", "is_final",
    ],
    "additionalProperties": False,
}

_STORY_DILEMMA = {
    "type": "object",
    "properties": {
        "setup": {"type": "string"},
        "skills": {
            "type": "array",
            "items": {"type": "string"},
            "minItems": 0,
            "maxItems": 3,
        },
    },
    "required": ["setup", "skills"],
    "additionalProperties": False,
}

_STORY_CHOICE_ITEM = {
    "type": "object",
    "properties": {
        "id": {"type": "string"},
        "text": {"type": "string"},
        "emoji": {"type": "string"},
        "consequence": {"type": "string"},
        "learning_note": {"type": "string"},
        "skill_tags": {
            "type": "array",
            "items": {"type": "string"},
            "minItems": 0,
            "maxItems": 2,
        },
        "who_affected": {
            "type": "array",
            "items": {"type": "string"},
            "minItems": 0,
            "maxItems": 4,
        },
        "immediate_effects": {
            "type": "array",
            "items": {"type": "string"},
            "minItems": 0,
            "maxItems": 4,
        },
        "reflection_question": {"type": "string"},
        "values_tradeoff": {"type": "string"},
        "preview": {"type": "string"},
        "next_scene_id": {"type": "string"},
        "reward_xp": {"type": "integer"},
        "reward_item": {"type": "string"},
        "ending_id": {"type": "string"},
        "activity_type": {"type": "string", "enum": ["story", "explore", "challenge", "puzzle"]},
    },
    "required": [
        "id", "text", "emoji", "consequence", "learning_note",
        "skill_tags", "who_affected", "immediate_effects", "reflection_question",
        "values_tradeoff", "preview",
        "next_scene_id", "reward_xp", "reward_item", "ending_id", "activity_type",
    ],
    "additionalProperties": False,
}

_STORY_PAIR = {
    "type": "object",
    "properties": {"left": {"type": "string"}, "right": {"type": "string"}},
    "required": ["left", "right"],
    "additionalProperties": False,
}

_STORY_DROP_ZONE = {
    "type": "object",
    "properties": {
        "id": {"type": "string"},
        "label": {"type": "string"},
        "emoji": {"type": "string"},
    },
    "required": ["id", "label", "emoji"],
    "additionalProperties": False,
}

_STORY_DROP_ITEM = {
    "type": "object",
    "properties": {
        "id": {"type": "string"},
        "label": {"type": "string"},
        "emoji": {"type": "string"},
    },
    "required": ["id", "label", "emoji"],
    "additionalProperties": False,
}

_STORY_PLACEMENT = {
    "type": "object",
    "properties": {"item_id": {"type": "string"}, "zone_id": {"type": "string"}},
    "required": ["item_id", "zone_id"],
    "additionalProperties": False,
}

_STORY_MEMORY_PAIR = {
    "type": "object",
    "properties": {
        "id": {"type": "string"},
        "content": {"type": "string"},
        "emoji": {"type": "string"},
    },
    "required": ["id", "content", "emoji"],
    "additionalProperties": False,
}

_STORY_BLANK = {
    "type": "object",
    "properties": {
        "id": {"type": "string"},
        "answer": {"type": "string"},
        "acceptable_answers": {"type": "array", "items": {"type": "string"}},
    },
    "required": ["id", "answer", "acceptable_answers"],
    "additionalProperties": False,
}

_STORY_CHALLENGE = {
    "type": "object",
    "properties": {
        "type": {"type": "string", "enum": _CHALLENGE_INTERACTIONS},
        "activity_type": {"type": "string", "enum": ACTIVITY_TYPE_NAMES},
        "category": {"type": "string", "enum": list(CHALLENGE_CATEGORIES)},
        "question": {"type": "string"},
        "hint": {"type": "string"},
        "progressive_hints": {
            "type": "array",
            "items": {"type": "string"},
            "minItems": 5,
            "maxItems": 5,
        },
        "options": {
            "type": "array",
            "items": {"type": "string"},
            "minItems": 4,
            "maxItems": 4,
        },
        "correct_index": {"type": "integer"},
        "correct_answer": {"type": "string"},
        "acceptable_answers": {"type": "array", "items": {"type": "string"}},
        "keywords": {"type": "array", "items": {"type": "string"}},
        "pairs": {
            "type": "array",
            "items": _STORY_PAIR,
            "minItems": 0,
            "maxItems": 6,
        },
        "order_items": {
            "type": "array",
            "items": {"type": "string"},
            "minItems": 0,
            "maxItems": 8,
        },
        "correct_order": {
            "type": "array",
            "items": {"type": "integer"},
            "minItems": 0,
            "maxItems": 8,
        },
        "drop_zones": {
            "type": "array",
            "items": _STORY_DROP_ZONE,
            "minItems": 0,
            "maxItems": 4,
        },
        "drop_items": {
            "type": "array",
            "items": _STORY_DROP_ITEM,
            "minItems": 0,
            "maxItems": 8,
        },
        "correct_placements": {
            "type": "array",
            "items": _STORY_PLACEMENT,
            "minItems": 0,
            "maxItems": 8,
        },
        "memory_pairs": {
            "type": "array",
            "items": _STORY_MEMORY_PAIR,
            "minItems": 0,
            "maxItems": 6,
        },
        "blanks": {
            "type": "array",
            "items": _STORY_BLANK,
            "minItems": 0,
            "maxItems": 4,
        },
        "success_narrative": {"type": "string"},
        "failure_narrative": {"type": "string"},
        "explanation": {"type": "string"},
        "reward_xp": {"type": "integer"},
        "reward_item": {"type": "string"},
    },
    "required": [
        "type", "activity_type", "category", "question", "hint", "progressive_hints",
        "options", "correct_index", "correct_answer", "acceptable_answers", "keywords",
        "pairs", "order_items", "correct_order", "drop_zones", "drop_items",
        "correct_placements", "memory_pairs", "blanks",
        "success_narrative", "failure_narrative", "explanation", "reward_xp", "reward_item",
    ],
    "additionalProperties": False,
}

_STORY_DIALOGUE_LINE = {
    "type": "object",
    "properties": {
        "character_id": {"type": "string"},
        "line": {"type": "string"},
        "mood": {"type": "string", "enum": ["neutral", "happy", "curious", "surprised", "worried", "excited"]},
    },
    "required": ["character_id", "line", "mood"],
    "additionalProperties": False,
}

_STORY_HOTSPOT = {
    "type": "object",
    "properties": {
        "object_id": {"type": "string"},
        "label": {"type": "string"},
        "emoji": {"type": "string"},
        "x_percent": {"type": "integer"},
        "y_percent": {"type": "integer"},
        "discovery_text": {"type": "string"},
        "reaction_emoji": {"type": "string"},
    },
    "required": ["object_id", "label", "emoji", "x_percent", "y_percent", "discovery_text", "reaction_emoji"],
    "additionalProperties": False,
}

_STORY_SCENE = {
    "type": "object",
    "properties": {
        "scene_id": {"type": "string"},
        "title": {"type": "string"},
        "location_id": {"type": "string"},
        "background_theme": {
            "type": "string",
            "enum": ["forest", "river", "mountain", "cave", "classroom", "space", "castle", "village"],
        },
        "character_ids": {
            "type": "array",
            "items": {"type": "string"},
            "minItems": 1,
            "maxItems": 3,
        },
        "narrative": {"type": "string"},
        "dialogue": {
            "type": "array",
            "items": _STORY_DIALOGUE_LINE,
            "minItems": 2,
            "maxItems": 5,
        },
        "hotspots": {
            "type": "array",
            "items": _STORY_HOTSPOT,
            "minItems": 0,
            "maxItems": 3,
        },
        "learning_objective": {"type": "string"},
        "dilemma": _STORY_DILEMMA,
        "next_scene_id": {"type": "string"},
        "challenge": _STORY_CHALLENGE,
        "choices": {
            "type": "array",
            "items": _STORY_CHOICE_ITEM,
            "minItems": 0,
            "maxItems": 3,
        },
    },
    "required": [
        "scene_id", "title", "location_id", "background_theme", "character_ids",
        "narrative", "dialogue", "hotspots", "learning_objective", "dilemma", "next_scene_id",
        "challenge", "choices",
    ],
    "additionalProperties": False,
}

STORY_WORLD_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "title": {"type": "string"},
        "synopsis": {"type": "string"},
        "characters": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "id": {"type": "string"},
                    "name": {"type": "string"},
                    "emoji": {"type": "string"},
                    "role": {"type": "string"},
                    "description": {"type": "string"},
                },
                "required": ["id", "name", "emoji", "role", "description"],
                "additionalProperties": False,
            },
            "minItems": 2,
            "maxItems": 4,
        },
        "locations": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "id": {"type": "string"},
                    "name": {"type": "string"},
                    "emoji": {"type": "string"},
                    "description": {"type": "string"},
                },
                "required": ["id", "name", "emoji", "description"],
                "additionalProperties": False,
            },
            "minItems": 2,
            "maxItems": 4,
        },
        "objects": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "id": {"type": "string"},
                    "name": {"type": "string"},
                    "emoji": {"type": "string"},
                    "location_id": {"type": "string"},
                    "description": {"type": "string"},
                },
                "required": ["id", "name", "emoji", "location_id", "description"],
                "additionalProperties": False,
            },
            "minItems": 1,
            "maxItems": 4,
        },
        "learning_objectives": {
            "type": "array",
            "items": {"type": "string"},
            "minItems": 2,
            "maxItems": 4,
        },
        "chapters": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "chapter_number": {"type": "integer"},
                    "title": {"type": "string"},
                    "scenes": {
                        "type": "array",
                        "items": _STORY_SCENE,
                        "minItems": 2,
                        "maxItems": 3,
                    },
                },
                "required": ["chapter_number", "title", "scenes"],
                "additionalProperties": False,
            },
            "minItems": 2,
            "maxItems": 2,
        },
        "endings": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "id": {"type": "string"},
                    "title": {"type": "string"},
                    "emoji": {"type": "string"},
                    "narrative": {"type": "string"},
                },
                "required": ["id", "title", "emoji", "narrative"],
                "additionalProperties": False,
            },
            "minItems": 1,
            "maxItems": 3,
        },
    },
    "required": [
        "title", "synopsis", "characters", "locations", "objects",
        "learning_objectives", "chapters", "endings",
    ],
    "additionalProperties": False,
}

KNOW_MORE_SPARKS_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "sparks": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "question": {"type": "string"},
                    "emoji": {"type": "string"},
                },
                "required": ["question", "emoji"],
                "additionalProperties": False,
            },
            "minItems": 2,
            "maxItems": 5,
        }
    },
    "required": ["sparks"],
    "additionalProperties": False,
}

KNOW_MORE_EXPLORE_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "title": {"type": "string"},
        "emoji": {"type": "string"},
        "content": {"type": "string"},
        "fun_fact": {"type": "string"},
        "follow_ups": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "question": {"type": "string"},
                    "emoji": {"type": "string"},
                    "preview": {"type": "string"},
                },
                "required": ["question", "emoji", "preview"],
                "additionalProperties": False,
            },
            "minItems": 0,
            "maxItems": 3,
        },
    },
    "required": ["title", "emoji", "content", "fun_fact", "follow_ups"],
    "additionalProperties": False,
}

_CHILD_STORY_VOCAB = {
    "type": "object",
    "properties": {
        "word": {"type": "string"},
        "definition": {"type": "string"},
    },
    "required": ["word", "definition"],
    "additionalProperties": False,
}

CHILD_STORY_GENERATE_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "title": {"type": "string"},
        "story": {"type": "string"},
        "vocabulary": {
            "type": "array",
            "items": _CHILD_STORY_VOCAB,
            "minItems": 2,
            "maxItems": 6,
        },
        "structure": {
            "type": "object",
            "properties": {
                "beginning": {"type": "string"},
                "middle": {"type": "string"},
                "ending": {"type": "string"},
            },
            "required": ["beginning", "middle", "ending"],
            "additionalProperties": False,
        },
        "skills_practiced": {
            "type": "array",
            "items": {"type": "string"},
            "minItems": 2,
            "maxItems": 5,
        },
        "praise": {"type": "string"},
    },
    "required": ["title", "story", "vocabulary", "structure", "skills_practiced", "praise"],
    "additionalProperties": False,
}

CHILD_STORY_CONTINUE_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "title": {"type": "string"},
        "child_words_preserved": {"type": "string"},
        "story": {"type": "string"},
        "vocabulary": {
            "type": "array",
            "items": _CHILD_STORY_VOCAB,
            "minItems": 1,
            "maxItems": 6,
        },
        "skills_feedback": {
            "type": "object",
            "properties": {
                "creativity": {"type": "string"},
                "sequencing": {"type": "string"},
                "vocabulary": {"type": "string"},
                "narrative_structure": {"type": "string"},
                "writing": {"type": "string"},
            },
            "required": ["creativity", "sequencing", "vocabulary", "narrative_structure", "writing"],
            "additionalProperties": False,
        },
        "praise": {"type": "string"},
    },
    "required": [
        "title", "child_words_preserved", "story", "vocabulary",
        "skills_feedback", "praise",
    ],
    "additionalProperties": False,
}

SCHEMAS: dict[str, dict[str, Any]] = {
    "flashcards": FLASHCARD_SCHEMA,
    "mindmap": MINDMAP_SCHEMA,
    "quiz": QUIZ_SCHEMA,
    "subject_gate": SUBJECT_GATE_SCHEMA,
    "question_set": QUESTION_SET_SCHEMA,
    "puzzle": PUZZLE_SCHEMA,
    "adventure": ADVENTURE_CHAPTER_SCHEMA,
    "adventure_meta": ADVENTURE_META_SCHEMA,
    "story_world": STORY_WORLD_SCHEMA,
    "know_more_sparks": KNOW_MORE_SPARKS_SCHEMA,
    "know_more_explore": KNOW_MORE_EXPLORE_SCHEMA,
    "child_story_generate": CHILD_STORY_GENERATE_SCHEMA,
    "child_story_continue": CHILD_STORY_CONTINUE_SCHEMA,
}


def complete_json(
    tier: str,
    schema_name: str,
    instructions: str,
    input_messages: list[dict[str, str]],
) -> Any:
    """Blocking structured JSON completion using the active provider + tier model."""
    return _provider(_settings["provider"]).complete_json(
        current_model(tier),
        SCHEMAS[schema_name],
        schema_name,
        instructions,
        input_messages,
    )


def complete_text(
    tier: str,
    instructions: str,
    input_messages: list[dict[str, str]],
) -> str:
    """Blocking free-text completion using the active provider + tier model."""
    return _provider(_settings["provider"]).complete_text(
        current_model(tier), instructions, input_messages,
    )


async def stream_text(
    tier: str,
    instructions: str,
    input_messages: list[dict[str, str]],
    *,
    reasoning: bool | None = None,
):
    """Yield (event_type, payload) tuples from the active provider's streaming API.

    event_type is one of: "token", "thinking", "completed", "error".
    """
    provider = _provider(_settings["provider"])
    async for event in provider.stream_text(
        current_model(tier), instructions, input_messages, reasoning=reasoning,
    ):
        yield event

