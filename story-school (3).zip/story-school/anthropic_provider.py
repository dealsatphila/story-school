"""Anthropic (Claude) provider — structured JSON, text, and streaming via the
Messages API.

Kept in its own module so the Anthropic SDK never shares a file with the OpenAI
SDK. The tier/model/provider selection lives in ai_config.py, which owns an
instance of this class.

Notes on shape differences from the OpenAI Responses API:
  * OpenAI ``instructions`` maps to Anthropic ``system``.
  * ``input_messages`` (``[{"role", "content"}]``) are valid Anthropic
    ``messages`` as-is.
  * Anthropic requires ``max_tokens`` on every request.
  * Structured JSON uses ``output_config={"format": {"type": "json_schema", ...}}``
    (no ``name``/``strict`` keys, unlike OpenAI).
"""

from __future__ import annotations

import json
import os
from typing import Any

from anthropic import Anthropic, AsyncAnthropic


def _int_env(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, "").strip() or default)
    except ValueError:
        return default


# Anthropic requires an explicit output ceiling. Kept comfortably below the SDK's
# non-streaming 10-minute guard (~21k tokens) for the create() paths; the JSON
# path streams internally so it may exceed that.
MAX_TOKENS_TEXT = _int_env("ANTHROPIC_MAX_TOKENS_TEXT", 8000)
MAX_TOKENS_JSON = _int_env("ANTHROPIC_MAX_TOKENS_JSON", 32000)
MAX_TOKENS_STREAM = _int_env("ANTHROPIC_MAX_TOKENS_STREAM", 8000)

# Summarized "thinking" is opt-in; off by default to match the current gpt-4o flow.
REASONING_DEFAULT = os.environ.get("ANTHROPIC_REASONING", "").strip().lower() in (
    "1", "true", "yes",
)


def _text_of(content: list) -> str:
    """Join all text blocks of a message's content."""
    return "".join(b.text for b in content if getattr(b, "type", "") == "text")


class AnthropicProvider:
    """Adapts the Anthropic Messages API to the provider interface."""

    name = "anthropic"
    label = "Anthropic (Claude)"

    def __init__(self) -> None:
        self._client: Anthropic | None = None
        self._async_client: AsyncAnthropic | None = None

    @staticmethod
    def has_key() -> bool:
        return bool(os.environ.get("ANTHROPIC_API_KEY"))

    def _sync(self) -> Anthropic:
        if self._client is None:
            key = os.environ.get("ANTHROPIC_API_KEY")
            if not key:
                raise RuntimeError("ANTHROPIC_API_KEY environment variable is required")
            self._client = Anthropic(api_key=key)
        return self._client

    def _async(self) -> AsyncAnthropic:
        if self._async_client is None:
            key = os.environ.get("ANTHROPIC_API_KEY")
            if not key:
                raise RuntimeError("ANTHROPIC_API_KEY environment variable is required")
            self._async_client = AsyncAnthropic(api_key=key)
        return self._async_client

    def complete_json(
        self,
        model: str,
        schema: dict[str, Any],
        schema_name: str,
        instructions: str,
        input_messages: list[dict[str, str]],
    ) -> Any:
        """Blocking structured JSON completion via the Messages API.

        Streams internally and reads the final message so large schemas (e.g.
        ``story_world``) never trip the SDK's non-streaming max_tokens guard.
        """
        kwargs: dict[str, Any] = {
            "model": model,
            "max_tokens": MAX_TOKENS_JSON,
            "messages": input_messages,
            "output_config": {"format": {"type": "json_schema", "schema": schema}},
        }
        if instructions:
            kwargs["system"] = instructions

        with self._sync().messages.stream(**kwargs) as stream:
            final = stream.get_final_message()
        # output_config guarantees the text block holds valid JSON.
        return json.loads(_text_of(final.content).strip())

    def complete_text(
        self,
        model: str,
        instructions: str,
        input_messages: list[dict[str, str]],
    ) -> str:
        """Blocking free-text completion via the Messages API."""
        kwargs: dict[str, Any] = {
            "model": model,
            "max_tokens": MAX_TOKENS_TEXT,
            "messages": input_messages,
        }
        if instructions:
            kwargs["system"] = instructions
        response = self._sync().messages.create(**kwargs)
        return _text_of(response.content)

    async def stream_text(
        self,
        model: str,
        instructions: str,
        input_messages: list[dict[str, str]],
        *,
        reasoning: bool | None = None,
    ):
        """Yield (event_type, payload) tuples from a streaming Messages call.

        Emits the same contract as the OpenAI provider: ``token``, ``thinking``,
        ``completed``, ``error``.
        """
        if reasoning is None:
            reasoning = REASONING_DEFAULT

        kwargs: dict[str, Any] = {
            "model": model,
            "max_tokens": MAX_TOKENS_STREAM,
            "messages": input_messages,
        }
        if instructions:
            kwargs["system"] = instructions
        if reasoning:
            kwargs["thinking"] = {"type": "adaptive", "display": "summarized"}

        try:
            async with self._async().messages.stream(**kwargs) as stream:
                async for event in stream:
                    if event.type == "content_block_delta":
                        delta = event.delta
                        dtype = getattr(delta, "type", "")
                        if dtype == "text_delta":
                            yield "token", delta.text
                        elif dtype == "thinking_delta":
                            yield "thinking", delta.thinking
            yield "completed", None
        except Exception as e:  # surface as an SSE error, mirroring OpenAI path
            yield "error", f"{type(e).__name__}: {e}"
