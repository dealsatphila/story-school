"""Hidden assessment engine — observes learning through gameplay, not tests."""

from __future__ import annotations

import json
import time
from typing import Any, Optional

SKILL_DIMENSIONS: dict[str, dict[str, str]] = {
    "apply_knowledge": {
        "label": "Applies ideas in context",
        "emoji": "🎯",
        "description": "Uses what they learned inside stories, quests, and challenges.",
    },
    "recall_knowledge": {
        "label": "Recalls what they learned",
        "emoji": "🧠",
        "description": "Remembers facts and ideas when asked naturally in play.",
    },
    "transfer_knowledge": {
        "label": "Transfers to new situations",
        "emoji": "🔀",
        "description": "Connects ideas across topics, genres, or real-world scenes.",
    },
    "explain_reasoning": {
        "label": "Explains their thinking",
        "emoji": "💬",
        "description": "Shares why they chose an answer or what they believe.",
    },
    "solve_unfamiliar": {
        "label": "Solves unfamiliar problems",
        "emoji": "🧩",
        "description": "Stretches into new or checkpoint-level challenges.",
    },
    "identify_patterns": {
        "label": "Identifies patterns",
        "emoji": "🔍",
        "description": "Notices repeating structures, rules, and relationships.",
    },
    "correct_mistakes": {
        "label": "Corrects mistakes",
        "emoji": "🔧",
        "description": "Recovers after a miss with practice or a second try.",
    },
    "make_predictions": {
        "label": "Makes predictions",
        "emoji": "🔮",
        "description": "Anticipates outcomes and reflects on choices.",
    },
}

LEVEL_THRESHOLDS = (
    (0.8, "strong", "🟢"),
    (0.6, "growing", "🟡"),
    (0.35, "developing", "🟡"),
    (0.0, "emerging", "🔴"),
)

# Gameplay source → skill dimensions (dimension, base_weight)
SOURCE_SKILL_MAP: dict[str, list[tuple[str, float]]] = {
    "quiz": [("recall_knowledge", 1.0), ("apply_knowledge", 0.45)],
    "story_challenge": [("apply_knowledge", 1.0), ("recall_knowledge", 0.35)],
    "adventure": [("apply_knowledge", 0.6), ("make_predictions", 0.5)],
    "adventure_choice": [("make_predictions", 0.85), ("explain_reasoning", 0.35)],
    "dilemma_choice": [
        ("make_predictions", 0.9),
        ("explain_reasoning", 0.55),
        ("transfer_knowledge", 0.45),
    ],
    "mini_practice": [("correct_mistakes", 1.0), ("recall_knowledge", 0.4)],
    "mistake_recovery": [("correct_mistakes", 1.0)],
    "doubt": [("explain_reasoning", 1.0)],
    "writing": [("explain_reasoning", 0.85), ("transfer_knowledge", 0.35)],
    "spaced_review": [("recall_knowledge", 1.0), ("correct_mistakes", 0.25)],
    "gate_exam": [("solve_unfamiliar", 1.0), ("transfer_knowledge", 0.55)],
    "puzzle": [("identify_patterns", 1.0), ("solve_unfamiliar", 0.45)],
    "project_step": [("apply_knowledge", 0.75), ("transfer_knowledge", 0.7)],
    "flashcards": [("recall_knowledge", 0.9)],
    "mindmap": [("identify_patterns", 0.7), ("transfer_knowledge", 0.4)],
    "comprehension": [("explain_reasoning", 0.6), ("recall_knowledge", 0.4)],
    "curiosity_explore": [("make_predictions", 0.7), ("transfer_knowledge", 0.55)],
    "story_creation": [("explain_reasoning", 0.85), ("transfer_knowledge", 0.5)],
    "reflection": [("explain_reasoning", 0.9), ("make_predictions", 0.35)],
}


def init_assessment_tables(conn) -> None:
    conn.execute("""
        CREATE TABLE IF NOT EXISTS assessment_signals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            learner_id TEXT NOT NULL,
            dimension TEXT NOT NULL,
            source_event TEXT NOT NULL,
            outcome TEXT NOT NULL,
            weight REAL NOT NULL,
            grade INTEGER,
            subject TEXT,
            topic TEXT,
            payload_json TEXT,
            created_at REAL NOT NULL
        )
    """)
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_assessment_learner_dim "
        "ON assessment_signals(learner_id, dimension, created_at)"
    )
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_assessment_learner_time "
        "ON assessment_signals(learner_id, created_at)"
    )


def _level_for_score(score: float) -> tuple[str, str]:
    for threshold, label, emoji in LEVEL_THRESHOLDS:
        if score >= threshold:
            return label, emoji
    return "emerging", "🔴"


def _outcome_strength(
    correct: Optional[bool],
    *,
    attempts: int = 1,
    hints: int = 0,
    response_ms: int = 0,
) -> tuple[str, float]:
    """Return (outcome, multiplier) where outcome is positive/neutral/negative."""
    if correct is True:
        mult = 1.0
        if attempts > 1:
            mult = 0.85
        if hints > 0:
            mult *= max(0.5, 1.0 - hints * 0.12)
        if response_ms > 45000:
            mult *= 0.9
        return "positive", mult
    if correct is False:
        mult = 1.0
        if attempts >= 3:
            mult = 1.15
        return "negative", mult
    return "neutral", 0.35


def _extra_dimensions(
    source: str,
    *,
    correct: Optional[bool],
    attempts: int,
    hints: int,
    payload: Optional[dict],
) -> list[tuple[str, float]]:
    """Infer additional skill signals from gameplay context."""
    extra: list[tuple[str, float]] = []
    p = payload or {}

    if correct and attempts > 1:
        extra.append(("correct_mistakes", 0.9))

    if correct is False and attempts == 1:
        extra.append(("correct_mistakes", 0.2))

    activity = str(p.get("activity_type") or p.get("challenge_type") or "").lower()
    if any(k in activity for k in ("pattern", "sequence", "sort", "classify")):
        extra.append(("identify_patterns", 0.8))

    if p.get("is_novel") or p.get("gate_exam") or source == "gate_exam":
        extra.append(("solve_unfamiliar", 0.85))

    if p.get("reflection") or p.get("has_explanation") or p.get("writing"):
        extra.append(("explain_reasoning", 0.75))

    if p.get("cross_topic") or p.get("project_id"):
        extra.append(("transfer_knowledge", 0.65))

    if p.get("prediction") or "predict" in str(p.get("choice_type", "")).lower():
        extra.append(("make_predictions", 0.8))

    if source in ("adventure", "story_challenge") and correct:
        extra.append(("apply_knowledge", 0.25))

    return extra


def record_signal(
    conn,
    learner_id: str,
    dimension: str,
    source_event: str,
    outcome: str,
    weight: float,
    *,
    grade: int = 0,
    subject: str = "",
    topic: str = "",
    payload: Optional[dict] = None,
) -> None:
    if dimension not in SKILL_DIMENSIONS:
        return
    conn.execute(
        """
        INSERT INTO assessment_signals (
            learner_id, dimension, source_event, outcome, weight,
            grade, subject, topic, payload_json, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            learner_id.strip(),
            dimension,
            source_event,
            outcome,
            round(max(0.05, min(weight, 3.0)), 3),
            grade or None,
            subject or "",
            topic or "",
            json.dumps(payload or {}),
            time.time(),
        ),
    )


def observe_gameplay(
    conn,
    learner_id: str,
    source: str,
    *,
    grade: int = 0,
    subject: str = "",
    topic: str = "",
    correct: Optional[bool] = None,
    attempts: int = 1,
    hints: int = 0,
    response_ms: int = 0,
    payload: Optional[dict] = None,
) -> None:
    """Record hidden assessment signals from a gameplay moment."""
    lid = learner_id.strip()
    if not lid or not source:
        return

    outcome, mult = _outcome_strength(
        correct, attempts=attempts, hints=hints, response_ms=response_ms,
    )

    mapped = list(SOURCE_SKILL_MAP.get(source, []))
    mapped.extend(_extra_dimensions(
        source, correct=correct, attempts=attempts, hints=hints, payload=payload,
    ))

    seen: set[str] = set()
    for dimension, base_weight in mapped:
        if dimension in seen:
            continue
        seen.add(dimension)
        record_signal(
            conn, lid, dimension, source, outcome, base_weight * mult,
            grade=grade, subject=subject, topic=topic, payload=payload,
        )


def _aggregate_dimension(rows: list) -> dict:
    positive = 0.0
    negative = 0.0
    neutral = 0.0
    sources: set[str] = set()
    for row in rows:
        w = float(row["weight"] or 0)
        sources.add(row["source_event"])
        if row["outcome"] == "positive":
            positive += w
        elif row["outcome"] == "negative":
            negative += w
        else:
            neutral += w * 0.5
    total = positive + negative + neutral
    score = positive / (positive + negative + 0.5) if (positive + negative) > 0 else 0.0
    if total > 0 and positive == 0 and negative > 0:
        score = max(0.0, 0.25 - negative * 0.05)
    level, emoji = _level_for_score(score)
    meta = SKILL_DIMENSIONS.get(rows[0]["dimension"], {})
    return {
        "dimension": rows[0]["dimension"],
        "label": meta.get("label", rows[0]["dimension"]),
        "emoji": meta.get("emoji", "📊"),
        "description": meta.get("description", ""),
        "score": round(score, 3),
        "level": level,
        "status_emoji": emoji,
        "evidence_count": len(rows),
        "positive_weight": round(positive, 2),
        "struggle_weight": round(negative, 2),
        "sources": sorted(sources),
    }


def build_learning_profile(conn, learner_id: str, *, limit: int = 500) -> dict:
    """Hidden learning profile from gameplay evidence — not test scores."""
    lid = learner_id.strip()
    rows = conn.execute(
        """
        SELECT dimension, source_event, outcome, weight, subject, topic, created_at
        FROM assessment_signals
        WHERE learner_id = ?
        ORDER BY created_at DESC
        LIMIT ?
        """,
        (lid, limit),
    ).fetchall()

    by_dim: dict[str, list] = {}
    for row in rows:
        by_dim.setdefault(row["dimension"], []).append(row)

    dimensions = []
    for dim_id in SKILL_DIMENSIONS:
        dim_rows = by_dim.get(dim_id, [])
        if not dim_rows:
            dimensions.append({
                "dimension": dim_id,
                "label": SKILL_DIMENSIONS[dim_id]["label"],
                "emoji": SKILL_DIMENSIONS[dim_id]["emoji"],
                "description": SKILL_DIMENSIONS[dim_id]["description"],
                "score": None,
                "level": "not_enough_data",
                "status_emoji": "⚪",
                "evidence_count": 0,
                "sources": [],
            })
            continue
        dimensions.append(_aggregate_dimension(dim_rows))

    observed = [d for d in dimensions if d["evidence_count"] >= 2 and d["score"] is not None]
    observed.sort(key=lambda d: d["score"], reverse=True)

    strengths = [
        f"{d['emoji']} {d['label']}"
        for d in observed[:3]
        if d["score"] >= 0.55
    ]
    growth_edges = [
        f"{d['status_emoji']} {d['label']}"
        for d in sorted(observed, key=lambda d: d["score"])[:3]
        if d["score"] < 0.6
    ]

    recent_sources = conn.execute(
        """
        SELECT source_event, COUNT(*) AS cnt FROM assessment_signals
        WHERE learner_id = ? AND created_at > ?
        GROUP BY source_event ORDER BY cnt DESC LIMIT 6
        """,
        (lid, time.time() - 7 * 86400),
    ).fetchall()

    return {
        "learner_id": lid,
        "assessment_note": (
            "Inferred from adventures, stories, and play — "
            "no separate tests required."
        ),
        "dimensions": dimensions,
        "strengths": strengths,
        "growth_edges": growth_edges,
        "total_signals": len(rows),
        "dimensions_observed": len(observed),
        "recent_gameplay_sources": [
            {"source": r["source_event"], "count": r["cnt"]}
            for r in recent_sources
        ],
        "generated_at": time.time(),
    }


def assessment_catalog() -> dict:
    return {
        "dimensions": [
            {"id": k, **v}
            for k, v in SKILL_DIMENSIONS.items()
        ],
        "sources": list(SOURCE_SKILL_MAP.keys()),
        "note": "Hidden assessment observes gameplay; learners are never asked to take a test.",
    }
