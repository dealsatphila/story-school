"""Child learner profile — personalization for stories and learning paths."""

from __future__ import annotations

import json
import re
import time
from typing import Any, Optional

from syllabus import LANGUAGES

READING_LEVELS = {
    "beginner": {
        "name": "Beginner",
        "emoji": "🌱",
        "instruction": (
            "Use very short sentences, simple words, and extra repetition. "
            "Define every new term in kid-friendly language."
        ),
    },
    "developing": {
        "name": "Developing",
        "emoji": "📗",
        "instruction": (
            "Use clear, simple language with supportive explanations. "
            "One new idea per paragraph; recap often."
        ),
    },
    "grade_level": {
        "name": "Grade level",
        "emoji": "📘",
        "instruction": (
            "Match typical reading level for this grade. "
            "Balance clarity with grade-appropriate vocabulary."
        ),
    },
    "advanced": {
        "name": "Advanced",
        "emoji": "📕",
        "instruction": (
            "Use richer vocabulary and longer sentences while staying age-appropriate. "
            "Include subtle connections and deeper examples."
        ),
    },
    "fluent": {
        "name": "Fluent",
        "emoji": "🚀",
        "instruction": (
            "Challenge the reader with precise terms, nuance, and multi-step reasoning "
            "while keeping explanations engaging."
        ),
    },
}

PROFILE_FIELDS = (
    "name",
    "age",
    "grade",
    "preferred_language",
    "reading_level",
    "interests",
    "favorite_characters",
    "favorite_animals",
    "favorite_colors_themes",
    "learning_goals",
    "favorite_themes",
    "favorite_story_types",
    "favorite_activity_types",
    "preferred_difficulty",
    "audio_narration",
    "audio_music",
    "audio_sfx",
)


def default_child_profile() -> dict:
    return {
        "name": "",
        "age": None,
        "grade": None,
        "preferred_language": "english",
        "reading_level": "grade_level",
        "interests": [],
        "favorite_characters": [],
        "favorite_animals": [],
        "favorite_colors_themes": [],
        "learning_goals": [],
        "favorite_themes": [],
        "favorite_story_types": [],
        "favorite_activity_types": [],
        "preferred_difficulty": "medium",
        "audio_narration": True,
        "audio_music": True,
        "audio_sfx": True,
    }


def _split_tags(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, list):
        items = value
    else:
        items = re.split(r"[,;\n]+", str(value))
    out = []
    seen = set()
    for item in items:
        text = str(item).strip()
        if not text:
            continue
        key = text.lower()
        if key in seen:
            continue
        seen.add(key)
        out.append(text[:80])
    return out[:20]


def normalize_child_profile(data: Optional[dict]) -> dict:
    base = default_child_profile()
    if not data:
        return base

    name = str(data.get("name") or "").strip()[:60]
    base["name"] = name

    age = data.get("age")
    if age is not None and age != "":
        try:
            age_int = int(age)
            if 5 <= age_int <= 18:
                base["age"] = age_int
        except (TypeError, ValueError):
            pass

    grade = data.get("grade")
    if grade is not None and grade != "":
        try:
            grade_int = int(grade)
            if 5 <= grade_int <= 10:
                base["grade"] = grade_int
        except (TypeError, ValueError):
            pass

    lang = str(data.get("preferred_language") or "english").strip().lower()
    base["preferred_language"] = lang if lang in LANGUAGES else "english"

    level = str(data.get("reading_level") or "grade_level").strip().lower()
    base["reading_level"] = level if level in READING_LEVELS else "grade_level"

    base["interests"] = _split_tags(data.get("interests"))
    base["favorite_characters"] = _split_tags(data.get("favorite_characters"))
    base["favorite_animals"] = _split_tags(data.get("favorite_animals"))
    base["favorite_colors_themes"] = _split_tags(data.get("favorite_colors_themes"))
    base["learning_goals"] = _split_tags(data.get("learning_goals"))
    base["favorite_themes"] = [
        _norm_key(t) for t in _split_tags(data.get("favorite_themes"))
        if _norm_key(t)
    ]
    base["favorite_story_types"] = _split_tags(data.get("favorite_story_types"))
    base["favorite_activity_types"] = _split_tags(data.get("favorite_activity_types"))

    diff = str(data.get("preferred_difficulty") or "medium").strip().lower()
    base["preferred_difficulty"] = diff if diff in ("easy", "medium", "hard") else "medium"

    base["audio_narration"] = bool(data.get("audio_narration", True))
    base["audio_music"] = bool(data.get("audio_music", True))
    base["audio_sfx"] = bool(data.get("audio_sfx", True))
    return base


def _norm_key(text: str) -> str:
    return re.sub(r"\s+", "_", str(text or "").strip().lower())[:40]


def reading_level_instruction(level_key: str) -> str:
    level = READING_LEVELS.get(normalize_child_profile({"reading_level": level_key})["reading_level"])
    return level["instruction"] if level else READING_LEVELS["grade_level"]["instruction"]


def save_child_profile(conn, learner_id: str, profile: dict) -> dict:
    normalized = normalize_child_profile(profile)
    now = time.time()
    conn.execute(
        """
        INSERT INTO child_profile (learner_id, profile_json, updated_at)
        VALUES (?, ?, ?)
        ON CONFLICT(learner_id) DO UPDATE SET
            profile_json = excluded.profile_json,
            updated_at = excluded.updated_at
        """,
        (learner_id.strip(), json.dumps(normalized), now),
    )
    return normalized


def get_child_profile(conn, learner_id: str) -> Optional[dict]:
    row = conn.execute(
        "SELECT profile_json FROM child_profile WHERE learner_id = ?",
        (learner_id.strip(),),
    ).fetchone()
    if not row:
        return None
    try:
        return normalize_child_profile(json.loads(row["profile_json"]))
    except json.JSONDecodeError:
        return None


def child_profile_is_set(profile: Optional[dict]) -> bool:
    if not profile:
        return False
    return bool(profile.get("name") or profile.get("grade") or profile.get("interests"))


def child_profile_prompt_block(profile: Optional[dict]) -> str:
    """Instructions appended to AI system prompts for personalization."""
    p = normalize_child_profile(profile)
    if not child_profile_is_set(p):
        return ""

    lines = ["\n\nCHILD PROFILE — personalize the lesson for this learner:"]
    if p["name"]:
        lines.append(f"- Call them {p['name']} occasionally (not every sentence).")
    if p["age"]:
        lines.append(f"- Age: {p['age']}.")
    if p["grade"]:
        lines.append(f"- School grade: {p['grade']} (CBSE).")
    if p["preferred_language"] in LANGUAGES:
        lang_name = LANGUAGES[p["preferred_language"]]["name"]
        lines.append(f"- Preferred language: {lang_name}.")
    lines.append(f"- Reading level: {READING_LEVELS[p['reading_level']]['name']}.")
    lines.append(f"  {reading_level_instruction(p['reading_level'])}")

    if p["interests"]:
        lines.append(f"- Interests to weave in: {', '.join(p['interests'])}.")
    if p["favorite_characters"]:
        lines.append(
            f"- Favorite characters/heroes (use as inspiration, not copyright copies): "
            f"{', '.join(p['favorite_characters'])}."
        )
    if p["favorite_animals"]:
        lines.append(f"- Favorite animals (optional story mascots): {', '.join(p['favorite_animals'])}.")
    if p["favorite_colors_themes"]:
        lines.append(f"- Favorite colors/themes for mood and visuals: {', '.join(p['favorite_colors_themes'])}.")
    if p["learning_goals"]:
        lines.append(f"- Learning goals to support: {', '.join(p['learning_goals'])}.")
    if p.get("favorite_themes"):
        theme_labels = ", ".join(p["favorite_themes"])
        lines.append(f"- Favorite story themes: {theme_labels}.")
    if p.get("favorite_story_types"):
        lines.append(f"- Favorite story styles: {', '.join(p['favorite_story_types'])}.")
    if p.get("preferred_difficulty"):
        lines.append(f"- Preferred challenge: {p['preferred_difficulty']}.")

    lines.append(
        "Use these details naturally in examples, character names, and metaphors — "
        "never force every item into one story."
    )
    return "\n".join(lines)
