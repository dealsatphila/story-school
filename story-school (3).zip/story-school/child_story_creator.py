"""Story creation by the child — builder mode and write-what-happens-next."""

from __future__ import annotations

import json
import time
import uuid
from typing import Any, Optional

SKILLS_TAUGHT = [
    {"id": "writing", "name": "Writing", "emoji": "✍️"},
    {"id": "vocabulary", "name": "Vocabulary", "emoji": "📚"},
    {"id": "creativity", "name": "Creativity", "emoji": "✨"},
    {"id": "sequencing", "name": "Sequencing", "emoji": "🔢"},
    {"id": "narrative_structure", "name": "Narrative structure", "emoji": "📖"},
]

HEROES = [
    {"id": "brave_kid", "name": "Brave Kid", "emoji": "🧒"},
    {"id": "curious_inventor", "name": "Curious Inventor", "emoji": "🔬"},
    {"id": "kind_helper", "name": "Kind Helper", "emoji": "💛"},
    {"id": "space_captain", "name": "Space Captain", "emoji": "👩‍🚀"},
    {"id": "forest_guardian", "name": "Forest Guardian", "emoji": "🌿"},
    {"id": "young_detective", "name": "Young Detective", "emoji": "🔍"},
    {"id": "dreamer_artist", "name": "Dreamer Artist", "emoji": "🎨"},
    {"id": "sports_champion", "name": "Sports Champion", "emoji": "🏆"},
]

ANIMALS = [
    {"id": "fox", "name": "Clever Fox", "emoji": "🦊"},
    {"id": "owl", "name": "Wise Owl", "emoji": "🦉"},
    {"id": "dolphin", "name": "Playful Dolphin", "emoji": "🐬"},
    {"id": "elephant", "name": "Gentle Elephant", "emoji": "🐘"},
    {"id": "dragon", "name": "Baby Dragon", "emoji": "🐉"},
    {"id": "penguin", "name": "Brave Penguin", "emoji": "🐧"},
    {"id": "rabbit", "name": "Quick Rabbit", "emoji": "🐰"},
    {"id": "turtle", "name": "Patient Turtle", "emoji": "🐢"},
]

LOCATIONS = [
    {"id": "enchanted_forest", "name": "Enchanted Forest", "emoji": "🌲"},
    {"id": "space_station", "name": "Space Station", "emoji": "🛸"},
    {"id": "underwater_city", "name": "Underwater City", "emoji": "🌊"},
    {"id": "mountain_village", "name": "Mountain Village", "emoji": "⛰️"},
    {"id": "busy_market", "name": "Busy Market", "emoji": "🏪"},
    {"id": "secret_library", "name": "Secret Library", "emoji": "📚"},
    {"id": "desert_oasis", "name": "Desert Oasis", "emoji": "🏜️"},
    {"id": "school_rooftop", "name": "School Rooftop Garden", "emoji": "🏫"},
]

PROBLEMS = [
    {"id": "lost_treasure", "name": "Find a lost treasure", "emoji": "💎"},
    {"id": "help_friend", "name": "Help a friend in trouble", "emoji": "🤝"},
    {"id": "solve_mystery", "name": "Solve a mystery", "emoji": "🕵️"},
    {"id": "save_nature", "name": "Save nature", "emoji": "🌍"},
    {"id": "invent_solution", "name": "Invent a clever solution", "emoji": "💡"},
    {"id": "learn_skill", "name": "Learn something new", "emoji": "📖"},
    {"id": "bridge_communities", "name": "Bring people together", "emoji": "🌉"},
    {"id": "overcome_fear", "name": "Overcome a fear", "emoji": "💪"},
]

THEMES = [
    {"id": "friendship", "name": "Friendship", "emoji": "🤝"},
    {"id": "courage", "name": "Courage", "emoji": "🦁"},
    {"id": "curiosity", "name": "Curiosity", "emoji": "🔍"},
    {"id": "kindness", "name": "Kindness", "emoji": "💛"},
    {"id": "perseverance", "name": "Never give up", "emoji": "🌱"},
    {"id": "teamwork", "name": "Teamwork", "emoji": "👥"},
    {"id": "honesty", "name": "Honesty", "emoji": "⭐"},
    {"id": "imagination", "name": "Imagination", "emoji": "🌈"},
]

CATALOG_MAP = {
    "hero": HEROES,
    "animal": ANIMALS,
    "location": LOCATIONS,
    "problem": PROBLEMS,
    "theme": THEMES,
}


def creator_catalog() -> dict:
    return {
        "name": "Create My Story",
        "emoji": "✍️",
        "description": "You pick the pieces — Finn helps weave them into a story you can be proud of.",
        "modes": [
            {
                "id": "builder",
                "name": "Create My Story",
                "emoji": "🎨",
                "description": "Pick a hero, animal, location, problem, and theme.",
            },
            {
                "id": "continue",
                "name": "Write What Happens Next",
                "emoji": "📝",
                "description": "Write your ideas — AI turns them into a full story while keeping YOUR voice.",
            },
        ],
        "choices": {
            "heroes": HEROES,
            "animals": ANIMALS,
            "locations": LOCATIONS,
            "problems": PROBLEMS,
            "themes": THEMES,
        },
        "skills_taught": SKILLS_TAUGHT,
    }


def resolve_choice(category: str, choice_id: str) -> Optional[dict]:
    items = CATALOG_MAP.get(category) or []
    for item in items:
        if item["id"] == choice_id:
            return item
    return None


def validate_choices(choices: dict) -> dict:
    required = ("hero", "animal", "location", "problem", "theme")
    out: dict[str, dict] = {}
    for key in required:
        cid = str((choices or {}).get(key, "")).strip()
        item = resolve_choice(key, cid)
        if not item:
            raise ValueError(f"Invalid or missing choice: {key}")
        out[key] = item
    return out


def choices_summary(choices: dict) -> str:
    parts = [
        f"Hero: {choices['hero']['emoji']} {choices['hero']['name']}",
        f"Animal ally: {choices['animal']['emoji']} {choices['animal']['name']}",
        f"Location: {choices['location']['emoji']} {choices['location']['name']}",
        f"Problem: {choices['problem']['emoji']} {choices['problem']['name']}",
        f"Theme: {choices['theme']['emoji']} {choices['theme']['name']}",
    ]
    return "\n".join(parts)


def builder_story_prompt(
    grade: int,
    choices: dict,
    *,
    child_name: str = "",
    subject: str = "",
    topic: str = "",
    language_instruction: str = "English",
    reading_instruction: str = "",
) -> str:
    name = child_name.strip() or "the young author"
    topic_line = ""
    if topic.strip():
        topic_line = (
            f"\nOPTIONAL SCHOOL TIE-IN: Gently weave Grade {grade} {subject} — "
            f"{topic} — into the adventure without making it feel like homework."
        )
    return f"""You are Finn the Fox 🦊 helping {name} (Grade {grade}) CREATE their own story.

THE CHILD CHOSE:
{choices_summary(choices)}

LANGUAGE: {language_instruction}
{reading_instruction}{topic_line}

Write a story (350–550 words) that:
1. Uses the child's choices as the heart of the plot — they are the CREATOR.
2. Has clear beginning (setup), middle (problem grows), and ending (theme shines through).
3. Includes the animal ally as a helpful friend — not a pet prop.
4. Uses 2–3 vivid vocabulary words marked with {{{{VOCAB: word|kid-friendly definition}}}}.
5. Ends with a warm line celebrating {name}'s imagination.

Also return:
- A catchy title
- 3 vocabulary highlights from the story
- Brief structure notes (beginning / middle / ending) for learning
- One sentence of praise for the child's creative choices
- Which skills they practiced (from: writing, vocabulary, creativity, sequencing, narrative_structure)

Tone: joyful, empowering, never condescending. The child is the author — you are the co-writer."""


def continue_story_prompt(
    grade: int,
    child_draft: str,
    *,
    child_name: str = "",
    subject: str = "",
    topic: str = "",
    story_context: str = "",
    language_instruction: str = "English",
    reading_instruction: str = "",
) -> str:
    name = child_name.strip() or "the young author"
    ctx = ""
    if story_context.strip():
        ctx = f"\nSTORY SO FAR (context):\n{story_context.strip()[:2500]}\n"
    elif topic.strip():
        ctx = f"\nTOPIC CONTEXT: Grade {grade} {subject} — {topic}\n"
    return f"""You are Finn the Fox 🦊 co-writing with {name} (Grade {grade}).

THE CHILD WROTE (preserve their ideas and words — do NOT replace their voice):
---
{child_draft.strip()}
---
{ctx}
LANGUAGE: {language_instruction}
{reading_instruction}

Turn their ideas into a complete story (300–500 words):
1. KEEP their key ideas, characters, and surprises — expand, don't overwrite.
2. Quote or echo at least one phrase they wrote in the opening.
3. Show clear sequencing: first → then → finally.
4. Mark 2–3 strong vocabulary words with {{{{VOCAB: word|definition}}}}.
5. End celebrating what THEY imagined.

Return skill-specific feedback (1 warm sentence each) for:
- creativity (what was original in their draft)
- sequencing (how events flow)
- vocabulary (words they used or could try)
- narrative_structure (beginning/middle/end)
- writing (overall encouragement)

Plus: title, full story markdown, vocabulary list, praise."""


def validate_generated_story(data: Any, choices: Optional[dict] = None) -> dict:
    if not isinstance(data, dict):
        raise ValueError("story response must be an object")
    title = str(data.get("title", "")).strip()
    story = str(data.get("story", "")).strip()
    if not story:
        raise ValueError("story text required")
    vocab = []
    for raw in data.get("vocabulary") or []:
        if isinstance(raw, dict) and raw.get("word"):
            vocab.append({
                "word": str(raw["word"]).strip(),
                "definition": str(raw.get("definition", "")).strip(),
            })
    structure = data.get("structure") or {}
    if not isinstance(structure, dict):
        structure = {}
    skills = []
    for s in data.get("skills_practiced") or []:
        sid = str(s).strip()
        if sid:
            skills.append(sid)
    praise = str(data.get("praise", "")).strip()
    return {
        "title": title or "My Story",
        "story": story,
        "vocabulary": vocab[:6],
        "structure": {
            "beginning": str(structure.get("beginning", "")).strip(),
            "middle": str(structure.get("middle", "")).strip(),
            "ending": str(structure.get("ending", "")).strip(),
        },
        "skills_practiced": skills or ["writing", "creativity"],
        "praise": praise,
        "choices": choices,
    }


def validate_continued_story(data: Any, child_draft: str) -> dict:
    if not isinstance(data, dict):
        raise ValueError("continue response must be an object")
    story = str(data.get("story", "")).strip()
    if not story:
        raise ValueError("story text required")
    feedback = data.get("skills_feedback") or {}
    if not isinstance(feedback, dict):
        feedback = {}
    vocab = []
    for raw in data.get("vocabulary") or []:
        if isinstance(raw, dict) and raw.get("word"):
            vocab.append({
                "word": str(raw["word"]).strip(),
                "definition": str(raw.get("definition", "")).strip(),
            })
    return {
        "title": str(data.get("title", "")).strip() or "What Happens Next",
        "child_draft": child_draft.strip(),
        "child_words_preserved": str(data.get("child_words_preserved", "")).strip(),
        "story": story,
        "vocabulary": vocab[:6],
        "skills_feedback": {
            k: str(feedback.get(k, "")).strip()
            for k in ("creativity", "sequencing", "vocabulary", "narrative_structure", "writing")
            if feedback.get(k)
        },
        "praise": str(data.get("praise", "")).strip(),
        "skills_practiced": ["writing", "vocabulary", "creativity", "sequencing", "narrative_structure"],
    }


def init_creator_tables(conn) -> None:
    conn.execute("""
        CREATE TABLE IF NOT EXISTS child_created_stories (
            id TEXT PRIMARY KEY,
            learner_id TEXT NOT NULL,
            mode TEXT NOT NULL,
            title TEXT,
            choices_json TEXT,
            child_draft TEXT,
            story_text TEXT NOT NULL,
            meta_json TEXT,
            grade INTEGER,
            subject TEXT,
            topic TEXT,
            created_at REAL
        )
    """)
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_child_stories_learner "
        "ON child_created_stories(learner_id, created_at DESC)"
    )


def save_created_story(
    conn,
    learner_id: str,
    mode: str,
    title: str,
    story_text: str,
    *,
    choices: Optional[dict] = None,
    child_draft: str = "",
    meta: Optional[dict] = None,
    grade: int = 0,
    subject: str = "",
    topic: str = "",
) -> str:
    story_id = uuid.uuid4().hex[:12]
    conn.execute(
        """
        INSERT INTO child_created_stories
            (id, learner_id, mode, title, choices_json, child_draft, story_text,
             meta_json, grade, subject, topic, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            story_id, learner_id.strip(), mode, title,
            json.dumps(choices) if choices else "",
            child_draft, story_text,
            json.dumps(meta or {}),
            grade, subject or "", topic or "",
            time.time(),
        ),
    )
    return story_id


def list_created_stories(conn, learner_id: str, limit: int = 12) -> list[dict]:
    rows = conn.execute(
        """
        SELECT id, mode, title, grade, subject, topic, created_at
        FROM child_created_stories
        WHERE learner_id = ?
        ORDER BY created_at DESC
        LIMIT ?
        """,
        (learner_id.strip(), limit),
    ).fetchall()
    return [
        {
            "id": r["id"],
            "mode": r["mode"],
            "title": r["title"],
            "grade": r["grade"],
            "subject": r["subject"],
            "topic": r["topic"],
            "created_at": r["created_at"],
        }
        for r in rows
    ]
