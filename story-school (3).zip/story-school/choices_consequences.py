"""Choices & consequences — meaningful decisions in stories (not quizzes)."""

from __future__ import annotations

import copy
from typing import Any, Optional

# Skills taught through narrative decisions (not scored quizzes).
CHOICE_SKILLS: dict[str, dict[str, str]] = {
    "critical_thinking": {
        "name": "Critical thinking",
        "emoji": "🧠",
        "description": "Weigh reasons, compare options, and notice what matters.",
    },
    "ethics": {
        "name": "Ethics",
        "emoji": "⚖️",
        "description": "Think about fairness, care, and what is right for everyone.",
    },
    "resource_management": {
        "name": "Resource management",
        "emoji": "💧",
        "description": "Decide how to share limited time, water, money, or supplies.",
    },
    "cause_effect": {
        "name": "Cause & effect",
        "emoji": "🔗",
        "description": "See how one decision ripples into what happens next.",
    },
    "decision_making": {
        "name": "Decision making",
        "emoji": "🎯",
        "description": "Choose a path on purpose, knowing trade-offs exist.",
    },
}

SKILL_KEYS = tuple(CHOICE_SKILLS.keys())


def choice_prompt_block() -> str:
    return """
CHOICES & CONSEQUENCES (meaningful decisions — NOT quizzes):
- Include at least 2 dilemma scenes where challenge.type is "none" and the scene has exactly 3 choices.
- Each dilemma should teach the topic through a real trade-off (fairness, resources, safety, teamwork).
- Example: a village has limited water — choices might be equal shares, prioritize those who need most, or find more water together.
- There are NO "wrong" choices — every path is valid but leads to DIFFERENT consequences to explore.

For dilemma scenes add:
  dilemma: { setup: "2-3 sentences describing the situation and stakes", skills: ["ethics","resource_management",...] }

For EVERY choice object include:
  id, text, emoji, consequence (3-5 sentences: what happens BECAUSE of this choice),
  learning_note (1-2 sentences linking to the school topic),
  skill_tags (1-2 from: critical_thinking, ethics, resource_management, cause_effect, decision_making),
  who_affected (1-3 short labels, e.g. "farmers", "children"),
  immediate_effects (2-3 short bullet strings shown after picking),
  reflection_question (one open question — no single right answer),
  values_tradeoff (short phrase, e.g. "Fairness vs speed"),
  next_scene_id, reward_xp (5-15), reward_item, ending_id, activity_type

Consequence writing rules:
- Show cause → effect in the story world (who gains, who struggles, what changes).
- Never say "correct" or "incorrect" — describe outcomes honestly.
- Tie learning_note to the curriculum topic without breaking immersion."""


def adventure_choice_prompt_block() -> str:
    return """
CHOICES & CONSEQUENCES:
- End non-final chapters with EXACTLY 3 meaningful decisions (not trivia).
- Each choice explores a different value or strategy tied to the topic.
- No choice is "wrong" — the NEXT chapter must explore consequences of what the student picked.
- When continuing after a student choice, dedicate the opening to what happened BECAUSE of that decision
  (who was helped, what got harder, what was learned) before new events unfold."""


def adventure_meta_prompt_block() -> str:
    return """
- dilemma_setup: 1-2 sentences if the chapter ends on a meaningful decision (empty string if is_final)
- dilemma_skills: array of skill ids when dilemma_setup is set
- choices: each with id, text, emoji, skill_tags (1-2), preview (one-line teaser — NOT the full consequence)
- is_final: true only when the narrative already includes a learning summary; then choices = []"""


def adventure_consequence_user_message(choice_text: str) -> str:
    return (
        f"The student chose: {choice_text}\n\n"
        "Write the NEXT chapter exploring the CONSEQUENCES of this decision:\n"
        "1. Open by showing what happened because they chose this (cause → effect).\n"
        "2. Who was helped or affected? What got easier or harder?\n"
        "3. Teach part of the topic through the outcome — not a lecture, lived experience.\n"
        "4. End on a new meaningful dilemma with 3 fresh choices (unless this should be the final chapter)."
    )


def _clean_str_list(raw: Any, max_items: int = 5) -> list[str]:
    if not isinstance(raw, list):
        return []
    out = []
    for item in raw:
        s = str(item or "").strip()
        if s:
            out.append(s[:120])
        if len(out) >= max_items:
            break
    return out


def normalize_dilemma(raw: Optional[dict]) -> Optional[dict]:
    if not raw or not isinstance(raw, dict):
        return None
    setup = str(raw.get("setup") or raw.get("dilemma_setup") or "").strip()
    if not setup:
        return None
    skills = []
    for s in raw.get("skills") or raw.get("dilemma_skills") or []:
        key = str(s or "").strip().lower().replace(" ", "_")
        if key in SKILL_KEYS and key not in skills:
            skills.append(key)
    return {"setup": setup[:500], "skills": skills[:3]}


def normalize_choice(raw: dict) -> dict:
    tags = []
    for s in raw.get("skill_tags") or []:
        key = str(s or "").strip().lower().replace(" ", "_")
        if key in SKILL_KEYS and key not in tags:
            tags.append(key)

    return {
        "id": str(raw.get("id") or "").strip() or "a",
        "text": str(raw.get("text") or "").strip()[:200],
        "emoji": str(raw.get("emoji") or "✨")[:4],
        "consequence": str(raw.get("consequence") or "").strip()[:1200],
        "learning_note": str(raw.get("learning_note") or "").strip()[:400],
        "skill_tags": tags[:2],
        "who_affected": _clean_str_list(raw.get("who_affected"), 4),
        "immediate_effects": _clean_str_list(raw.get("immediate_effects"), 4),
        "reflection_question": str(raw.get("reflection_question") or "").strip()[:300],
        "values_tradeoff": str(raw.get("values_tradeoff") or "").strip()[:120],
        "preview": str(raw.get("preview") or "").strip()[:160],
        "next_scene_id": str(raw.get("next_scene_id") or "").strip(),
        "reward_xp": max(0, min(30, int(raw.get("reward_xp") or 5))),
        "reward_item": str(raw.get("reward_item") or "").strip()[:60],
        "ending_id": str(raw.get("ending_id") or "").strip(),
        "activity_type": str(raw.get("activity_type") or "story").strip()[:20] or "story",
    }


def enrich_skill_tags(tags: list[str]) -> list[dict]:
    out = []
    for key in tags:
        meta = CHOICE_SKILLS.get(key, {})
        out.append({
            "id": key,
            "name": meta.get("name", key.replace("_", " ").title()),
            "emoji": meta.get("emoji", "✨"),
        })
    return out


def strip_choice_for_client(choice: dict) -> dict:
    """Remove spoilers before the learner decides."""
    c = copy.deepcopy(choice)
    for key in (
        "consequence", "learning_note", "immediate_effects",
        "reflection_question", "who_affected", "values_tradeoff",
    ):
        c.pop(key, None)
    return c


def strip_scene_choices_for_client(scene: dict) -> dict:
    sc = copy.deepcopy(scene)
    sc["choices"] = [strip_choice_for_client(c) for c in (sc.get("choices") or [])]
    return sc


def build_choice_outcome(choice: dict, scene: Optional[dict] = None) -> dict:
    dilemma = normalize_dilemma((scene or {}).get("dilemma"))
    tags = enrich_skill_tags(choice.get("skill_tags") or [])
    dilemma_skills = enrich_skill_tags((dilemma or {}).get("skills") or [])
    return {
        "consequence": choice.get("consequence", ""),
        "learning_note": choice.get("learning_note", ""),
        "immediate_effects": choice.get("immediate_effects") or [],
        "who_affected": choice.get("who_affected") or [],
        "reflection_question": choice.get("reflection_question", ""),
        "values_tradeoff": choice.get("values_tradeoff", ""),
        "skill_tags": tags,
        "dilemma_skills": dilemma_skills,
        "choice_text": choice.get("text", ""),
        "choice_emoji": choice.get("emoji", "✨"),
    }


def catalog_for_api() -> dict:
    return {
        "skills": [{"id": k, **v} for k, v in CHOICE_SKILLS.items()],
        "narrative_note": (
            "Choices explore consequences and trade-offs — there is no single "
            "'correct' answer, only different lessons."
        ),
        "example": {
            "setup": "The village well is almost dry before the rainy season.",
            "choices": [
                "Give everyone equal water",
                "Give more water to people who need it most",
                "Work together to collect more water",
            ],
        },
    }
