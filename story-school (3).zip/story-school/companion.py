"""Companion character development — narrative attributes & unlocks."""

from __future__ import annotations

import copy
import time
from typing import Any, Optional

# Narrative attributes — describe the companion's adventure journey, NOT the child.
COMPANION_ATTRIBUTES: dict[str, dict[str, str]] = {
    "courage": {
        "name": "Courage",
        "emoji": "🦁",
        "narrative": "Your companion grows braver on tough quests and checkpoints.",
    },
    "curiosity": {
        "name": "Curiosity",
        "emoji": "🔍",
        "narrative": "Your companion loves asking questions and exploring new topics.",
    },
    "creativity": {
        "name": "Creativity",
        "emoji": "🎨",
        "narrative": "Your companion imagines wild story worlds and clever ideas.",
    },
    "problem_solving": {
        "name": "Problem-solving",
        "emoji": "🧩",
        "narrative": "Your companion cracks puzzles and story challenges.",
    },
    "knowledge": {
        "name": "Knowledge",
        "emoji": "📚",
        "narrative": "Your companion collects wisdom from lessons and quizzes.",
    },
    "kindness": {
        "name": "Kindness",
        "emoji": "💛",
        "narrative": "Your companion helps friends and chooses caring paths.",
    },
    "persistence": {
        "name": "Persistence",
        "emoji": "🌱",
        "narrative": "Your companion keeps going after mistakes and mini practices.",
    },
}

ATTRIBUTE_KEYS = tuple(COMPANION_ATTRIBUTES.keys())

UNLOCK_TYPES = (
    "clothes",
    "pets",
    "accessories",
    "vehicles",
    "houses",
    "rooms",
    "decorations",
    "companions",
)

# id, type, emoji, name, cost_coins, requires {attr: min}, min_level (optional)
COMPANION_UNLOCKS: list[dict[str, Any]] = [
    # Clothes
    {"id": "starter_scarf", "type": "clothes", "emoji": "🧣", "name": "Cozy Scarf", "cost_coins": 0, "requires": {}},
    {"id": "explorer_cap", "type": "clothes", "emoji": "🧢", "name": "Explorer Cap", "cost_coins": 15, "requires": {"curiosity": 3}},
    {"id": "star_hoodie", "type": "clothes", "emoji": "👕", "name": "Star Hoodie", "cost_coins": 25, "requires": {"knowledge": 4}},
    {"id": "wizard_robe", "type": "clothes", "emoji": "🧙", "name": "Wizard Robe", "cost_coins": 40, "requires": {"creativity": 6}},
    {"id": "hero_cape", "type": "clothes", "emoji": "🦸", "name": "Hero Cape", "cost_coins": 50, "requires": {"courage": 5}},
    # Pets
    {"id": "baby_owl", "type": "pets", "emoji": "🦉", "name": "Baby Owl", "cost_coins": 20, "requires": {"curiosity": 4}},
    {"id": "pocket_fox", "type": "pets", "emoji": "🦊", "name": "Pocket Fox", "cost_coins": 30, "requires": {"persistence": 3}},
    {"id": "spark_dragon", "type": "pets", "emoji": "🐉", "name": "Spark Dragon", "cost_coins": 60, "requires": {"courage": 6, "creativity": 4}},
    {"id": "cloud_bunny", "type": "pets", "emoji": "🐰", "name": "Cloud Bunny", "cost_coins": 25, "requires": {"kindness": 4}},
    # Accessories
    {"id": "magnifying_glass", "type": "accessories", "emoji": "🔎", "name": "Magnifying Glass", "cost_coins": 10, "requires": {"curiosity": 2}},
    {"id": "lucky_charm", "type": "accessories", "emoji": "🍀", "name": "Lucky Charm", "cost_coins": 18, "requires": {"persistence": 3}},
    {"id": "brain_badge", "type": "accessories", "emoji": "🧠", "name": "Brain Badge", "cost_coins": 22, "requires": {"knowledge": 3}},
    {"id": "puzzle_belt", "type": "accessories", "emoji": "🧩", "name": "Puzzle Belt", "cost_coins": 28, "requires": {"problem_solving": 4}},
    {"id": "heart_pin", "type": "accessories", "emoji": "💝", "name": "Heart Pin", "cost_coins": 20, "requires": {"kindness": 3}},
    # Vehicles
    {"id": "rocket_scooter", "type": "vehicles", "emoji": "🛴", "name": "Rocket Scooter", "cost_coins": 35, "requires": {"curiosity": 5}},
    {"id": "sky_glider", "type": "vehicles", "emoji": "🪂", "name": "Sky Glider", "cost_coins": 55, "requires": {"courage": 4}},
    {"id": "story_boat", "type": "vehicles", "emoji": "⛵", "name": "Story Boat", "cost_coins": 45, "requires": {"creativity": 5}},
    {"id": "knowledge_train", "type": "vehicles", "emoji": "🚂", "name": "Knowledge Express", "cost_coins": 70, "requires": {"knowledge": 7}},
    # Houses
    {"id": "cozy_nest", "type": "houses", "emoji": "🏡", "name": "Cozy Nest", "cost_coins": 0, "requires": {}},
    {"id": "treehouse", "type": "houses", "emoji": "🌳", "name": "Treehouse", "cost_coins": 50, "requires": {"persistence": 5}},
    {"id": "crystal_cottage", "type": "houses", "emoji": "🏠", "name": "Crystal Cottage", "cost_coins": 80, "requires": {"knowledge": 6, "creativity": 4}},
    {"id": "sky_castle", "type": "houses", "emoji": "🏰", "name": "Sky Castle", "cost_coins": 100, "requires": {"courage": 8}},
    # Rooms
    {"id": "reading_nook", "type": "rooms", "emoji": "📖", "name": "Reading Nook", "cost_coins": 30, "requires": {"knowledge": 3}},
    {"id": "art_studio", "type": "rooms", "emoji": "🖌️", "name": "Art Studio", "cost_coins": 35, "requires": {"creativity": 4}},
    {"id": "puzzle_lab", "type": "rooms", "emoji": "🔬", "name": "Puzzle Lab", "cost_coins": 40, "requires": {"problem_solving": 5}},
    {"id": "kindness_garden", "type": "rooms", "emoji": "🌻", "name": "Kindness Garden", "cost_coins": 32, "requires": {"kindness": 4}},
    # Decorations
    {"id": "star_lamp", "type": "decorations", "emoji": "💡", "name": "Star Lamp", "cost_coins": 12, "requires": {}},
    {"id": "trophy_shelf", "type": "decorations", "emoji": "🏆", "name": "Trophy Shelf", "cost_coins": 25, "requires": {"knowledge": 2}},
    {"id": "story_banner", "type": "decorations", "emoji": "🎏", "name": "Story Banner", "cost_coins": 18, "requires": {"curiosity": 3}},
    {"id": "galaxy_poster", "type": "decorations", "emoji": "🌌", "name": "Galaxy Poster", "cost_coins": 22, "requires": {"creativity": 3}},
    # Companion allies
    {"id": "finn_ally", "type": "companions", "emoji": "🦊", "name": "Finn the Fox", "cost_coins": 0, "requires": {"curiosity": 1}},
    {"id": "wise_owl", "type": "companions", "emoji": "🦉", "name": "Oliver the Owl", "cost_coins": 35, "requires": {"knowledge": 5}},
    {"id": "brave_lion", "type": "companions", "emoji": "🦁", "name": "Leo the Lion", "cost_coins": 45, "requires": {"courage": 5}},
    {"id": "kind_deer", "type": "companions", "emoji": "🦌", "name": "Daisy the Deer", "cost_coins": 38, "requires": {"kindness": 5}},
]

# Learning events → companion attribute growth (narrative, not personality labels)
EVENT_GROWTH: dict[str, dict[str, int]] = {
    "story_complete": {"curiosity": 1},
    "mindmap_complete": {"knowledge": 1},
    "flashcards_complete": {"knowledge": 1},
    "quiz_bronze": {"knowledge": 1},
    "quiz_silver": {"knowledge": 1, "problem_solving": 1},
    "quiz_gold": {"knowledge": 2, "persistence": 1},
    "story_world_complete": {"creativity": 1, "problem_solving": 1},
    "challenge_solved": {"problem_solving": 1},
    "mini_practice_done": {"persistence": 2},
    "doubt_asked": {"curiosity": 1},
    "know_more_explore": {"curiosity": 1, "knowledge": 1},
    "story_created": {"creativity": 2, "knowledge": 1},
    "reflection_shared": {"critical_thinking": 1, "curiosity": 1},
    "adventure_chapter": {"creativity": 1, "courage": 1},
    "gate_passed": {"courage": 2, "knowledge": 1},
    "mistake_recovered": {"persistence": 1, "kindness": 1},
    "dilemma_choice": {"critical_thinking": 1, "creativity": 1},
    "project_step": {"knowledge": 1, "problem_solving": 1, "persistence": 1},
}


def default_companion() -> dict:
    return {
        "name": "Spark",
        "species": "fox",
        "emoji": "🦊",
        "attributes": {k: 0 for k in ATTRIBUTE_KEYS},
        "unlocked": ["starter_scarf", "cozy_nest", "finn_ally", "star_lamp"],
        "equipped": {
            "clothes": "starter_scarf",
            "pets": None,
            "accessories": None,
            "vehicles": None,
            "houses": "cozy_nest",
            "rooms": None,
            "decorations": "star_lamp",
            "companions": "finn_ally",
        },
        "updated_at": time.time(),
    }


def normalize_companion(data: Optional[dict]) -> dict:
    base = default_companion()
    if not data:
        return base
    name = str(data.get("name") or "Spark").strip()[:30] or "Spark"
    base["name"] = name
    base["species"] = str(data.get("species") or "fox")[:20]
    base["emoji"] = str(data.get("emoji") or "🦊")[:4]

    attrs = data.get("attributes") or {}
    for key in ATTRIBUTE_KEYS:
        try:
            base["attributes"][key] = max(0, min(100, int(attrs.get(key, 0))))
        except (TypeError, ValueError):
            base["attributes"][key] = 0

    unlocked = data.get("unlocked") or []
    if isinstance(unlocked, list):
        valid_ids = {u["id"] for u in COMPANION_UNLOCKS}
        base["unlocked"] = list(dict.fromkeys(
            [u for u in unlocked if u in valid_ids] + base["unlocked"]
        ))

    eq = data.get("equipped") or {}
    for utype in UNLOCK_TYPES:
        val = eq.get(utype)
        if val and val in base["unlocked"]:
            base["equipped"][utype] = val
        elif val is None:
            base["equipped"][utype] = None

    return base


def unlock_by_id(unlock_id: str) -> Optional[dict]:
    return next((u for u in COMPANION_UNLOCKS if u["id"] == unlock_id), None)


def attribute_totals(companion: dict) -> int:
    return sum(companion.get("attributes", {}).values())


def meets_requirements(companion: dict, item: dict, level: int = 1) -> bool:
    reqs = item.get("requires") or {}
    attrs = companion.get("attributes") or {}
    for key, need in reqs.items():
        if attrs.get(key, 0) < need:
            return False
    min_level = item.get("min_level")
    if min_level and level < min_level:
        return False
    return True


def growth_message(attribute: str, amount: int, companion_name: str) -> str:
    meta = COMPANION_ATTRIBUTES.get(attribute, {})
    name = meta.get("name", attribute)
    emoji = meta.get("emoji", "✨")
    if amount > 1:
        return f"{emoji} {companion_name}'s **{name}** grew +{amount} on this adventure!"
    return f"{emoji} {companion_name}'s **{name}** grew on this adventure!"


def apply_companion_event(
    companion: dict,
    event_type: str,
    *,
    amount_scale: int = 1,
) -> tuple[dict, list[dict]]:
    """Apply narrative attribute growth. Returns (companion, growth_messages)."""
    growth = EVENT_GROWTH.get(event_type, {})
    if not growth:
        return companion, []

    out = copy.deepcopy(normalize_companion(companion))
    messages = []
    for attr, delta in growth.items():
        if attr not in ATTRIBUTE_KEYS:
            continue
        bump = max(1, int(delta) * amount_scale)
        out["attributes"][attr] = min(100, out["attributes"].get(attr, 0) + bump)
        messages.append({
            "attribute": attr,
            "delta": bump,
            "total": out["attributes"][attr],
            "message": growth_message(attr, bump, out["name"]),
        })

    out["updated_at"] = time.time()
    return out, messages


def auto_unlock_eligible(companion: dict, level: int = 1) -> list[str]:
    """Free unlocks when requirements met (cost 0) not yet owned."""
    owned = set(companion.get("unlocked") or [])
    new_ids = []
    for item in COMPANION_UNLOCKS:
        if item["id"] in owned:
            continue
        if item.get("cost_coins", 0) == 0 and meets_requirements(companion, item, level):
            new_ids.append(item["id"])
    return new_ids


def purchase_unlock(
    companion: dict,
    unlock_id: str,
    coins: int,
    level: int = 1,
) -> tuple[dict, int, Optional[str]]:
    """Try to purchase. Returns (companion, coins_spent, error)."""
    item = unlock_by_id(unlock_id)
    if not item:
        return companion, 0, "Unknown item"
    out = copy.deepcopy(normalize_companion(companion))
    if unlock_id in out["unlocked"]:
        return out, 0, "Already unlocked"

    if not meets_requirements(out, item, level):
        return out, 0, "Companion needs more adventure growth first"

    cost = int(item.get("cost_coins") or 0)
    if coins < cost:
        return out, 0, f"Need {cost} coins"

    out["unlocked"].append(unlock_id)
    out["updated_at"] = time.time()
    return out, cost, None


def equip_item(companion: dict, unlock_id: str) -> tuple[dict, Optional[str]]:
    item = unlock_by_id(unlock_id)
    if not item:
        return companion, "Unknown item"
    out = copy.deepcopy(normalize_companion(companion))
    if unlock_id not in out["unlocked"]:
        return out, "Not unlocked yet"
    utype = item["type"]
    if utype not in UNLOCK_TYPES:
        return out, "Invalid item type"
    out["equipped"][utype] = unlock_id
    out["updated_at"] = time.time()
    return out, None


def companion_catalog() -> dict:
    by_type: dict[str, list] = {t: [] for t in UNLOCK_TYPES}
    for item in COMPANION_UNLOCKS:
        by_type[item["type"]].append({
            "id": item["id"],
            "emoji": item["emoji"],
            "name": item["name"],
            "cost_coins": item.get("cost_coins", 0),
            "requires": item.get("requires", {}),
        })
    return {
        "attributes": [
            {"id": k, **v} for k, v in COMPANION_ATTRIBUTES.items()
        ],
        "unlock_types": list(UNLOCK_TYPES),
        "unlocks_by_type": by_type,
        "event_growth": {k: v for k, v in EVENT_GROWTH.items()},
        "narrative_note": (
            "Attributes describe your companion's adventure story — "
            "not a judgment of who you are."
        ),
    }


def build_companion_view(companion: dict, level: int = 1, coins: int = 0) -> dict:
    c = normalize_companion(companion)
    unlocks = []
    for item in COMPANION_UNLOCKS:
        owned = item["id"] in c["unlocked"]
        eligible = meets_requirements(c, item, level)
        unlocks.append({
            **{k: item[k] for k in ("id", "type", "emoji", "name")},
            "cost_coins": item.get("cost_coins", 0),
            "requires": item.get("requires", {}),
            "owned": owned,
            "can_buy": eligible and not owned and coins >= item.get("cost_coins", 0),
            "eligible": eligible,
        })
    return {
        "companion": c,
        "unlocks": unlocks,
        "attribute_total": attribute_totals(c),
        "top_attributes": top_attributes(c, 3),
    }


def top_attributes(companion: dict, n: int = 3) -> list[dict]:
    attrs = companion.get("attributes") or {}
    ranked = sorted(attrs.items(), key=lambda x: (-x[1], x[0]))[:n]
    return [
        {
            "id": k,
            "name": COMPANION_ATTRIBUTES[k]["name"],
            "emoji": COMPANION_ATTRIBUTES[k]["emoji"],
            "value": v,
        }
        for k, v in ranked if v > 0
    ]


def companion_prompt_snippet(companion: Optional[dict]) -> str:
    """Optional AI prompt block — companion flavor in stories."""
    c = normalize_companion(companion)
    if attribute_totals(c) < 2:
        return ""
    tops = top_attributes(c, 2)
    if not tops:
        return ""
    traits = ", ".join(f"{t['emoji']} {t['name']}" for t in tops)
    return (
        f"\n\nCOMPANION ({c['emoji']} {c['name']}): "
        f"This learner's story companion is growing in {traits}. "
        f"Mention the companion occasionally as a brave story ally — "
        f"never as a label for the child."
    )
