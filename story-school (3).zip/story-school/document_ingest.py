"""Server-side text extraction for uploaded documents.

StorySchool lets a learner upload their own chapter or question bank and have the
LLM act on it. The AI provider layer is strictly text-only (see ``ai_config.py``),
so we extract plain text here and pass it as an ordinary message ``content`` — no
multimodal / file-upload retrofit is involved.

Supported inputs: ``.txt`` (stdlib), ``.pdf`` (``pypdf``), ``.docx`` (``python-docx``).
The vendor parsers are imported lazily inside each branch so that a ``.txt`` upload
(and importing this module) never requires them.

Everything here is pure/offline — no network, no API calls — so it is trivially testable.
"""

import re
from io import BytesIO

# Extensions we accept. Anything else is rejected with a clear error.
ALLOWED_EXTS = {".pdf", ".docx", ".txt"}

# Reject oversized uploads before we even try to parse them (~5 MB).
MAX_UPLOAD_BYTES = 5 * 1024 * 1024

# Cap the text we feed the model, matching the app's existing ``.strip()[:N]``
# slicing convention for pasted/free-form content.
MAX_CHARS = 12_000


def file_ext(filename: str) -> str:
    """Return the lowercased extension (including the dot), or "" if none."""
    name = (filename or "").strip().lower()
    dot = name.rfind(".")
    return name[dot:] if dot != -1 else ""


def _extract_txt(data: bytes) -> str:
    return data.decode("utf-8", errors="replace")


def _extract_pdf(data: bytes) -> str:
    import pypdf  # lazy: only needed for PDF uploads

    reader = pypdf.PdfReader(BytesIO(data))
    parts: list[str] = []
    for page in reader.pages:
        try:
            parts.append(page.extract_text() or "")
        except Exception:
            # A single unreadable page shouldn't sink the whole document.
            continue
    return "\n".join(parts)


def _extract_docx(data: bytes) -> str:
    import docx  # python-docx; lazy: only needed for DOCX uploads

    document = docx.Document(BytesIO(data))
    parts: list[str] = [p.text for p in document.paragraphs]
    # Question banks are often laid out in tables — pull that text in too.
    for table in document.tables:
        for row in table.rows:
            for cell in row.cells:
                if cell.text:
                    parts.append(cell.text)
    return "\n".join(parts)


def extract_text(filename: str, data: bytes) -> str:
    """Extract raw text from an uploaded document, dispatching by extension.

    Raises ``ValueError`` for an unsupported extension. Parser errors (corrupt /
    encrypted files) propagate as the vendor library's own exception so the caller
    can turn them into a 400. May legitimately return "" (e.g. a scanned PDF with no
    text layer); the caller should treat empty extraction as an error.
    """
    ext = file_ext(filename)
    if ext == ".txt":
        return _extract_txt(data)
    if ext == ".pdf":
        return _extract_pdf(data)
    if ext == ".docx":
        return _extract_docx(data)
    raise ValueError(f"Unsupported file type: {ext or filename!r}")


_HWS_RUN = re.compile(r"[ \t\f\v]+")   # runs of horizontal whitespace
_BLANK_RUN = re.compile(r"\n{3,}")     # 3+ newlines -> one blank line


def clean_text(s: str) -> str:
    """Normalise extracted text and truncate to ``MAX_CHARS``.

    Collapses horizontal whitespace, trims each line, squeezes long runs of blank
    lines, strips, then slices to the char cap. Extraction tends to be noisy
    (page breaks, stray spaces); this keeps the prompt compact and consistent.
    """
    if not s:
        return ""
    s = s.replace("\r\n", "\n").replace("\r", "\n")
    s = _HWS_RUN.sub(" ", s)
    s = "\n".join(line.strip() for line in s.split("\n"))
    s = _BLANK_RUN.sub("\n\n", s)
    return s.strip()[:MAX_CHARS]
