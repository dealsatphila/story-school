"""Emotional engagement — story hooks without manipulative mechanics."""

from __future__ import annotations

from typing import Optional

EMOTIONAL_HOOKS: dict[str, dict[str, str]] = {
    "curiosity": {
        "name": "Curiosity",
        "emoji": "🔍",
        "technique": "Open with a question, puzzle, or 'what if' the reader wants answered.",
    },
    "mystery": {
        "name": "Mystery",
        "emoji": "🌫️",
        "technique": "A gentle clue or secret to uncover — never scary or anxiety-inducing.",
    },
    "humor": {
        "name": "Humor",
        "emoji": "😄",
        "technique": "Warm jokes and wordplay that help memory, never mock the learner.",
    },
    "surprise": {
        "name": "Surprise",
        "emoji": "✨",
        "technique": "Delightful twists that reframe the topic in a memorable way.",
    },
    "discovery": {
        "name": "Discovery",
        "emoji": "🗺️",
        "technique": "Let the hero (and reader) find the idea themselves through exploration.",
    },
    "achievement": {
        "name": "Achievement",
        "emoji": "🏅",
        "technique": "Celebrate small wins inside the story — effort matters more than perfection.",
    },
    "friendship": {
        "name": "Friendship",
        "emoji": "🤝",
        "technique": "Allies who help, disagree kindly, and grow together.",
    },
    "empathy": {
        "name": "Empathy",
        "emoji": "💛",
        "technique": "Characters notice feelings and care for others — link to real-world kindness.",
    },
    "responsibility": {
        "name": "Responsibility",
        "emoji": "🌱",
        "technique": "Choices with caring consequences — stewardship, not guilt.",
    },
    "adventure": {
        "name": "Adventure",
        "emoji": "⚔️",
        "technique": "Forward motion, quests, and brave steps — excitement without danger for its own sake.",
    },
}

DEFAULT_STORY_HOOKS = (
    "curiosity", "humor", "discovery", "achievement", "adventure",
)

GENRE_HOOK_EMPHASIS: dict[str, list[str]] = {
    "mystery": ["mystery", "curiosity", "surprise"],
    "fantasy": ["adventure", "discovery", "friendship"],
    "sci_fi": ["curiosity", "surprise", "discovery"],
    "animals": ["empathy", "friendship", "humor"],
    "realistic": ["empathy", "responsibility", "achievement"],
    "historical": ["discovery", "responsibility", "curiosity"],
    "novel_inspired": ["adventure", "empathy", "surprise"],
}

ETHICAL_ENGAGEMENT_RULES = """
EMOTIONAL ENGAGEMENT (ethical):
- Create genuine curiosity, wonder, laughter, and pride in learning.
- Use mystery and surprise to make ideas memorable — never to frighten or shame.
- Celebrate effort, teamwork, and kindness inside the narrative.
- End on hope, competence, or a warm laugh — not cliffhanger anxiety.

NEVER use manipulative patterns:
- No guilt trips ("you'll fall behind", "everyone else is ahead").
- No fear of losing streaks, coins, or progress as motivation.
- No artificial urgency timers or "come back or lose X" framing.
- No shame for wrong answers — mistakes are part of the adventure.
- No gambling-style variable rewards or pressure to grind.
"""


def hooks_for_context(genre_key: str = "realistic", extra: Optional[list[str]] = None) -> list[str]:
    emphasis = list(GENRE_HOOK_EMPHASIS.get(genre_key, []))
    for h in DEFAULT_STORY_HOOKS:
        if h not in emphasis:
            emphasis.append(h)
    if extra:
        for h in extra:
            if h in EMOTIONAL_HOOKS and h not in emphasis:
                emphasis.insert(0, h)
    return emphasis[:6]


def emotional_engagement_prompt_block(
    genre_key: str = "realistic",
    *,
    hooks: Optional[list[str]] = None,
) -> str:
    active = hooks or hooks_for_context(genre_key)
    lines = [ETHICAL_ENGAGEMENT_RULES.strip(), "", "EMOTIONAL HOOKS to weave naturally (pick 3–4):"]
    for key in active:
        meta = EMOTIONAL_HOOKS.get(key)
        if meta:
            lines.append(f"- {meta['emoji']} {meta['name']}: {meta['technique']}")
    lines.append(
        "\nBalance hooks with calm pacing — one strong moment beats ten loud ones."
    )
    return "\n".join(lines) + "\n"


def engagement_catalog() -> dict:
    return {
        "hooks": [{"id": k, **v} for k, v in EMOTIONAL_HOOKS.items()],
        "ethical_principles": [
            "Celebrate learning, never punish absence",
            "No fear of losing rewards or streaks",
            "Mistakes are safe and instructive",
            "Humor serves understanding",
            "Emotional hooks support memory — not addiction",
        ],
        "avoid": [
            "Streak-loss anxiety",
            "Guilt-based return prompts",
            "Punitive gate messaging",
            "Shame for wrong answers",
            "Artificial scarcity or FOMO",
        ],
        "default_hooks": list(DEFAULT_STORY_HOOKS),
    }


def soft_streak_message(consecutive_days: int, *, returning_after_gap: bool = False) -> str:
    if returning_after_gap:
        return "Welcome back! Your stories and progress are still here. 🌟"
    if consecutive_days <= 1:
        return "Great to see you learning today!"
    if consecutive_days < 7:
        return f"You've learned {consecutive_days} days in a row — nice rhythm!"
    return f"{consecutive_days} days of curiosity — keep exploring at your pace!"


def soft_gate_fail_message(pass_pct: int = 80) -> str:
    return (
        f"Scholar checkpoint: {pass_pct}% to unlock the next topics. "
        "Review stories and try again whenever you're ready — no rush."
    )


def supportive_wrong_answer_message() -> str:
    return "Almost! Every try teaches something new. 🌱"
