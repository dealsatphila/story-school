"""Phase 1 gamification — explorer ranks, rewards, and unlock catalog."""

from __future__ import annotations

EXPLORER_RANKS: list[dict] = [
    {"min_level": 1, "name": "Curious Reader"},
    {"min_level": 3, "name": "Story Scout"},
    {"min_level": 5, "name": "Adventure Seeker"},
    {"min_level": 7, "name": "Explorer"},
    {"min_level": 10, "name": "Trailblazer"},
    {"min_level": 15, "name": "Legend"},
    {"min_level": 20, "name": "Grand Explorer"},
]

UNLOCK_CATALOG: list[dict] = [
    {"id": "meadow_start", "type": "location", "emoji": "🌼", "name": "Sunny Meadow", "min_level": 1},
    {"id": "crystal_forest", "type": "location", "emoji": "🌲", "name": "Crystal Forest", "min_level": 3},
    {"id": "owl_guide", "type": "character", "emoji": "🦉", "name": "Wise Owl", "min_level": 2},
    {"id": "captain_nova", "type": "character", "emoji": "🧑‍🚀", "name": "Captain Nova", "min_level": 5},
    {"id": "star_cape", "type": "accessory", "emoji": "⭐", "name": "Star Cape", "min_level": 7},
    {"id": "sky_docks", "type": "location", "emoji": "☁️", "name": "Sky Docks", "min_level": 8},
    {"id": "chapter_sky", "type": "chapter", "emoji": "📜", "name": "Sky Kingdom Chapter", "min_level": 10},
    {"id": "moon_goggles", "type": "accessory", "emoji": "🥽", "name": "Moon Goggles", "min_level": 12},
    {"id": "dragon_friend", "type": "character", "emoji": "🐉", "name": "Ember the Dragon", "min_level": 15},
]

REWARD_DEFAULTS = {
    "story": {"coins": 5, "story_points": 10, "stars": 1},
    "quiz_bronze": {"coins": 8, "story_points": 5, "stars": 1},
    "quiz_silver": {"coins": 12, "story_points": 8, "stars": 2},
    "quiz_gold": {"coins": 18, "story_points": 12, "stars": 3},
    "story_world": {"coins": 15, "story_points": 25, "stars": 2},
    "adventure": {"coins": 10, "story_points": 20, "stars": 2},
    "gate_pass": {"coins": 25, "story_points": 15, "stars": 3},
    "challenge": {"coins": 6, "story_points": 8, "stars": 1},
}


def explorer_rank_name(level: int) -> str:
    name = EXPLORER_RANKS[0]["name"]
    for rank in EXPLORER_RANKS:
        if level >= rank["min_level"]:
            name = rank["name"]
    return name


def explorer_headline(level: int) -> str:
    return f"⭐ {explorer_rank_name(level)} Level {level}"


def unlocks_for_level(level: int) -> list[dict]:
    return [u for u in UNLOCK_CATALOG if u["min_level"] == level]


def gamification_catalog() -> dict:
    return {
        "explorer_ranks": EXPLORER_RANKS,
        "unlocks": UNLOCK_CATALOG,
        "reward_defaults": REWARD_DEFAULTS,
        "currencies": ["xp", "stars", "coins", "story_points"],
        "unlock_types": ["location", "character", "accessory", "chapter", "badge"],
    }


def quiz_tier_message(tier: str) -> str:
    messages = {
        "gold": "🔓 Golden Scholar path unlocked!",
        "silver": "🔓 Silver Trail discovered!",
        "bronze": "🔓 Bronze Path opened — keep exploring!",
    }
    return messages.get(tier, "🔓 New story paths await!")


def gate_pass_message(subject: str = "") -> str:
    subj = f" in {subject}" if subject else ""
    return f"🔓 New topics unlocked{subj}!"


def gate_fail_message(pass_pct: int = 80) -> str:
    from emotional_engagement import soft_gate_fail_message
    return soft_gate_fail_message(pass_pct)


def quiz_celebration_subtext(score: int, total: int) -> str:
    return f"{score} of {total} challenges conquered"
