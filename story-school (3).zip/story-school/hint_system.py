"""Progressive hint system — 5 escalating levels that reward persistence."""

from __future__ import annotations

import re
from typing import Any, Optional

from story_challenges import get_interaction, normalize_challenge

HINT_LEVELS: list[dict[str, Any]] = [
    {"level": 1, "name": "Small clue", "emoji": "🔎", "description": "A gentle nudge"},
    {"level": 2, "name": "Clearer clue", "emoji": "💡", "description": "More explicit direction"},
    {"level": 3, "name": "Worked example", "emoji": "📎", "description": "A similar problem"},
    {"level": 4, "name": "Step-by-step", "emoji": "🪜", "description": "Walk through the method"},
    {"level": 5, "name": "Answer + explanation", "emoji": "✅", "description": "Full solution"},
]

MAX_HINT_LEVEL = 5

PERSISTENCE_NUDGES = [
    "Try this clue first — you've got this! 🦊",
    "Give it another go before the next hint!",
    "Persistence beats guessing — what can you try now?",
    "One more attempt? You're closer than you think!",
    "Now you can check your work and learn the full method.",
]


def hint_catalog() -> dict:
    return {
        "max_level": MAX_HINT_LEVEL,
        "levels": HINT_LEVELS,
        "philosophy": (
            "Hints escalate gradually so learners build problem-solving stamina "
            "instead of jumping to answers."
        ),
    }


def _answer_text(challenge: dict) -> str:
    interaction = get_interaction(challenge)
    if interaction == "mcq":
        opts = challenge.get("options") or []
        idx = int(challenge.get("correct_index", -1))
        if 0 <= idx < len(opts):
            return str(opts[idx]).strip()
    ans = (challenge.get("correct_answer") or "").strip()
    if ans:
        return ans
    if interaction == "matching":
        pairs = challenge.get("pairs") or []
        return "; ".join(f"{p.get('left')} → {p.get('right')}" for p in pairs[:4])
    if interaction == "ordering":
        items = challenge.get("order_items") or []
        order = challenge.get("correct_order") or []
        return " → ".join(str(items[i]) for i in order if i < len(items))
    return ""


def _mcq_wrong_options(challenge: dict, n: int = 2) -> list[str]:
    opts = challenge.get("options") or []
    correct_idx = int(challenge.get("correct_index", -1))
    wrong = [opts[i] for i in range(len(opts)) if i != correct_idx and opts[i]]
    return wrong[:n]


def _steps_from_explanation(text: str) -> list[str]:
    if not text:
        return []
    parts = re.split(r"(?<=[.!?])\s+|\n+", text.strip())
    parts = [p.strip() for p in parts if p.strip()]
    if len(parts) >= 2:
        return parts
    return [text.strip()] if text.strip() else []


def synthesize_progressive_hints(challenge: dict) -> list[str]:
    """Build five escalating hints from challenge fields (or use stored progressive_hints)."""
    ch = normalize_challenge(challenge)
    stored = ch.get("progressive_hints") or []
    if isinstance(stored, list) and len(stored) >= 5:
        cleaned = [str(s).strip() for s in stored[:5]]
        if all(cleaned):
            return cleaned

    question = (ch.get("question") or "").strip()
    hint = (ch.get("hint") or "").strip()
    explanation = (ch.get("explanation") or "").strip()
    keywords = [k.strip() for k in (ch.get("keywords") or []) if k and str(k).strip()]
    interaction = get_interaction(ch)
    answer = _answer_text(ch)

    # Level 1 — small clue
    if hint:
        level1 = hint
    elif keywords:
        level1 = f"Sniff out these ideas: {', '.join(keywords[:2])}."
    else:
        level1 = "What do you already know? Read the question once more — what's it really asking?"

    # Level 2 — more explicit
    if interaction == "mcq":
        wrong = _mcq_wrong_options(ch)
        if wrong:
            level2 = (
                f"It's probably not «{wrong[0]}»"
                + (f" or «{wrong[1]}»" if len(wrong) > 1 else "")
                + ". Which ideas still fit the question?"
            )
        else:
            level2 = "Cross out options that don't match the story or the topic."
    elif interaction == "numeric":
        level2 = "What maths operation could turn the numbers in the question into an answer?"
    elif keywords:
        level2 = f"Focus on: {', '.join(keywords)}. How do they connect?"
    elif explanation:
        level2 = f"Bigger clue: {explanation[:120]}{'…' if len(explanation) > 120 else ''}"
    else:
        level2 = "Break the problem into two smaller parts. Solve the first part first."

    # Level 3 — worked example
    category = (ch.get("category") or "this topic").replace("_", " ")
    if interaction == "numeric" and answer:
        level3 = (
            f"Worked example (different numbers): If the question were similar but simpler, "
            f"you'd use the same method as for {category} problems — then apply it here."
        )
    elif explanation:
        level3 = (
            f"Imagine a similar {category} puzzle: {explanation[:150]}"
            f"{'…' if len(explanation) > 150 else ''} "
            f"Now try the same thinking on your question."
        )
    else:
        level3 = (
            f"Picture a simpler version of this {category} problem. "
            f"How would you solve that? Use the same steps here."
        )

    # Level 4 — step-by-step
    steps = _steps_from_explanation(explanation)
    if len(steps) >= 2:
        level4 = "Step by step:\n" + "\n".join(
            f"{i + 1}. {s}" for i, s in enumerate(steps[:5])
        )
    elif explanation:
        level4 = f"Walk through it:\n1. Read the question carefully.\n2. {explanation}\n3. Check your answer makes sense."
    elif interaction == "mcq":
        level4 = (
            "Step by step:\n1. Restate the question in your own words.\n"
            "2. Eliminate options that cannot be true.\n"
            "3. Pick the best match among what's left."
        )
    else:
        level4 = (
            "Step by step:\n1. What is given?\n2. What do you need to find?\n"
            "3. What method links them?\n4. Solve and check."
        )

    # Level 5 — answer + explanation
    if answer and explanation:
        level5 = f"Answer: **{answer}**\n\n{explanation}"
    elif answer:
        level5 = f"Answer: **{answer}**\n\nNow see if you can explain *why* that's correct."
    elif explanation:
        level5 = f"Solution: {explanation}"
    else:
        level5 = "Review the step-by-step hint above — the answer follows that same path."

    return [level1, level2, level3, level4, level5]


def finn_opener_for_level(level: int) -> str:
    openers = {
        1: "Hmm… let's think about this together. Here's a small clue:",
        2: "Good persistence! 🦊 This clue is a bit clearer:",
        3: "Nice effort — here's a worked example to learn from:",
        4: "You're really sticking with it! Walk through these steps:",
        5: "You earned the full walkthrough. Here's the answer and why:",
    }
    return openers.get(level, openers[1])


def reveal_hint(challenge: dict, level: int) -> dict[str, Any]:
    """Return hint payload for a given level (1–5)."""
    level = max(1, min(MAX_HINT_LEVEL, int(level)))
    hints = synthesize_progressive_hints(challenge)
    meta = HINT_LEVELS[level - 1]
    text = hints[level - 1]
    opener = finn_opener_for_level(level)

    return {
        "level": level,
        "max_level": MAX_HINT_LEVEL,
        "name": meta["name"],
        "emoji": meta["emoji"],
        "description": meta["description"],
        "text": text,
        "finn_opener": opener,
        "finn_message": f"{opener}\n\n{text}",
        "next_level": level + 1 if level < MAX_HINT_LEVEL else None,
        "levels_unlocked": list(range(1, level + 1)),
        "persistence_nudge": PERSISTENCE_NUDGES[min(level - 1, len(PERSISTENCE_NUDGES) - 1)],
        "reveals_answer": level >= 5,
    }


def quiz_question_to_challenge(question: dict) -> dict:
    """Adapt a quiz question dict to challenge shape for hint synthesis."""
    return normalize_challenge({
        "type": "mcq",
        "activity_type": "mcq",
        "category": "reasoning",
        "question": question.get("question", ""),
        "hint": question.get("hint", ""),
        "explanation": question.get("explanation", ""),
        "options": question.get("options", ["", "", "", ""]),
        "correct_index": question.get("correct_index", -1),
        "correct_answer": "",
        "progressive_hints": question.get("progressive_hints") or [],
    })


def strip_hints_for_client(challenge: dict) -> dict:
    """Remove progressive_hints from client-bound challenge copies."""
    ch = dict(challenge)
    ch.pop("progressive_hints", None)
    return ch
