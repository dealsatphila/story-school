"""Child Interest Engine — preference model from explicit profile + behavior."""

from __future__ import annotations

import copy
import json
import re
import time
from typing import Any, Optional

from story_challenges import ACTIVITY_CATALOG

# Story themes learners can favor (explicit + inferred)
STORY_THEMES: dict[str, dict[str, str]] = {
    "space": {"name": "Space", "emoji": "🚀"},
    "dinosaurs": {"name": "Dinosaurs", "emoji": "🦕"},
    "animals": {"name": "Animals", "emoji": "🐾"},
    "magic": {"name": "Magic", "emoji": "✨"},
    "princesses": {"name": "Princesses", "emoji": "👑"},
    "superheroes": {"name": "Superheroes", "emoji": "🦸"},
    "mystery": {"name": "Mystery", "emoji": "🔍"},
    "adventure": {"name": "Adventure", "emoji": "🗺️"},
    "pirates": {"name": "Pirates", "emoji": "🏴‍☠️"},
    "ocean": {"name": "Ocean", "emoji": "🌊"},
    "science": {"name": "Science", "emoji": "🔬"},
    "sports": {"name": "Sports", "emoji": "⚽"},
    "history": {"name": "History", "emoji": "📜"},
    "fantasy": {"name": "Fantasy", "emoji": "🧙"},
    "nature": {"name": "Nature", "emoji": "🌿"},
    "robots": {"name": "Robots", "emoji": "🤖"},
    "time_travel": {"name": "Time Travel", "emoji": "⏳"},
}

# Genre keys (story types) -> related theme ids for inference
GENRE_THEME_LINKS: dict[str, list[str]] = {
    "animals": ["animals", "nature"],
    "indian_mythology": ["history", "fantasy", "magic"],
    "western_mythology": ["history", "fantasy", "adventure"],
    "realistic": ["sports", "science"],
    "anime": ["adventure", "superheroes"],
    "documentary": ["science", "nature", "animals"],
    "novel_inspired": ["adventure", "fantasy"],
    "scifi": ["space", "robots", "science", "time_travel"],
    "fantasy": ["magic", "fantasy", "princesses"],
    "detective": ["mystery", "adventure"],
    "superhero": ["superheroes", "adventure"],
}

THEME_KEYWORDS: dict[str, tuple[str, ...]] = {
    "space": ("space", "rocket", "planet", "astronaut", "galaxy"),
    "dinosaurs": ("dinosaur", "dino", "jurassic", "fossil"),
    "animals": ("animal", "zoo", "wildlife", "pet"),
    "magic": ("magic", "wizard", "spell", "enchant"),
    "princesses": ("princess", "prince", "castle", "crown"),
    "superheroes": ("superhero", "hero", "cape", "marvel"),
    "mystery": ("mystery", "detective", "clue", "secret"),
    "adventure": ("adventure", "quest", "journey", "explore"),
    "pirates": ("pirate", "ship", "treasure", "sail"),
    "ocean": ("ocean", "sea", "marine", "coral", "fish"),
    "science": ("science", "lab", "experiment", "scientist"),
    "sports": ("sport", "cricket", "football", "basketball", "game"),
    "history": ("history", "ancient", "empire", "past"),
    "fantasy": ("fantasy", "dragon", "elf", "realm"),
    "nature": ("nature", "forest", "tree", "garden"),
    "robots": ("robot", "android", "machine", "ai"),
    "time_travel": ("time travel", "time machine", "future", "past"),
}

WEIGHT_KEYS = (
    "favorite_subjects",
    "favorite_characters",
    "favorite_themes",
    "favorite_story_types",
    "favorite_activity_types",
)


def default_preferences() -> dict:
    return {
        "favorite_subjects": {},
        "favorite_characters": {},
        "favorite_themes": {},
        "favorite_story_types": {},
        "favorite_activity_types": {},
        "preferred_difficulty": "medium",
        "reading_preferences": {
            "reading_level": "grade_level",
            "pace": "normal",
        },
        "audio_preferences": {
            "narration": True,
            "music": True,
            "sfx": True,
        },
        "explicit_themes": [],
        "explicit_story_types": [],
        "updated_at": time.time(),
    }


def init_interest_tables(conn) -> None:
    conn.execute("""
        CREATE TABLE IF NOT EXISTS interest_preferences (
            learner_id TEXT PRIMARY KEY,
            prefs_json TEXT NOT NULL,
            updated_at REAL
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS interest_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            learner_id TEXT NOT NULL,
            event_type TEXT NOT NULL,
            payload_json TEXT,
            created_at REAL
        )
    """)
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_interest_events_learner "
        "ON interest_events(learner_id, created_at)"
    )


def _norm_key(text: str) -> str:
    return re.sub(r"\s+", "_", str(text or "").strip().lower())[:60]


def _bump(weights: dict[str, float], key: str, amount: float = 1.0) -> None:
    if not key:
        return
    k = _norm_key(key)
    weights[k] = min(100.0, weights.get(k, 0) + amount)


def infer_themes_from_text(*texts: str) -> list[str]:
    blob = " ".join(t for t in texts if t).lower()
    found = []
    for theme_id, keywords in THEME_KEYWORDS.items():
        if any(kw in blob for kw in keywords):
            found.append(theme_id)
    return found


def merge_explicit_from_profile(prefs: dict, profile: Optional[dict]) -> dict:
    """Apply child profile fields as strong explicit signals."""
    out = copy.deepcopy(prefs)
    if not profile:
        return out

    p = profile
    for subj in p.get("interests") or []:
        for theme_id in infer_themes_from_text(subj):
            _bump(out["favorite_themes"], theme_id, 2.0)
        _bump(out["favorite_subjects"], subj, 0.5)

    for char in p.get("favorite_characters") or []:
        _bump(out["favorite_characters"], char, 3.0)

    for animal in p.get("favorite_animals") or []:
        _bump(out["favorite_themes"], "animals", 2.0)
        _bump(out["favorite_characters"], animal, 1.5)

    for item in p.get("favorite_colors_themes") or []:
        for theme_id in infer_themes_from_text(item):
            _bump(out["favorite_themes"], theme_id, 2.5)
        if not infer_themes_from_text(item):
            _bump(out["favorite_themes"], _norm_key(item), 1.0)

    for theme_id in p.get("favorite_themes") or []:
        tid = _norm_key(theme_id)
        if tid in STORY_THEMES:
            _bump(out["favorite_themes"], tid, 4.0)
            if tid not in out["explicit_themes"]:
                out["explicit_themes"].append(tid)

    for genre in p.get("favorite_story_types") or []:
        gid = _norm_key(genre)
        _bump(out["favorite_story_types"], gid, 4.0)
        if gid not in out["explicit_story_types"]:
            out["explicit_story_types"].append(gid)
        for linked in GENRE_THEME_LINKS.get(gid, []):
            _bump(out["favorite_themes"], linked, 1.5)

    for act in p.get("favorite_activity_types") or []:
        _bump(out["favorite_activity_types"], act, 3.0)

    if p.get("reading_level"):
        out["reading_preferences"]["reading_level"] = p["reading_level"]

    if p.get("preferred_difficulty"):
        out["preferred_difficulty"] = p["preferred_difficulty"]

    audio = out["audio_preferences"]
    if "audio_narration" in p:
        audio["narration"] = bool(p["audio_narration"])
    if "audio_music" in p:
        audio["music"] = bool(p["audio_music"])
    if "audio_sfx" in p:
        audio["sfx"] = bool(p["audio_sfx"])

    return out


def apply_event(prefs: dict, event_type: str, payload: Optional[dict] = None) -> dict:
    out = copy.deepcopy(prefs)
    p = payload or {}

    if event_type == "subject_pick":
        _bump(out["favorite_subjects"], p.get("subject", ""), 2.0)
    elif event_type == "genre_pick":
        genre = p.get("genre", "")
        _bump(out["favorite_story_types"], genre, 3.0)
        for theme_id in GENRE_THEME_LINKS.get(genre, []):
            _bump(out["favorite_themes"], theme_id, 1.5)
    elif event_type == "theme_pick":
        for theme_id in p.get("themes") or []:
            if theme_id in STORY_THEMES:
                _bump(out["favorite_themes"], theme_id, 4.0)
    elif event_type == "character_met":
        _bump(out["favorite_characters"], p.get("character", ""), 2.0)
    elif event_type == "activity_complete":
        _bump(out["favorite_activity_types"], p.get("activity_type", ""), 2.5)
    elif event_type == "story_complete":
        _bump(out["favorite_story_types"], p.get("genre", ""), 1.5)
        _bump(out["favorite_subjects"], p.get("subject", ""), 1.0)
        for theme_id in infer_themes_from_text(p.get("topic", "")):
            _bump(out["favorite_themes"], theme_id, 1.0)
    elif event_type == "difficulty_set":
        diff = p.get("difficulty")
        if diff in ("easy", "medium", "hard"):
            out["preferred_difficulty"] = diff
    elif event_type == "reading_set":
        if p.get("reading_level"):
            out["reading_preferences"]["reading_level"] = p["reading_level"]
    elif event_type == "audio_set":
        audio = out["audio_preferences"]
        for key in ("narration", "music", "sfx"):
            if key in p:
                audio[key] = bool(p[key])
    elif event_type == "curiosity_explore":
        _bump(out["favorite_activity_types"], "exploration", 2.5)
        for theme_id in infer_themes_from_text(p.get("question", "") + " " + p.get("topic", "")):
            _bump(out["favorite_themes"], theme_id, 1.5)
    elif event_type == "story_created":
        _bump(out["favorite_activity_types"], "creative_writing", 3.0)
        _bump(out["favorite_story_types"], "fantasy", 1.0)
        for theme_id in infer_themes_from_text(p.get("topic", "")):
            _bump(out["favorite_themes"], theme_id, 1.0)
    elif event_type == "reflection":
        opt = p.get("option_id", "")
        if opt == "want_more":
            _bump(out["favorite_activity_types"], "exploration", 2.0)
        elif opt == "want_challenge":
            _bump(out["favorite_activity_types"], "quiz", 1.5)
        elif opt == "learned_new":
            _bump(out["favorite_subjects"], p.get("subject", ""), 1.5)

    out["updated_at"] = time.time()
    return out


def top_items(weights: dict[str, float], n: int = 5) -> list[dict]:
    ranked = sorted(weights.items(), key=lambda x: (-x[1], x[0]))[:n]
    return [{"id": k, "score": round(v, 2)} for k, v in ranked if v > 0]


def top_themes(prefs: dict, n: int = 5) -> list[dict]:
    items = top_items(prefs.get("favorite_themes") or {}, n)
    return [
        {**item, "name": STORY_THEMES.get(item["id"], {}).get("name", item["id"]),
         "emoji": STORY_THEMES.get(item["id"], {}).get("emoji", "✨")}
        for item in items
    ]


def recommend_genre(prefs: dict) -> Optional[str]:
    story_types = prefs.get("favorite_story_types") or {}
    if not story_types:
        themes = prefs.get("favorite_themes") or {}
        if themes:
            best_theme = max(themes, key=themes.get)
            for genre, links in GENRE_THEME_LINKS.items():
                if best_theme in links:
                    return genre
        return None
    return max(story_types, key=story_types.get)


def interest_summary(prefs: dict) -> str:
    themes = top_themes(prefs, 3)
    if not themes:
        return "Tell us what you love — we'll tailor every story!"
    parts = [f"{t['emoji']} {t['name']}" for t in themes]
    return " · ".join(parts)


def load_preferences(conn, learner_id: str, profile: Optional[dict] = None) -> dict:
    row = conn.execute(
        "SELECT prefs_json FROM interest_preferences WHERE learner_id = ?",
        (learner_id.strip(),),
    ).fetchone()
    if row:
        try:
            prefs = json.loads(row["prefs_json"])
        except json.JSONDecodeError:
            prefs = default_preferences()
    else:
        prefs = default_preferences()
    prefs = merge_explicit_from_profile(prefs, profile)
    return prefs


def save_preferences(conn, learner_id: str, prefs: dict) -> dict:
    now = time.time()
    prefs = copy.deepcopy(prefs)
    prefs["updated_at"] = now
    conn.execute(
        """
        INSERT INTO interest_preferences (learner_id, prefs_json, updated_at)
        VALUES (?, ?, ?)
        ON CONFLICT(learner_id) DO UPDATE SET
            prefs_json = excluded.prefs_json,
            updated_at = excluded.updated_at
        """,
        (learner_id.strip(), json.dumps(prefs), now),
    )
    return prefs


def sync_explicit_profile(conn, learner_id: str, profile: Optional[dict]) -> dict:
    """Refresh stored weights from explicit child profile fields."""
    prefs = load_preferences(conn, learner_id, profile=None)
    prefs = merge_explicit_from_profile(prefs, profile)
    return save_preferences(conn, learner_id, prefs)


def record_interest_event(
    conn,
    learner_id: str,
    event_type: str,
    payload: Optional[dict] = None,
    profile: Optional[dict] = None,
) -> dict:
    prefs = load_preferences(conn, learner_id, profile=None)
    prefs = apply_event(prefs, event_type, payload)
    prefs = merge_explicit_from_profile(prefs, profile)
    save_preferences(conn, learner_id, prefs)
    conn.execute(
        "INSERT INTO interest_events (learner_id, event_type, payload_json, created_at) VALUES (?, ?, ?, ?)",
        (learner_id.strip(), event_type, json.dumps(payload or {}), time.time()),
    )
    return prefs


def build_interest_model(conn, learner_id: str, profile: Optional[dict] = None) -> dict:
    prefs = load_preferences(conn, learner_id, profile)
    return {
        "preferences": prefs,
        "top_subjects": top_items(prefs.get("favorite_subjects") or {}, 5),
        "top_characters": top_items(prefs.get("favorite_characters") or {}, 5),
        "top_themes": top_themes(prefs, 6),
        "top_story_types": top_items(prefs.get("favorite_story_types") or {}, 5),
        "top_activity_types": top_items(prefs.get("favorite_activity_types") or {}, 5),
        "recommended_genre": recommend_genre(prefs),
        "summary": interest_summary(prefs),
        "preferred_difficulty": prefs.get("preferred_difficulty", "medium"),
        "reading_preferences": prefs.get("reading_preferences", {}),
        "audio_preferences": prefs.get("audio_preferences", {}),
    }


def interest_catalog() -> dict:
    return {
        "story_themes": [
            {"id": k, **v} for k, v in STORY_THEMES.items()
        ],
        "story_types": [
            {"id": "animals", "name": "Animal Kingdom", "emoji": "🐾"},
            {"id": "scifi", "name": "Sci-Fi", "emoji": "🚀"},
            {"id": "fantasy", "name": "Fantasy", "emoji": "🧙"},
            {"id": "superhero", "name": "Superhero", "emoji": "🦸"},
            {"id": "detective", "name": "Mystery", "emoji": "🔍"},
            {"id": "anime", "name": "Anime", "emoji": "🎌"},
            {"id": "realistic", "name": "School Life", "emoji": "🏫"},
            {"id": "indian_mythology", "name": "Indian Mythology", "emoji": "🕉️"},
            {"id": "adventure", "name": "Adventure", "emoji": "🗺️"},
        ],
        "activity_types": [
            {"id": k, "label": v["label"], "category": v["category"]}
            for k, v in sorted(ACTIVITY_CATALOG.items(), key=lambda x: x[1]["label"])
        ][:12],
        "reading_levels": ["beginner", "developing", "grade_level", "advanced", "fluent"],
        "difficulties": ["easy", "medium", "hard"],
    }


def interest_prompt_block(model: Optional[dict]) -> str:
    if not model:
        return ""
    prefs = model.get("preferences") if "preferences" in model else model
    if not prefs:
        return ""

    themes = top_themes(prefs, 4)
    chars = top_items(prefs.get("favorite_characters") or {}, 4)
    subjects = top_items(prefs.get("favorite_subjects") or {}, 3)
    story_types = top_items(prefs.get("favorite_story_types") or {}, 3)
    activities = top_items(prefs.get("favorite_activity_types") or {}, 3)

    if not (themes or chars or subjects or story_types):
        return ""

    lines = ["\n\nCHILD INTEREST ENGINE — lean into what this learner loves:"]
    if themes:
        lines.append(
            "- Favorite themes: "
            + ", ".join(f"{t['emoji']} {t['name']}" for t in themes)
            + ". Set mood, setting, and metaphors here."
        )
    if story_types:
        labels = [s["id"].replace("_", " ") for s in story_types]
        lines.append(f"- Preferred story types / genres: {', '.join(labels)}.")
    if chars:
        lines.append(
            "- Favorite characters & mascots (inspire originals, no copyright): "
            + ", ".join(c["id"].replace("_", " ") for c in chars)
            + "."
        )
    if subjects:
        lines.append(
            "- Favorite subjects (extra enthusiasm when teaching these): "
            + ", ".join(s["id"].replace("_", " ") for s in subjects)
            + "."
        )
    if activities:
        lines.append(
            "- Enjoys these challenge styles in Story World: "
            + ", ".join(a["id"].replace("_", " ") for a in activities)
            + "."
        )

    diff = prefs.get("preferred_difficulty")
    if diff:
        lines.append(f"- Preferred challenge level: {diff}.")
    reading = prefs.get("reading_preferences") or {}
    if reading.get("reading_level"):
        lines.append(f"- Reading preference: {reading['reading_level']}.")

    audio = prefs.get("audio_preferences") or {}
    if audio.get("narration"):
        lines.append("- They like read-aloud / narration — use rhythmic, speakable prose.")

    lines.append(
        "Weave interests into plot and examples naturally — never list them mechanically."
    )
    return "\n".join(lines)
