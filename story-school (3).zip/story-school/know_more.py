"""I Want to Know More — child-led curiosity paths during stories."""

from __future__ import annotations

import hashlib
import json
import re
import time
import uuid
from typing import Any, Optional

KNOW_MORE_MARKER_RE = re.compile(
    r"\{\{KNOW_MORE:\s*(.+?)\s*\}\}",
    re.IGNORECASE,
)

MAX_PATH_DEPTH = 6
MAX_SPARKS = 5


def know_more_catalog() -> dict:
    return {
        "name": "I Want to Know More",
        "emoji": "🔎",
        "description": (
            "During a story, wonder-spots invite the child to tap Tell me more "
            "and follow a gentle curiosity path — no quizzes, no pressure."
        ),
        "principles": [
            "Child chooses what to explore — never forced detours.",
            "Short, wonder-filled mini-lessons (not another full story).",
            "Each stop offers 2–3 optional next questions, like a friendly rabbit hole.",
            "No streaks, timers, or fear of missing out.",
            "Always easy to return to the main story.",
        ],
        "max_depth": MAX_PATH_DEPTH,
    }


def extract_sparks_from_story(story_text: str) -> list[dict]:
    """Pull embedded {{KNOW_MORE: question}} markers from story markdown."""
    seen: set[str] = set()
    sparks: list[dict] = []
    for match in KNOW_MORE_MARKER_RE.finditer(story_text or ""):
        question = match.group(1).strip()
        key = question.lower()
        if not question or key in seen:
            continue
        seen.add(key)
        sparks.append({
            "id": f"spark_{len(sparks) + 1}",
            "question": question,
            "emoji": _guess_emoji(question),
        })
        if len(sparks) >= MAX_SPARKS:
            break
    return sparks


def strip_know_more_markers(story_text: str) -> str:
    return KNOW_MORE_MARKER_RE.sub("", story_text or "")


def _guess_emoji(text: str) -> str:
    t = text.lower()
    pairs = (
        ("dinosaur", "🦖"), ("extinct", "🦕"), ("asteroid", "☄️"),
        ("space", "🚀"), ("planet", "🪐"), ("solar", "☀️"),
        ("ocean", "🌊"), ("animal", "🐾"), ("plant", "🌱"),
        ("history", "📜"), ("math", "🔢"), ("fraction", "🍕"),
        ("water", "💧"), ("fire", "🔥"), ("earth", "🌍"),
        ("why", "🤔"), ("how", "🛠️"), ("who", "👤"),
    )
    for needle, emoji in pairs:
        if needle in t:
            return emoji
    return "✨"


def sparks_detect_prompt(grade: int, subject: str, topic: str) -> str:
    return f"""You find natural curiosity sparks inside a Grade {grade} story about {subject}: {topic}.

Return 3–4 short questions a child might wonder while reading — tied to the story, not generic trivia.
Each question should feel like "I want to know more!" — warm, specific, and age-appropriate.
Use an emoji that fits each question."""


def explore_prompt(
    grade: int,
    subject: str,
    topic: str,
    language_instruction: str,
    path: list[str],
    depth: int,
) -> str:
    path_line = " → ".join(path) if path else topic
    return f"""You are Finn the Fox 🦊 guiding a Grade {grade} child's curiosity path.

CONTEXT: {subject} — {topic}
LANGUAGE: {language_instruction}
CURIOSITY PATH SO FAR: {path_line}
DEPTH: {depth} of {MAX_PATH_DEPTH}

Write a MINI EXPLORATION (not a full story):
- 120–200 words, warm and wonder-filled, grade-appropriate.
- Answer the child's question clearly with one vivid example or analogy.
- Include one "🤯 Did you know?" fun fact (short).
- End with genuine curiosity — the child chose to explore!
- Offer 2–3 follow-up questions the child might ask next (optional branches).
  Phrase them like "Want to learn about …?" — inviting, never pushy.
- If depth is {MAX_PATH_DEPTH}, omit follow_ups (path complete).

ETHICAL RULES:
- No guilt, no "you must learn this", no cliffhanger anxiety.
- Celebrate wondering; wrong guesses are welcome.
- Keep content safe and factual for CBSE Grade {grade}."""


def validate_sparks(data: Any) -> list[dict]:
    sparks = data.get("sparks") if isinstance(data, dict) else None
    if not isinstance(sparks, list):
        raise ValueError("sparks must be a list")
    out: list[dict] = []
    seen: set[str] = set()
    for i, raw in enumerate(sparks[:MAX_SPARKS]):
        if not isinstance(raw, dict):
            continue
        question = str(raw.get("question", "")).strip()
        if not question:
            continue
        key = question.lower()
        if key in seen:
            continue
        seen.add(key)
        emoji = str(raw.get("emoji", "")).strip() or _guess_emoji(question)
        out.append({"id": f"spark_{i + 1}", "question": question, "emoji": emoji})
    if len(out) < 2:
        raise ValueError("Need at least 2 curiosity sparks")
    return out


def validate_exploration(data: Any, question: str, depth: int) -> dict:
    if not isinstance(data, dict):
        raise ValueError("exploration must be an object")
    title = str(data.get("title", "")).strip() or question
    content = str(data.get("content", "")).strip()
    if not content:
        raise ValueError("exploration content required")
    fun_fact = str(data.get("fun_fact", "")).strip()
    emoji = str(data.get("emoji", "")).strip() or _guess_emoji(question)

    follow_ups: list[dict] = []
    if depth < MAX_PATH_DEPTH:
        for raw in data.get("follow_ups") or []:
            if not isinstance(raw, dict):
                continue
            fq = str(raw.get("question", "")).strip()
            if not fq:
                continue
            follow_ups.append({
                "question": fq,
                "emoji": str(raw.get("emoji", "")).strip() or _guess_emoji(fq),
                "preview": str(raw.get("preview", "")).strip()[:120],
            })
            if len(follow_ups) >= 3:
                break

    return {
        "question": question,
        "emoji": emoji,
        "title": title,
        "content": content,
        "fun_fact": fun_fact,
        "follow_ups": follow_ups,
        "depth": depth,
        "path_complete": depth >= MAX_PATH_DEPTH or not follow_ups,
    }


def exploration_cache_key(grade: int, question: str, path: list[str]) -> str:
    raw = f"{grade}|{question.strip().lower()}|{' > '.join(path)}"
    return hashlib.sha256(raw.encode()).hexdigest()[:32]


def init_know_more_tables(conn) -> None:
    conn.execute("""
        CREATE TABLE IF NOT EXISTS know_more_cache (
            cache_key TEXT PRIMARY KEY,
            grade INTEGER,
            question TEXT,
            response_json TEXT NOT NULL,
            created_at REAL,
            hits INTEGER DEFAULT 0
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS know_more_events (
            id TEXT PRIMARY KEY,
            learner_id TEXT NOT NULL,
            grade INTEGER,
            subject TEXT,
            topic TEXT,
            question TEXT,
            path_json TEXT,
            depth INTEGER,
            created_at REAL
        )
    """)
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_know_more_events_learner "
        "ON know_more_events(learner_id, created_at)"
    )


def get_cached_exploration(conn, cache_key: str) -> Optional[dict]:
    row = conn.execute(
        "SELECT response_json, hits FROM know_more_cache WHERE cache_key = ?",
        (cache_key,),
    ).fetchone()
    if not row:
        return None
    conn.execute(
        "UPDATE know_more_cache SET hits = hits + 1 WHERE cache_key = ?",
        (cache_key,),
    )
    return json.loads(row["response_json"])


def store_cached_exploration(
    conn, cache_key: str, grade: int, question: str, payload: dict,
) -> None:
    now = time.time()
    conn.execute(
        """
        INSERT INTO know_more_cache (cache_key, grade, question, response_json, created_at, hits)
        VALUES (?, ?, ?, ?, ?, 0)
        ON CONFLICT(cache_key) DO UPDATE SET
            response_json = excluded.response_json,
            created_at = excluded.created_at
        """,
        (cache_key, grade, question, json.dumps(payload), now),
    )


def record_exploration_event(
    conn,
    learner_id: str,
    grade: int,
    subject: str,
    topic: str,
    question: str,
    path: list[str],
    depth: int,
) -> str:
    event_id = uuid.uuid4().hex[:12]
    conn.execute(
        """
        INSERT INTO know_more_events
            (id, learner_id, grade, subject, topic, question, path_json, depth, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            event_id, learner_id.strip(), grade, subject, topic,
            question, json.dumps(path), depth, time.time(),
        ),
    )
    return event_id


def story_prompt_know_more_block() -> str:
    return """
CURIOSITY SPARKS (I Want to Know More):
- Embed exactly 3–4 wonder-spots using this EXACT format inline in the story
  (place them where a child might naturally wonder):
  {{KNOW_MORE: Why did dinosaurs become extinct?}}
- Questions must relate to the story moment and the school topic.
- Keep each question short, vivid, and genuinely interesting — not test questions.
- Do NOT explain the answer inside the marker; the child will explore separately."""


def merge_sparks(*lists: list[dict]) -> list[dict]:
    seen: set[str] = set()
    out: list[dict] = []
    for sparks in lists:
        for s in sparks:
            q = s.get("question", "").strip()
            key = q.lower()
            if not q or key in seen:
                continue
            seen.add(key)
            out.append(s)
            if len(out) >= MAX_SPARKS:
                return out
    return out
