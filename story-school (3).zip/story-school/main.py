import json
import logging
import os
import random
import sqlite3
import time
import uuid
from pathlib import Path
from typing import Any, Optional

import httpx
from fastapi import FastAPI, Request, Query, UploadFile, File, Form, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel

import document_ingest

from companion import (
    apply_companion_event,
    auto_unlock_eligible,
    build_companion_view,
    companion_catalog,
    companion_prompt_snippet,
    default_companion,
    equip_item,
    normalize_companion,
    purchase_unlock,
)
from choices_consequences import (
    adventure_choice_prompt_block,
    adventure_consequence_user_message,
    adventure_meta_prompt_block,
    catalog_for_api as choices_catalog,
    choice_prompt_block,
)
from child_profile import (
    READING_LEVELS,
    child_profile_prompt_block,
    default_child_profile,
    get_child_profile,
    normalize_child_profile,
    reading_level_instruction,
    save_child_profile,
)
from multimodal_learning import (
    build_writing_feedback,
    comprehension_reflection,
    default_multimodal_preferences,
    extract_vocabulary,
    multimodal_catalog,
    multimodal_prompt_block,
    normalize_multimodal_preferences,
)
from project_adventures import (
    build_project_view,
    complete_step,
    default_learner_projects,
    project_catalog,
    start_project,
    PROJECT_BY_ID,
)
from ncert import lookup_ncert_chapter, ncert_story_hint, ncert_grounding_context
from study_videos import (
    external_links_allowed,
    lookup_study_videos,
    study_videos_catalog,
)
from subject_gate import (
    GATE_PASS_PCT,
    GATE_QUESTION_COUNT,
    TOPICS_PER_BATCH,
    build_gate_status,
    gate_key,
    gate_ready_to_take,
    gates_required_before_topic,
    grade_gate_exam,
    is_gate_passed,
    new_exam_id,
    strip_exam_for_client,
    store_gate_result,
    topics_for_gate,
    topic_is_unlocked,
    validate_gate_questions,
)
from adaptive_learning import (
    adaptive_prompt_block,
    get_adaptive_status,
    load_concept_state,
    record_event,
    status_message,
)
from gamification import gamification_catalog
from interest_engine import (
    build_interest_model,
    interest_catalog,
    interest_prompt_block,
    record_interest_event,
    sync_explicit_profile,
)
from mistake_learning import (
    analyze_mistake,
    build_mini_practice,
    check_mini_practice,
    get_recovery,
    load_mini_practice,
    mark_mini_practice_done,
    record_wrong_attempt,
)
from parent_dashboard import build_parent_dashboard
from parent_controls import (
    build_progress_report,
    build_usage_status,
    controls_catalog,
    get_parent_controls,
    get_effective_difficulty,
    init_parent_tables,
    is_subject_allowed,
    parent_controls_prompt_block,
    record_session_minutes,
    save_parent_controls,
    sync_learning_goals_to_child,
    verify_parent_pin,
)
from accessibility import (
    accessibility_catalog,
    accessibility_prompt_block,
    body_classes_for_prefs,
    css_variables_for_prefs,
    effective_content_language,
    normalize_accessibility_preferences,
)
from assessment_engine import (
    assessment_catalog,
    build_learning_profile,
    init_assessment_tables,
    observe_gameplay,
)
from emotional_engagement import engagement_catalog, emotional_engagement_prompt_block
from reflection_system import (
    ACTIVITY_PROMPTS,
    finn_reflection_reply,
    init_reflection_tables,
    list_reflections,
    own_words_prompt,
    reflection_catalog,
    save_reflection,
    validate_option,
)
from child_story_creator import (
    builder_story_prompt,
    choices_summary,
    continue_story_prompt,
    creator_catalog,
    init_creator_tables,
    list_created_stories,
    save_created_story,
    validate_choices,
    validate_continued_story,
    validate_generated_story,
)
from know_more import (
    explore_prompt,
    exploration_cache_key,
    extract_sparks_from_story,
    get_cached_exploration,
    init_know_more_tables,
    know_more_catalog,
    merge_sparks,
    record_exploration_event,
    sparks_detect_prompt,
    story_prompt_know_more_block,
    store_cached_exploration,
    validate_exploration,
    validate_sparks,
)
from hint_system import (
    hint_catalog,
    quiz_question_to_challenge,
    reveal_hint,
)
from tutor_character import (
    FINN_STORY_WORLD_SNIPPET,
    coach_message,
    finn_catalog,
    finn_doubt_prompt,
)
from story_challenges import activity_catalog_for_api, get_interaction, normalize_challenge
from story_world import (
    apply_challenge_result,
    apply_choice,
    check_challenge_answer,
    default_progress,
    enrich_scene_for_playback,
    first_scene_id,
    get_ending,
    load_session,
    new_world_id,
    save_session,
    scene_by_id,
    strip_world_for_client,
    validate_world,
)
from spaced_rep import (
    INTERVALS_DAYS,
    count_due_items,
    list_all_items,
    list_due_items,
    make_item_key,
    question_identifier,
    upsert_spaced_item,
)
from syllabus import CBSE_SYLLABUS, DIFFICULTY_LEVELS, GENRES, LANGUAGES, SUBJECT_DISPLAY_ORDER
from ai_config import (
    complete_json,
    complete_text,
    configured_providers,
    current_model,
    current_provider_name,
    get_settings,
    provider_catalog,
    stream_text,
    update_settings,
    validate_active_provider,
)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="StorySchool 🎭")
templates = Jinja2Templates(directory="templates")


# ---------------------------------------------------------------------------
# SQLite cache for stories + flashcards — zero-cost instant repeats
# ---------------------------------------------------------------------------
CACHE_DB = Path(__file__).parent / "storyschool_cache.db"

def _get_conn():
    conn = sqlite3.connect(str(CACHE_DB))
    conn.row_factory = sqlite3.Row
    return conn

def init_cache():
    conn = _get_conn()
    try:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS story_cache (
                cache_key TEXT PRIMARY KEY,
                grade INTEGER,
                subject TEXT,
                topic TEXT,
                language TEXT,
                genre TEXT,
                novel_name TEXT,
                story TEXT,
                created_at REAL,
                accessed_at REAL,
                hits INTEGER DEFAULT 0
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS flashcard_cache (
                cache_key TEXT PRIMARY KEY,
                grade INTEGER,
                subject TEXT,
                topic TEXT,
                language TEXT,
                cards_json TEXT,
                created_at REAL,
                accessed_at REAL,
                hits INTEGER DEFAULT 0
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS mindmap_cache (
                cache_key TEXT PRIMARY KEY,
                grade INTEGER,
                subject TEXT,
                topic TEXT,
                language TEXT,
                diagram_json TEXT,
                created_at REAL,
                accessed_at REAL,
                hits INTEGER DEFAULT 0
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS quiz_cache (
                cache_key TEXT PRIMARY KEY,
                grade INTEGER,
                subject TEXT,
                topic TEXT,
                language TEXT,
                quiz_json TEXT,
                created_at REAL,
                accessed_at REAL,
                hits INTEGER DEFAULT 0
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS quiz_mastery (
                topic_key TEXT PRIMARY KEY,
                grade INTEGER,
                subject TEXT,
                topic TEXT,
                best_score INTEGER,
                best_total INTEGER,
                best_pct INTEGER,
                tier TEXT,
                updated_at REAL
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS learning_progress (
                learner_id TEXT NOT NULL,
                topic_key TEXT NOT NULL,
                grade INTEGER,
                subject TEXT,
                topic TEXT,
                difficulty TEXT DEFAULT 'medium',
                story_done INTEGER DEFAULT 0,
                mindmap_done INTEGER DEFAULT 0,
                flashcards_done INTEGER DEFAULT 0,
                quiz_done INTEGER DEFAULT 0,
                quiz_tier TEXT,
                quiz_pct INTEGER,
                updated_at REAL,
                PRIMARY KEY (learner_id, topic_key)
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS learner_profile (
                learner_id TEXT PRIMARY KEY,
                profile_json TEXT,
                updated_at REAL
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS child_profile (
                learner_id TEXT PRIMARY KEY,
                profile_json TEXT NOT NULL,
                updated_at REAL
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS spaced_items (
                learner_id TEXT NOT NULL,
                item_key TEXT NOT NULL,
                item_type TEXT NOT NULL,
                grade INTEGER,
                subject TEXT,
                topic TEXT,
                prompt TEXT,
                answer TEXT,
                extra_json TEXT,
                level INTEGER DEFAULT 0,
                due_at REAL NOT NULL,
                last_result TEXT,
                updated_at REAL,
                PRIMARY KEY (learner_id, item_key)
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_spaced_due ON spaced_items(learner_id, due_at)")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS subject_gate_results (
                learner_id TEXT NOT NULL,
                gate_key TEXT NOT NULL,
                grade INTEGER,
                subject TEXT,
                gate_num INTEGER,
                topics_json TEXT,
                score INTEGER,
                total INTEGER,
                pct INTEGER,
                passed INTEGER DEFAULT 0,
                updated_at REAL,
                PRIMARY KEY (learner_id, gate_key)
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS subject_gate_exams (
                exam_id TEXT PRIMARY KEY,
                learner_id TEXT NOT NULL,
                gate_key TEXT NOT NULL,
                exam_json TEXT NOT NULL,
                created_at REAL
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_gate_exam_learner ON subject_gate_exams(learner_id, gate_key)")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS story_world_sessions (
                world_id TEXT PRIMARY KEY,
                learner_id TEXT NOT NULL,
                cache_key TEXT,
                world_json TEXT NOT NULL,
                progress_json TEXT NOT NULL,
                created_at REAL,
                updated_at REAL
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_story_world_learner ON story_world_sessions(learner_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_flash_lookup ON flashcard_cache(grade, subject, topic, language)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_mindmap_lookup ON mindmap_cache(grade, subject, topic, language)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_quiz_lookup ON quiz_cache(grade, subject, topic, language)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_learning_progress_learner ON learning_progress(learner_id)")
        from adaptive_learning import init_adaptive_tables
        init_adaptive_tables(conn)
        from interest_engine import init_interest_tables
        init_interest_tables(conn)
        init_parent_tables(conn)
        init_assessment_tables(conn)
        init_know_more_tables(conn)
        init_creator_tables(conn)
        init_reflection_tables(conn)
        conn.commit()
        logger.info(f"Cache ready at {CACHE_DB}")
    finally:
        conn.close()

def _story_cache_key(grade, subject, topic, language, genre, novel_name, difficulty) -> str:
    return (
        f"{grade}|{subject}|{topic}|{language}|{genre}|"
        f"{(novel_name or '').strip().lower()}|{normalize_difficulty(difficulty)}"
    )


def normalize_difficulty(key: str) -> str:
    k = (key or "medium").strip().lower()
    return k if k in DIFFICULTY_LEVELS else "medium"


def difficulty_instruction(key: str) -> str:
    return DIFFICULTY_LEVELS[normalize_difficulty(key)]["instruction"]


def _flash_cache_key(grade, subject, topic, language, difficulty) -> str:
    return f"{grade}|{subject}|{topic}|{language}|{normalize_difficulty(difficulty)}"


def _mindmap_cache_key(grade, subject, topic, language, difficulty) -> str:
    return f"{grade}|{subject}|{topic}|{language}|{normalize_difficulty(difficulty)}"


def _quiz_cache_key(grade, subject, topic, language, difficulty) -> str:
    return f"{grade}|{subject}|{topic}|{language}|{normalize_difficulty(difficulty)}"


def _quiz_topic_key(grade, subject, topic) -> str:
    return f"{grade}|{subject}|{topic}"


def _build_story_user_message(grade: int, subject: str, topic: str) -> str:
    ncert_line = ncert_story_hint(grade, subject, topic)
    return (
        f"Grade: {grade}\n"
        f"Subject: {subject}\n"
        f"Topic: {topic}\n"
        f"{ncert_line}\n"
        f"Tell me a hilarious comedy story that teaches this topic! "
        f"Include ASCII art, fun facts, image suggestions, and reference links."
    )


def _build_doc_story_user_message(grade: int, subject: str, topic: str, doc_text: str) -> str:
    """User message for a story built around an uploaded chapter/material."""
    topic_line = f"Topic focus: {topic}\n" if (topic or "").strip() else ""
    return (
        f"Grade: {grade}\n"
        f"Subject: {subject or 'general'}\n"
        f"{topic_line}"
        f"The student uploaded the chapter material below. Base your comedy story on THIS content — "
        f"teach the specific concepts, terms, definitions, and examples that appear here, and stay "
        f"faithful to its scope (don't wander off to unrelated topics). Weave the real ideas from this "
        f"material into the funny story so a student who reads it learns what this chapter teaches.\n"
        f"Include ASCII art, fun facts, image suggestions, and reference links as usual.\n\n"
        f"===== UPLOADED CHAPTER MATERIAL =====\n"
        f"{doc_text}\n"
        f"===== END OF MATERIAL ====="
    )


def _build_doc_questions_user_message(grade: int, subject: str, doc_text: str) -> str:
    """User message carrying the uploaded question bank for pattern analysis."""
    return (
        f"Grade: {grade}\n"
        f"Subject: {subject or 'general'}\n\n"
        f"Here is the question bank the student uploaded. Analyze its pattern and generate a new, "
        f"slightly harder set following the same format as in the uploaded document.\n\n"
        f"===== UPLOADED QUESTION BANK =====\n"
        f"{doc_text}\n"
        f"===== END OF QUESTION BANK ====="
    )


def get_cached_story(key: str):
    conn = _get_conn()
    try:
        row = conn.execute(
            "SELECT story, hits FROM story_cache WHERE cache_key = ?", (key,)
        ).fetchone()
        if row:
            conn.execute(
                "UPDATE story_cache SET accessed_at = ?, hits = hits + 1 WHERE cache_key = ?",
                (time.time(), key)
            )
            conn.commit()
            return {"story": row["story"], "hits": row["hits"] + 1}
        return None
    finally:
        conn.close()

def store_cached_story(key: str, grade, subject, topic, language, genre, novel_name, story: str):
    conn = _get_conn()
    try:
        now = time.time()
        conn.execute("""
            INSERT INTO story_cache (cache_key, grade, subject, topic, language, genre, novel_name,
                                     story, created_at, accessed_at, hits)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)
            ON CONFLICT(cache_key) DO UPDATE SET
                story = excluded.story,
                accessed_at = excluded.accessed_at
        """, (key, grade, subject, topic, language, genre, novel_name or "", story, now, now))
        conn.commit()
    finally:
        conn.close()

def get_cached_flashcards(key: str):
    conn = _get_conn()
    try:
        row = conn.execute(
            "SELECT cards_json, hits FROM flashcard_cache WHERE cache_key = ?", (key,)
        ).fetchone()
        if row:
            conn.execute(
                "UPDATE flashcard_cache SET accessed_at = ?, hits = hits + 1 WHERE cache_key = ?",
                (time.time(), key)
            )
            conn.commit()
            return {"cards": json.loads(row["cards_json"]), "hits": row["hits"] + 1}
        return None
    finally:
        conn.close()

def store_cached_flashcards(key: str, grade, subject, topic, language, cards):
    conn = _get_conn()
    try:
        now = time.time()
        conn.execute("""
            INSERT INTO flashcard_cache (cache_key, grade, subject, topic, language, cards_json,
                                         created_at, accessed_at, hits)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0)
            ON CONFLICT(cache_key) DO UPDATE SET
                cards_json = excluded.cards_json,
                accessed_at = excluded.accessed_at
        """, (key, grade, subject, topic, language, json.dumps(cards), now, now))
        conn.commit()
    finally:
        conn.close()

def get_cached_mindmap(key: str):
    conn = _get_conn()
    try:
        row = conn.execute(
            "SELECT diagram_json, hits FROM mindmap_cache WHERE cache_key = ?", (key,)
        ).fetchone()
        if row:
            conn.execute(
                "UPDATE mindmap_cache SET accessed_at = ?, hits = hits + 1 WHERE cache_key = ?",
                (time.time(), key)
            )
            conn.commit()
            return {"diagram": json.loads(row["diagram_json"]), "hits": row["hits"] + 1}
        return None
    finally:
        conn.close()

def store_cached_mindmap(key: str, grade, subject, topic, language, diagram):
    conn = _get_conn()
    try:
        now = time.time()
        conn.execute("""
            INSERT INTO mindmap_cache (cache_key, grade, subject, topic, language, diagram_json,
                                       created_at, accessed_at, hits)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0)
            ON CONFLICT(cache_key) DO UPDATE SET
                diagram_json = excluded.diagram_json,
                accessed_at = excluded.accessed_at
        """, (key, grade, subject, topic, language, json.dumps(diagram), now, now))
        conn.commit()
    finally:
        conn.close()

def get_cached_quiz(key: str):
    conn = _get_conn()
    try:
        row = conn.execute(
            "SELECT quiz_json, hits FROM quiz_cache WHERE cache_key = ?", (key,)
        ).fetchone()
        if row:
            conn.execute(
                "UPDATE quiz_cache SET accessed_at = ?, hits = hits + 1 WHERE cache_key = ?",
                (time.time(), key)
            )
            conn.commit()
            return {"quiz": json.loads(row["quiz_json"]), "hits": row["hits"] + 1}
        return None
    finally:
        conn.close()

def store_cached_quiz(key: str, grade, subject, topic, language, quiz: dict):
    conn = _get_conn()
    try:
        now = time.time()
        conn.execute("""
            INSERT INTO quiz_cache (cache_key, grade, subject, topic, language, quiz_json,
                                    created_at, accessed_at, hits)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0)
            ON CONFLICT(cache_key) DO UPDATE SET
                quiz_json = excluded.quiz_json,
                accessed_at = excluded.accessed_at
        """, (key, grade, subject, topic, language, json.dumps(quiz), now, now))
        conn.commit()
    finally:
        conn.close()

def store_quiz_mastery(topic_key: str, grade, subject, topic, score, total, pct, tier: str):
    conn = _get_conn()
    try:
        now = time.time()
        tier_rank = {"bronze": 1, "silver": 2, "gold": 3}
        row = conn.execute(
            "SELECT best_pct, tier FROM quiz_mastery WHERE topic_key = ?", (topic_key,)
        ).fetchone()
        if row:
            old_rank = tier_rank.get(row["tier"], 0)
            new_rank = tier_rank.get(tier, 0)
            if new_rank < old_rank or (new_rank == old_rank and row["best_pct"] >= pct):
                return row["tier"]
        conn.execute("""
            INSERT INTO quiz_mastery (topic_key, grade, subject, topic, best_score, best_total,
                                      best_pct, tier, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(topic_key) DO UPDATE SET
                best_score = excluded.best_score,
                best_total = excluded.best_total,
                best_pct = excluded.best_pct,
                tier = excluded.tier,
                updated_at = excluded.updated_at
        """, (topic_key, grade, subject, topic, score, total, pct, tier, now))
        conn.commit()
        return tier
    finally:
        conn.close()

def get_quiz_mastery(topic_key: str):
    conn = _get_conn()
    try:
        row = conn.execute(
            "SELECT tier, best_pct, best_score, best_total FROM quiz_mastery WHERE topic_key = ?",
            (topic_key,),
        ).fetchone()
        if not row:
            return None
        return {
            "tier": row["tier"],
            "best_pct": row["best_pct"],
            "best_score": row["best_score"],
            "best_total": row["best_total"],
        }
    finally:
        conn.close()


TIER_RANK = {"bronze": 1, "silver": 2, "gold": 3}

VALID_PROGRESS_STEPS = frozenset({"story", "mindmap", "flashcards", "quiz"})


def record_learning_step(
    learner_id: str,
    grade: int,
    subject: str,
    topic: str,
    difficulty: str,
    step: str,
    *,
    quiz_tier: Optional[str] = None,
    quiz_pct: Optional[int] = None,
) -> dict:
    """Upsert a study-path step for a learner/topic."""
    learner_id = learner_id.strip()
    if not learner_id:
        raise ValueError("learner_id required")
    step = step.strip().lower()
    if step not in VALID_PROGRESS_STEPS:
        raise ValueError(f"Invalid step: {step}")

    topic_key = _quiz_topic_key(grade, subject, topic)
    difficulty = normalize_difficulty(difficulty)
    now = time.time()

    conn = _get_conn()
    try:
        row = conn.execute(
            """SELECT story_done, mindmap_done, flashcards_done, quiz_done, quiz_tier, quiz_pct
               FROM learning_progress WHERE learner_id = ? AND topic_key = ?""",
            (learner_id, topic_key),
        ).fetchone()

        story_done = int(row["story_done"]) if row else 0
        mindmap_done = int(row["mindmap_done"]) if row else 0
        flashcards_done = int(row["flashcards_done"]) if row else 0
        quiz_done = int(row["quiz_done"]) if row else 0
        best_tier = row["quiz_tier"] if row else None
        best_pct = row["quiz_pct"] if row else None

        if step == "story":
            story_done = 1
        elif step == "mindmap":
            mindmap_done = 1
        elif step == "flashcards":
            flashcards_done = 1
        elif step == "quiz":
            quiz_done = 1
            if quiz_tier:
                if not best_tier or TIER_RANK.get(quiz_tier, 0) >= TIER_RANK.get(best_tier, 0):
                    best_tier = quiz_tier
            if quiz_pct is not None:
                best_pct = max(best_pct or 0, quiz_pct)

        conn.execute(
            """
            INSERT INTO learning_progress (
                learner_id, topic_key, grade, subject, topic, difficulty,
                story_done, mindmap_done, flashcards_done, quiz_done,
                quiz_tier, quiz_pct, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(learner_id, topic_key) DO UPDATE SET
                grade = excluded.grade,
                subject = excluded.subject,
                topic = excluded.topic,
                difficulty = excluded.difficulty,
                story_done = MAX(learning_progress.story_done, excluded.story_done),
                mindmap_done = MAX(learning_progress.mindmap_done, excluded.mindmap_done),
                flashcards_done = MAX(learning_progress.flashcards_done, excluded.flashcards_done),
                quiz_done = MAX(learning_progress.quiz_done, excluded.quiz_done),
                quiz_tier = excluded.quiz_tier,
                quiz_pct = excluded.quiz_pct,
                updated_at = excluded.updated_at
            """,
            (
                learner_id, topic_key, grade, subject, topic, difficulty,
                story_done, mindmap_done, flashcards_done, quiz_done,
                best_tier, best_pct, now,
            ),
        )
        conn.commit()
        return get_topic_progress(learner_id, topic_key) or {}
    finally:
        conn.close()


def get_topic_progress(learner_id: str, topic_key: str) -> Optional[dict]:
    conn = _get_conn()
    try:
        row = conn.execute(
            """SELECT grade, subject, topic, difficulty,
                      story_done, mindmap_done, flashcards_done, quiz_done,
                      quiz_tier, quiz_pct, updated_at
               FROM learning_progress WHERE learner_id = ? AND topic_key = ?""",
            (learner_id, topic_key),
        ).fetchone()
        if not row:
            return None
        return _progress_row_to_dict(topic_key, row)
    finally:
        conn.close()


def _progress_row_to_dict(topic_key: str, row) -> dict:
    steps = {
        "story": bool(row["story_done"]),
        "mindmap": bool(row["mindmap_done"]),
        "flashcards": bool(row["flashcards_done"]),
        "quiz": bool(row["quiz_done"]),
    }
    done = sum(1 for v in steps.values() if v)
    return {
        "topic_key": topic_key,
        "grade": row["grade"],
        "subject": row["subject"],
        "topic": row["topic"],
        "difficulty": row["difficulty"],
        "steps": steps,
        "quiz_tier": row["quiz_tier"],
        "quiz_pct": row["quiz_pct"],
        "completion_pct": round(done / 4 * 100),
        "updated_at": row["updated_at"],
    }


def list_learning_progress(learner_id: str) -> list[dict]:
    conn = _get_conn()
    try:
        rows = conn.execute(
            """SELECT topic_key, grade, subject, topic, difficulty,
                      story_done, mindmap_done, flashcards_done, quiz_done,
                      quiz_tier, quiz_pct, updated_at
               FROM learning_progress WHERE learner_id = ?
               ORDER BY updated_at DESC""",
            (learner_id.strip(),),
        ).fetchall()
        return [_progress_row_to_dict(r["topic_key"], r) for r in rows]
    finally:
        conn.close()


def save_learner_profile(learner_id: str, profile: dict) -> None:
    conn = _get_conn()
    try:
        now = time.time()
        conn.execute(
            """
            INSERT INTO learner_profile (learner_id, profile_json, updated_at)
            VALUES (?, ?, ?)
            ON CONFLICT(learner_id) DO UPDATE SET
                profile_json = excluded.profile_json,
                updated_at = excluded.updated_at
            """,
            (learner_id.strip(), json.dumps(profile), now),
        )
        conn.commit()
    finally:
        conn.close()


def get_learner_profile(learner_id: str) -> Optional[dict]:
    conn = _get_conn()
    try:
        row = conn.execute(
            "SELECT profile_json FROM learner_profile WHERE learner_id = ?",
            (learner_id.strip(),),
        ).fetchone()
        if not row:
            return None
        return json.loads(row["profile_json"])
    finally:
        conn.close()


# Create cache tables at startup
init_cache()
# ---------------------------------------------------------------------------
# End cache setup
# ---------------------------------------------------------------------------

# Ensure the active AI provider has an API key (falls back to any configured
# provider; raises if none). Provider clients are built lazily in ai_config.
validate_active_provider()

logger.info(
    f"AI provider: {current_provider_name()} — "
    f"story: {current_model('story')}, fast: {current_model('fast')}"
)

# ---------------------------------------------------------------------------
# System prompts
# ---------------------------------------------------------------------------

def build_story_prompt(
    grade: int,
    language_key: str,
    genre_key: str,
    novel_name: str = "",
    difficulty: str = "medium",
    child_profile: Optional[dict] = None,
    adaptive_block: str = "",
    interest_block: str = "",
    emotional_block: str = "",
) -> str:
    lang = LANGUAGES.get(language_key, LANGUAGES["english"])
    genre = GENRES.get(genre_key, GENRES["realistic"])
    genre_instruction = genre["prompt"]
    if genre_key == "novel_inspired" and novel_name:
        genre_instruction = genre_instruction.replace("{novel_name}", novel_name)

    reading_block = ""
    if child_profile and child_profile.get("reading_level"):
        reading_block = f"\nREADING LEVEL: {reading_level_instruction(child_profile['reading_level'])}"

    return f"""You are Professor Giggles 🎓, the world's funniest teacher!

Your job is to explain school topics to Grade {grade} students (CBSE) as a HILARIOUS comedy story.

LANGUAGE: {lang['instruction']}

GENRE/STYLE: {genre_instruction}

DIFFICULTY: {difficulty_instruction(difficulty)}{reading_block}
{child_profile_prompt_block(child_profile)}
{adaptive_block}
{interest_block}
{emotional_block}
Rules:
1. Create a fun, engaging story (500-800 words) that teaches the topic thoroughly.
2. Use silly characters with funny names fitting the genre.
3. Include jokes, puns, and unexpected twists that relate to the topic.
4. Include ASCII art characters or diagrams where they help visualize the concept.
   Use code blocks (```) for ASCII art so it renders properly.
5. Sprinkle in 2-3 "🤯 Did You Know?" or "⚡ Fun Fact!" boxes throughout the story using blockquotes:
   > 🤯 **Did You Know?** [fascinating real fact about the topic]
6. End with a "📝 What We Actually Learned" section — 3-4 bullet points summarizing the real lesson.
7. After the summary, add a "🔗 Want to Learn More?" section with 2-3 real, relevant links:
   - Use Wikipedia, Khan Academy, BYJU'S, or NCERT links
   - Format: [Title](URL)
8. Include image suggestions using this EXACT format (3-4 per story):
   {{{{IMAGE: descriptive search query}}}}
   Place them naturally within the story where a visual would help.
9. Keep language grade-appropriate for Grade {grade}.
10. Make it genuinely educational — the comedy should SERVE the learning, not replace it.
11. Use emojis effectively but not excessively.
{story_prompt_know_more_block()}

Format your response in Markdown."""


FLASHCARD_PROMPT = """You are a quiz master creating flash cards for a student.

Generate exactly 6 flash cards to test understanding of the topic.
Mix different question types: factual recall, true/false, fill-in-the-blank, and conceptual.

IMPORTANT: Respond with ONLY a valid JSON array. No markdown, no code blocks, no explanation.
Each object must have exactly these fields:
- "question": the question text
- "answer": the correct answer (keep it concise, 1-2 sentences)
- "hint": a small hint to help if stuck

Example format:
[{{"question":"What is X?","answer":"X is Y","hint":"Think about Z"}}]"""


MINDMAP_PROMPT = """You are Professor Giggles creating a Mermaid mind map to help a student visualize a topic.

Generate a clear, grade-appropriate mind map with:
- 1 central topic (root node)
- 3 to 5 main branches (key ideas)
- 2 to 3 sub-nodes under each branch (details or examples)

IMPORTANT: Respond with ONLY valid JSON. No markdown fences, no extra text.
Format:
{{"title":"Short topic title","mermaid":"mindmap\\n  root((Central Topic))\\n    Branch One\\n      Detail A\\n      Detail B\\n    Branch Two\\n      Detail C"}}

Mermaid rules (follow exactly):
- First line must be: mindmap
- Root node uses double parentheses: root((Topic Name))
- Use 2-space indentation for hierarchy
- Keep every label short (max 5 words), no quotes, no colons, no parentheses except root
- You may use one emoji on the root node only
- Labels must be plain text suitable for Mermaid mindmap syntax"""


QUIZ_PROMPT = """You are Professor Giggles creating a scored multiple-choice quiz for a student.

Generate exactly 8 multiple-choice questions that test understanding of the topic.
Mix factual recall, application, and common misconceptions.

IMPORTANT: Respond with ONLY valid JSON. No markdown fences, no extra text.
Format:
{{"questions":[{{"question":"...","options":["A","B","C","D"],"correct_index":0,"explanation":"..."}}]}}

Rules:
- Each question must have exactly 4 options
- correct_index is 0-based (0 = first option)
- Keep questions and options concise and grade-appropriate
- explanation is one short sentence shown after the student answers"""


QUESTION_SET_PROMPT = """You are Professor Giggles creating a practice question set from a question bank a student uploaded.

First, carefully ANALYZE the uploaded question bank:
- Identify the question TYPES used (multiple choice, short answer, long answer, fill in the blank, true/false).
- Note the FORMAT and STYLE — how options are written, how many, phrasing, expected answer length.
- Judge the overall DIFFICULTY.

Then produce a BRAND-NEW set of questions on the SAME concepts and topics that:
1. Follows the SAME pattern and mix of question types as the source (mirror the proportions you see).
2. Is ONE NOTCH HARDER than the source — use more precise terminology, add an extra reasoning step,
   introduce subtler distractors, or combine two ideas. Do NOT make it drastically harder; keep it
   grade-appropriate.
3. Does NOT copy the source questions verbatim — create fresh questions in the same spirit.

Output rules (per question):
- "type": one of "mcq", "short_answer", "long_answer", "fill_blank", "true_false".
- "question": the question text. For "fill_blank" use ____ to mark the blank.
- "options": for "mcq" give exactly 4 options; for "true_false" give ["True", "False"]; for every
  other type use an empty array [].
- "correct_index": 0-based index of the correct option for "mcq"/"true_false"; use -1 when there are
  no options.
- "model_answer": the full correct/expected answer (for "mcq", the text of the correct option).
- "keywords": 2-5 key words/phrases a good answer should contain (empty array [] if not applicable).
- "difficulty": "easy", "medium", or "hard" for this specific question.
- "explanation": one short sentence explaining the answer.

Also fill:
- "title": a short title for this question set.
- "source_pattern": one sentence describing the pattern you detected in the uploaded bank
  (types, count, style, difficulty).

Produce between 5 and 15 questions, roughly matching the source's length."""


SUBJECT_GATE_PROMPT = """You are Professor Giggles creating a compulsory subject checkpoint exam.

The student has finished three topics in one subject. Generate exactly 20 questions that review ALL three topics fairly.

Mix:
- 12 multiple-choice (type "mcq") — 4 options each, correct_index 0-based
- 4 short subjective (type "subjective") — 2-4 sentence answers
- 4 descriptive (type "descriptive") — one short paragraph answers

For non-mcq questions set options to [], correct_index to -1, and provide:
- model_answer: ideal concise answer
- keywords: 4-8 important terms/phrases that should appear in a good answer
- explanation: one sentence grading hint

For mcq questions set model_answer to the correct option text, keywords to [], explanation as usual.

IMPORTANT: Respond with ONLY valid JSON matching the schema. No markdown fences."""


STORY_WORLD_PROMPT = """You are Professor Giggles designing an interactive STORY WORLD — a game-like story universe where the school topic is learned BY PLAYING, not by a separate quiz.
""" + FINN_STORY_WORLD_SNIPPET + """

Build a complete mini-universe with:
- A catchy story title and synopsis
- 2–4 characters (ids like "maya", emoji, role, short description)
- 2–4 locations (ids like "hidden_door")
- 1–4 objects tied to locations (keys, maps, codes, etc.)
- 2–4 learning_objectives aligned to the topic
- Exactly 2 chapters, each with 2–3 scenes
- 1–3 endings

CRITICAL — EMBEDDED LEARNING (like a video game):
- At least 4 scenes MUST have a real challenge (type NOT "none").
- Each challenge MUST set activity_type and category from the catalog below.
- Vary activity types across the story — do not repeat the same activity_type more than twice.
- The challenge question must be part of the STORY (unlock a door, decode a map, sort potions, classify creatures).
- success_narrative describes what happens when they solve it; failure_narrative encourages retry in-story (explain WHY a common wrong answer happens, not just "wrong").
- hint: level-1 small clue; progressive_hints: EXACTLY 5 strings escalating help:
  [1] small clue, [2] clearer clue, [3] worked example (similar problem), [4] step-by-step method, [5] answer + explanation.
- reward_item gives an inventory object; reward_xp is 10–25.

LEARNING CHALLENGE CATALOG — pick activity_type + matching type (interaction):

Mathematics (category: mathematics):
  mcq, fill_blank, drag_drop, number_order, matching, mental_math, word_problem,
  pattern_recognition, geometry_puzzle, measurement

Language (category: language):
  vocabulary, spelling, grammar, sentence_building, reading_comprehension, word_matching,
  synonyms, antonyms, story_sequencing, pronunciation

Science (category: science):
  classification, cause_effect, prediction, observation, experiment, diagram_labeling,
  scientific_reasoning, hypothesis

Reasoning (category: reasoning):
  logic_puzzle, pattern_puzzle, memory_game, deduction, spatial_reasoning, problem_solving

Interaction type (challenge.type) must match activity:
  mcq / mental_math / word_problem / measurement / vocabulary / grammar / reading_comprehension /
  pattern_recognition / geometry_puzzle / prediction / observation / hypothesis / logic_puzzle /
  pattern_puzzle / deduction → type "mcq" or "numeric" or "text" or "fill_blank" as appropriate
  matching / word_matching / synonyms / antonyms / cause_effect → type "matching" + pairs[{left,right}] (3–4 pairs)
  number_order / sentence_building / story_sequencing / experiment / spatial_reasoning → type "ordering"
    + order_items[] + correct_order[] (indices into order_items)
  drag_drop / classification / diagram_labeling → type "drag_drop"
    + drop_zones[{id,label,emoji}] + drop_items[{id,label,emoji}] + correct_placements[{item_id,zone_id}]
  memory_game → type "memory" + memory_pairs[{id,content,emoji}] (3–4 pairs)
  fill_blank / spelling → type "fill_blank" + blanks[{id,answer,acceptable_answers}] OR correct_answer
  scientific_reasoning / problem_solving / pronunciation → type "text" + keywords[]

Example numeric: "24 stars, one quarter blue. How many blue?" → activity_type mental_math, type numeric, correct_answer "6"
Example matching: match animals to habitats using pairs array.
Example ordering: arrange story events with order_items and correct_order.

Scenes with challenge type "none" should offer 1–3 choices (e.g. three paths: river / mountain / cave) with activity_type: story, explore, challenge, or puzzle.
""" + choice_prompt_block() + """

INTERACTIVE STORYTELLING — every scene MUST include:
- background_theme: forest, river, mountain, cave, classroom, space, castle, or village
- dialogue: 2–5 lines with character_id, line (spoken text), mood (neutral/happy/curious/surprised/worried/excited)
  Use character_id "narrator" for scene-setting lines. Characters should speak in character — not wall-of-text narrative.
- hotspots: 0–3 tappable objects (object_id, label, emoji, x_percent 10–90, y_percent 20–80, discovery_text, reaction_emoji)
- choices: when branching, use labels like "Follow the river" with activity_type hinting what happens (explore/challenge/story)

Scene IDs: ch1_s1, ch1_s2, ch2_s1, etc. Link next_scene_id between scenes. Last scene may use empty next_scene_id.

For unused choice fields: ending_id = "" when not ending. activity_type = "story" by default.
  skill_tags = [], who_affected = [], immediate_effects = [], reflection_question = "", values_tradeoff = "", preview = "".

For scenes without a dilemma trade-off: dilemma: { setup: "", skills: [] }.

For unused challenge fields when type is "none": activity_type="mcq"; category="reasoning"; question/hint/success/failure/explanation/reward_item=""; progressive_hints=["","","","",""]; options=["","","",""]; correct_index=-1; correct_answer=""; acceptable_answers=[]; keywords=[]; pairs=[]; order_items=[]; correct_order=[]; drop_zones=[]; drop_items=[]; correct_placements=[]; memory_pairs=[]; blanks=[]; reward_xp=0.

For scenes with no hotspots use hotspots: [].

Make the math/science/language INSEPARABLE from the plot — never say "now solve this problem"."""


def build_adventure_prompt(
    grade: int,
    language_key: str,
    genre_key: str,
    novel_name: str = "",
    difficulty: str = "medium",
    child_profile: Optional[dict] = None,
    interest_block: str = "",
    emotional_block: str = "",
) -> str:
    lang = LANGUAGES.get(language_key, LANGUAGES["english"])
    genre = GENRES.get(genre_key, GENRES["realistic"])
    genre_instruction = genre["prompt"]
    if genre_key == "novel_inspired" and novel_name:
        genre_instruction = genre_instruction.replace("{novel_name}", novel_name)

    return f"""You are Professor Giggles 🎓 running a "Choose Your Own Adventure" lesson!

You teach Grade {grade} students (CBSE) by letting them LIVE the lesson as an interactive story.

LANGUAGE: {lang['instruction']}
GENRE/STYLE: {genre_instruction}
DIFFICULTY: {difficulty_instruction(difficulty)}
{child_profile_prompt_block(child_profile)}
{interest_block}
{emotional_block}

You generate ONE chapter at a time. Each chapter should:
1. Be 150-250 words of fun, engaging narrative that teaches part of the topic.
2. Use funny characters and humor fitting the genre.
3. Include a "🤯 Did You Know?" fact OR an ASCII art visual when it fits naturally.
4. End with EXACTLY 3 choices for what happens next.

IMPORTANT: Respond with ONLY valid JSON. No markdown, no code blocks, no extra text.
Format:
{{{{
  "chapter_number": 1,
  "chapter_title": "The Adventure Begins",
  "content": "Markdown story content here...",
  "choices": [
    {{"id": "a", "text": "Follow the river upstream", "emoji": "🌊"}},
    {{"id": "b", "text": "Investigate the glowing cave", "emoji": "✨"}},
    {{"id": "c", "text": "Ask the wise old owl", "emoji": "🦉"}}
  ],
  "is_final": false
}}}}

When the story should end (after 3-5 chapters), set is_final to true, choices to an empty array,
and include a "📝 What We Actually Learned" summary (3-4 bullets) and
a "🔗 Want to Learn More?" section with 2-3 links in the content.

Each choice should lead to a DIFFERENT aspect of the topic being explored.
Make every path educational — there are no wrong choices, just different lessons!
""" + adventure_choice_prompt_block() + """

The adventure should feel like the student is DISCOVERING the topic, not being lectured."""


def build_adventure_narrative_prompt(
    grade: int,
    language_key: str,
    genre_key: str,
    novel_name: str = "",
    difficulty: str = "medium",
    child_profile: Optional[dict] = None,
    interest_block: str = "",
    emotional_block: str = "",
) -> str:
    lang = LANGUAGES.get(language_key, LANGUAGES["english"])
    genre = GENRES.get(genre_key, GENRES["realistic"])
    genre_instruction = genre["prompt"]
    if genre_key == "novel_inspired" and novel_name:
        genre_instruction = genre_instruction.replace("{novel_name}", novel_name)

    return f"""You are Professor Giggles 🎓 running a "Choose Your Own Adventure" lesson!

You teach Grade {grade} students (CBSE) by letting them LIVE the lesson as an interactive story.

LANGUAGE: {lang['instruction']}
GENRE/STYLE: {genre_instruction}
DIFFICULTY: {difficulty_instruction(difficulty)}
{child_profile_prompt_block(child_profile)}
{interest_block}
{emotional_block}

Write ONE chapter as Markdown (150-250 words). Do NOT output JSON.
1. Fun narrative that teaches part of the topic with silly characters.
2. Include a "🤯 Did You Know?" fact OR ASCII art in a code block when it fits.
3. If this is the final chapter (chapter 5+, or the story arc is complete), end with
   "📝 What We Actually Learned" bullets and "🔗 Want to Learn More?" links.
4. Otherwise end on a cliffhanger — choices will be generated separately.
5. Make every path educational; humor should serve learning.""" + adventure_choice_prompt_block()


ADVENTURE_META_PROMPT = """You structure a Choose Your Own Adventure lesson chapter.

Given the chapter narrative and context, return JSON metadata and exactly 3 choices.

Rules:
- chapter_title: short, exciting title matching the narrative
- choices: 3 objects with id (a/b/c), text, emoji — each explores a different aspect of the topic
- is_final: true if the narrative already has a learning summary / ending; then choices must be []
- If not final, each choice must be distinct and educational (no wrong paths)""" + adventure_meta_prompt_block()


DOUBT_PROMPT = finn_doubt_prompt()


PUZZLE_TYPES = [
    "riddle",
    "word scramble (give jumbled letters, answer is the word)",
    "spot the pattern number sequence",
    "fun would you rather question",
    "tongue twister challenge",
    "simple logic puzzle",
    "emoji guessing game (represent a movie/book/phrase with emojis)",
    "fun trivia question",
]

PUZZLE_PROMPT = """You are a fun puzzle master! Generate ONE quick brain-break puzzle or game
of the specific type given to you in the user message. This should be totally UNRELATED to
any school subject — just pure fun! Make it a NEW, original puzzle each time — never reuse a
common/famous example (e.g. avoid classic riddles like "what has keys but no locks").

IMPORTANT: Respond with ONLY valid JSON. No markdown, no code blocks.
Format:
{{"type":"riddle","title":"Brain Break! 🧩","content":"the puzzle content","hint":"a helpful hint","answer":"the answer"}}"""


TOPIC_PUZZLE_TYPES = [
    "emoji guessing game (represent key terms and concepts from the topic using emojis)",
    "word scramble using key vocabulary words from the topic",
    "true/false quiz question about a common misconception on the topic",
    "fill-in-the-blank challenge with a key definition from the topic",
    "fun mnemonic or memory-trick puzzle to remember something important on the topic",
    "logic puzzle that requires understanding of the topic to solve",
    "trivia question with a surprising fun fact about the topic",
    "spot-the-mistake puzzle that presents a wrong statement about the topic for the student to correct",
]

TOPIC_PUZZLE_PROMPT = """You are a fun puzzle master! Generate ONE topic-relevant educational puzzle
for a student. Use the puzzle type provided in the user message, and base the puzzle ENTIRELY on the
given Grade, Subject, and Topic. The puzzle should BOTH be fun AND REINFORCE LEARNING of the topic.

Make it:
- Age-appropriate for the student's grade
- Directly related to the actual concepts they study (not vague)
- Playful and engaging, not like a textbook quiz
- Creative and original — don't just regurgitate textbook questions

IMPORTANT: Respond with ONLY valid JSON. No markdown, no code blocks.
Format:
{{"type":"emoji puzzle","title":"🧠 Topic Challenge!","content":"the puzzle content","hint":"a helpful hint related to the topic","answer":"the correct answer with a short 1-sentence explanation"}}"""


def _extract_json(raw_text: str):
    """Robustly extract JSON object from LLM output that may have extra text or code fences."""
    text = raw_text.strip()
    if text.startswith("```"):
        first_nl = text.find("\n")
        if first_nl != -1:
            text = text[first_nl + 1:]
        else:
            text = text[3:]
        if text.endswith("```"):
            text = text[:-3]
        text = text.strip()
    start = text.find("{")
    end = text.rfind("}")
    if start != -1 and end != -1 and end > start:
        text = text[start:end + 1]
    return text.strip()


def _extract_json_array(raw_text: str):
    """Robustly extract JSON array from LLM output."""
    text = raw_text.strip()
    if text.startswith("```"):
        first_nl = text.find("\n")
        if first_nl != -1:
            text = text[first_nl + 1:]
        else:
            text = text[3:]
        if text.endswith("```"):
            text = text[:-3]
        text = text.strip()
    start = text.find("[")
    end = text.rfind("]")
    if start != -1 and end != -1 and end > start:
        text = text[start:end + 1]
    return text.strip()


def _validate_quiz_questions(questions: list) -> list:
    validated = []
    for q in questions:
        options = q.get("options", [])
        if not isinstance(options, list) or len(options) != 4:
            continue
        correct = q.get("correct_index", 0)
        if not isinstance(correct, int) or correct < 0 or correct >= 4:
            continue
        if not q.get("question"):
            continue
        validated.append({
            "question": str(q["question"]),
            "options": [str(o) for o in options],
            "correct_index": correct,
            "explanation": str(q.get("explanation", "")),
        })
    if len(validated) < 4:
        raise ValueError("Quiz must have at least 4 valid questions")
    return validated


# ---------------------------------------------------------------------------
# Request models
# ---------------------------------------------------------------------------

class ExplainRequest(BaseModel):
    grade: int
    subject: str
    topic: str
    language: str = "english"
    genre: str = "realistic"
    novel_name: Optional[str] = ""
    difficulty: str = "medium"
    skip_cache: Optional[bool] = False  # bypass cache for regenerate (Tell It Differently)
    learner_id: Optional[str] = ""


class FlashcardRequest(BaseModel):
    grade: int
    subject: str
    topic: str
    language: str = "english"
    difficulty: str = "medium"
    learner_id: Optional[str] = ""


class MindmapRequest(BaseModel):
    grade: int
    subject: str
    topic: str
    language: str = "english"
    difficulty: str = "medium"
    learner_id: Optional[str] = ""


class QuizRequest(BaseModel):
    grade: int
    subject: str
    topic: str
    language: str = "english"
    genre: str = "realistic"
    difficulty: str = "medium"
    learner_id: Optional[str] = ""


class QuizWrongItem(BaseModel):
    question: str
    answer: str
    explanation: Optional[str] = ""


class QuizSubmitRequest(BaseModel):
    grade: int
    subject: str
    topic: str
    score: int
    total: int
    learner_id: Optional[str] = ""
    difficulty: str = "medium"
    wrong_items: list[QuizWrongItem] = []


class SpacedReviewRequest(BaseModel):
    learner_id: str
    item_key: str
    correct: bool


class SpacedRateRequest(BaseModel):
    learner_id: str
    grade: int
    subject: str
    topic: str
    item_type: str  # flashcard | quiz
    identifier: str
    prompt: str
    answer: str
    correct: bool
    explanation: Optional[str] = ""


class SubjectGateExamRequest(BaseModel):
    learner_id: str
    grade: int
    subject: str
    gate_num: int
    language: str = "english"
    difficulty: str = "medium"


class SubjectGateAnswerItem(BaseModel):
    index: int
    value: str | int | float | None = None


class SubjectGateSubmitRequest(BaseModel):
    learner_id: str
    exam_id: str
    answers: list[SubjectGateAnswerItem]


class DoubtMessage(BaseModel):
    role: str  # "user" or "assistant"
    content: str


class DoubtRequest(BaseModel):
    question: str
    grade: Optional[int] = None
    subject: Optional[str] = ""
    topic: Optional[str] = ""
    language: str = "english"
    difficulty: str = "medium"
    history: list[DoubtMessage] = []
    learner_id: Optional[str] = ""
    story_excerpt: str = ""


class KnowMoreSparksRequest(BaseModel):
    grade: int
    subject: str
    topic: str
    story_text: str
    language: str = "english"


class KnowMoreExploreRequest(BaseModel):
    learner_id: str = ""
    grade: int
    subject: str
    topic: str
    question: str
    story_excerpt: str = ""
    path: list[str] = []
    language: str = "english"


class CreateStoryChoices(BaseModel):
    hero: str
    animal: str
    location: str
    problem: str
    theme: str


class CreateStoryGenerateRequest(BaseModel):
    learner_id: str = ""
    grade: int
    subject: str = ""
    topic: str = ""
    language: str = "english"
    choices: CreateStoryChoices


class CreateStoryContinueRequest(BaseModel):
    learner_id: str = ""
    grade: int
    subject: str = ""
    topic: str = ""
    language: str = "english"
    child_draft: str
    story_context: str = ""


class ReflectionSubmitRequest(BaseModel):
    learner_id: str
    activity_type: str = "adventure"
    grade: int = 0
    subject: str = ""
    topic: str = ""
    option_id: str
    own_words: str = ""


class AdventureChapter(BaseModel):
    role: str  # "user" or "assistant"
    content: str


class AdventureRequest(BaseModel):
    grade: int
    subject: str
    topic: str
    language: str = "english"
    genre: str = "realistic"
    novel_name: Optional[str] = ""
    difficulty: str = "medium"
    history: list[AdventureChapter] = []  # previous chapters + choices
    choice: Optional[str] = None  # the choice text the student picked (None for first chapter)
    learner_id: Optional[str] = ""


class PuzzleRequest(BaseModel):
    grade: Optional[int] = None
    subject: Optional[str] = ""
    topic: Optional[str] = ""
    language: str = "english"
    difficulty: str = "medium"


class StoryWorldStartRequest(BaseModel):
    learner_id: str
    grade: int
    subject: str
    topic: str
    language: str = "english"
    genre: str = "realistic"
    novel_name: Optional[str] = ""
    difficulty: str = "medium"


class StoryWorldAnswerRequest(BaseModel):
    learner_id: str
    world_id: str
    scene_id: str
    answer: Any = None
    response_ms: int = 0
    attempts: int = 1
    hints: int = 0


class StoryWorldMiniPracticeRequest(BaseModel):
    learner_id: str
    world_id: str
    scene_id: str
    answer: Any = None


class MistakeAnalyzeRequest(BaseModel):
    challenge: dict
    user_answer: Any = None
    context: str = "quiz"


class StoryWorldChoiceRequest(BaseModel):
    learner_id: str
    world_id: str
    scene_id: str
    choice_id: str


class ProgressEventRequest(BaseModel):
    learner_id: str
    grade: int
    subject: str
    topic: str
    step: str  # story | mindmap | flashcards | quiz
    difficulty: str = "medium"
    quiz_tier: Optional[str] = None
    quiz_pct: Optional[int] = None


class CompanionUpdateRequest(BaseModel):
    learner_id: str
    name: str = ""
    species: str = "fox"
    emoji: str = "🦊"


class CompanionEventRequest(BaseModel):
    learner_id: str
    event_type: str


class CompanionPurchaseRequest(BaseModel):
    learner_id: str
    unlock_id: str
    coins: int = 0
    level: int = 1


class CompanionEquipRequest(BaseModel):
    learner_id: str
    unlock_id: str


class MultimodalPreferencesRequest(BaseModel):
    learner_id: str
    preferences: dict


class MultimodalWritingRequest(BaseModel):
    learner_id: str = ""
    prompt_id: str
    text: str
    grade: Optional[int] = None
    subject: str = ""
    topic: str = ""


class ProjectStartRequest(BaseModel):
    learner_id: str
    project_id: str


class ProjectStepCompleteRequest(BaseModel):
    learner_id: str
    project_id: str
    step_id: str
    choice_id: Optional[str] = None
    design_id: Optional[str] = None
    answer: Optional[Any] = None
    answer_index: Optional[int] = None
    text: Optional[str] = None


def _load_companion_state(learner_id: str) -> dict:
    profile = get_learner_profile(learner_id.strip()) or {}
    return normalize_companion(profile.get("companion"))


def _save_companion_state(learner_id: str, companion: dict) -> None:
    profile = get_learner_profile(learner_id.strip()) or {}
    profile["companion"] = companion
    save_learner_profile(learner_id.strip(), profile)


def _record_companion_event(learner_id: str, event_type: str) -> dict:
    lid = (learner_id or "").strip()
    if not lid or not event_type:
        return {}
    profile = get_learner_profile(lid) or {}
    companion = normalize_companion(profile.get("companion"))
    companion, growth = apply_companion_event(companion, event_type)
    level = int(profile.get("level") or 1)
    new_unlocks = auto_unlock_eligible(companion, level)
    for uid in new_unlocks:
        if uid not in companion["unlocked"]:
            companion["unlocked"].append(uid)
    profile["companion"] = companion
    save_learner_profile(lid, profile)
    return {"growth": growth, "new_unlocks": new_unlocks, "companion": companion}


def _companion_prompt_for(learner_id: Optional[str]) -> str:
    lid = (learner_id or "").strip()
    if not lid:
        return ""
    return companion_prompt_snippet(_load_companion_state(lid))


def _emotional_engagement_prompt_for(
    genre_key: str = "realistic",
    learner_id: Optional[str] = None,
) -> str:
    return emotional_engagement_prompt_block(genre_key)


def _learner_prompt_blocks(learner_id: Optional[str], genre_key: str = "realistic") -> str:
    return (
        _interest_prompt_for(learner_id)
        + _companion_prompt_for(learner_id)
        + _multimodal_prompt_for(learner_id)
        + _parent_controls_prompt_for(learner_id)
        + _accessibility_prompt_for(learner_id)
        + _emotional_engagement_prompt_for(genre_key, learner_id)
    )


def _load_accessibility_prefs(learner_id: str) -> dict:
    profile = get_learner_profile(learner_id.strip()) or {}
    return normalize_accessibility_preferences(profile.get("accessibility"))


def _save_accessibility_prefs(learner_id: str, prefs: dict) -> dict:
    profile = get_learner_profile(learner_id.strip()) or {}
    normalized = normalize_accessibility_preferences(prefs)
    profile["accessibility"] = normalized
    save_learner_profile(learner_id.strip(), profile)
    return normalized


def _accessibility_prompt_for(learner_id: Optional[str]) -> str:
    lid = (learner_id or "").strip()
    if not lid:
        return ""
    return accessibility_prompt_block(_load_accessibility_prefs(lid))


def _load_parent_controls(learner_id: Optional[str]) -> dict:
    lid = (learner_id or "").strip()
    if not lid:
        return {}
    conn = _get_conn()
    try:
        return get_parent_controls(conn, lid)
    finally:
        conn.close()


def _parent_controls_prompt_for(learner_id: Optional[str]) -> str:
    controls = _load_parent_controls(learner_id)
    return parent_controls_prompt_block(controls) if controls else ""


def _load_multimodal_prefs(learner_id: str) -> dict:
    profile = get_learner_profile(learner_id.strip()) or {}
    return normalize_multimodal_preferences(profile.get("multimodal"))


def _save_multimodal_prefs(learner_id: str, prefs: dict) -> None:
    profile = get_learner_profile(learner_id.strip()) or {}
    profile["multimodal"] = normalize_multimodal_preferences(prefs)
    save_learner_profile(learner_id.strip(), profile)


def _multimodal_prompt_for(learner_id: Optional[str]) -> str:
    lid = (learner_id or "").strip()
    prefs = _load_multimodal_prefs(lid) if lid else default_multimodal_preferences()
    return multimodal_prompt_block(prefs)


def _load_project_state(learner_id: str) -> dict:
    profile = get_learner_profile(learner_id.strip()) or {}
    raw = profile.get("project_adventures")
    if not raw:
        return default_learner_projects()
    base = default_learner_projects()
    base["active_project_id"] = raw.get("active_project_id")
    base["projects"] = raw.get("projects") or {}
    return base


def _save_project_state(learner_id: str, state: dict) -> None:
    profile = get_learner_profile(learner_id.strip()) or {}
    profile["project_adventures"] = state
    save_learner_profile(learner_id.strip(), profile)


def _load_child_profile(learner_id: Optional[str]) -> Optional[dict]:
    lid = (learner_id or "").strip()
    if not lid:
        return None
    conn = _get_conn()
    try:
        return get_child_profile(conn, lid)
    finally:
        conn.close()


def _adaptive_prompt_for(learner_id: Optional[str], grade: int, subject: str, topic: str) -> str:
    lid = (learner_id or "").strip()
    if not lid or not topic:
        return ""
    conn = _get_conn()
    try:
        state = load_concept_state(conn, lid, grade, subject, topic)
        return adaptive_prompt_block(state)
    finally:
        conn.close()


def _effective_difficulty(
    learner_id: Optional[str],
    grade: int,
    subject: str,
    topic: str,
    requested: str,
) -> str:
    lid = (learner_id or "").strip()
    base = normalize_difficulty(requested)
    if lid and topic:
        conn = _get_conn()
        try:
            status = get_adaptive_status(conn, lid, grade, subject, topic)
            base = normalize_difficulty(status["recommended_difficulty"])
            controls = get_parent_controls(conn, lid)
            cp = get_child_profile(conn, lid)
        finally:
            conn.close()
    else:
        controls = _load_parent_controls(learner_id)
        cp = _load_child_profile(learner_id)
    preferred = (cp or {}).get("preferred_difficulty") if cp else None
    return get_effective_difficulty(controls, base, preferred)


def _record_adaptive(
    learner_id: Optional[str],
    event_type: str,
    grade: int,
    subject: str,
    topic: str,
    *,
    correct: Optional[bool] = None,
    response_ms: int = 0,
    attempts: int = 1,
    hints: int = 0,
    engagement: str = "",
    payload: Optional[dict] = None,
) -> None:
    lid = (learner_id or "").strip()
    if not lid or not topic:
        return
    conn = _get_conn()
    try:
        record_event(
            conn, lid, event_type, grade, subject, topic,
            correct=correct, response_ms=response_ms, attempts=attempts,
            hints=hints, engagement=engagement, payload=payload,
        )
        observe_gameplay(
            conn, lid, event_type, grade=grade, subject=subject, topic=topic,
            correct=correct, attempts=attempts, hints=hints,
            response_ms=response_ms, payload=payload,
        )
        conn.commit()
    except Exception as e:
        logger.warning(f"Adaptive record failed: {e}")
    finally:
        conn.close()


def _record_assessment(
    learner_id: Optional[str],
    source: str,
    grade: int = 0,
    subject: str = "",
    topic: str = "",
    *,
    correct: Optional[bool] = None,
    response_ms: int = 0,
    attempts: int = 1,
    hints: int = 0,
    payload: Optional[dict] = None,
) -> None:
    """Hidden gameplay assessment — no test UI."""
    lid = (learner_id or "").strip()
    if not lid or not source:
        return
    conn = _get_conn()
    try:
        observe_gameplay(
            conn, lid, source, grade=grade, subject=subject, topic=topic,
            correct=correct, attempts=attempts, hints=hints,
            response_ms=response_ms, payload=payload,
        )
        conn.commit()
    except Exception as e:
        logger.warning(f"Assessment observe failed: {e}")
    finally:
        conn.close()


def _interest_prompt_for(learner_id: Optional[str]) -> str:
    lid = (learner_id or "").strip()
    if not lid:
        return ""
    conn = _get_conn()
    try:
        cp = get_child_profile(conn, lid)
        model = build_interest_model(conn, lid, cp)
        return interest_prompt_block(model)
    finally:
        conn.close()


def _record_interest(
    learner_id: Optional[str],
    event_type: str,
    payload: Optional[dict] = None,
) -> None:
    lid = (learner_id or "").strip()
    if not lid:
        return
    conn = _get_conn()
    try:
        cp = get_child_profile(conn, lid)
        record_interest_event(conn, lid, event_type, payload, profile=cp)
        conn.commit()
    except Exception as e:
        logger.warning(f"Interest event failed: {e}")
    finally:
        conn.close()


class InterestEventRequest(BaseModel):
    learner_id: str
    event_type: str
    payload: dict = {}


class AdaptiveEventRequest(BaseModel):
    learner_id: str
    event_type: str
    grade: int
    subject: str
    topic: str
    correct: Optional[bool] = None
    response_ms: int = 0
    attempts: int = 1
    hints: int = 0
    engagement: str = ""
    concept_tag: Optional[str] = None


class ChildProfileSaveRequest(BaseModel):
    learner_id: str
    name: str = ""
    age: Optional[int] = None
    grade: Optional[int] = None
    preferred_language: str = "english"
    reading_level: str = "grade_level"
    interests: list[str] = []
    favorite_characters: list[str] = []
    favorite_animals: list[str] = []
    favorite_colors_themes: list[str] = []
    learning_goals: list[str] = []
    favorite_themes: list[str] = []
    favorite_story_types: list[str] = []
    favorite_activity_types: list[str] = []
    preferred_difficulty: str = "medium"
    audio_narration: bool = True
    audio_music: bool = True
    audio_sfx: bool = True


class ProfileSaveRequest(BaseModel):
    learner_id: str
    profile: dict


class ParentControlsSaveRequest(BaseModel):
    learner_id: str
    controls: dict
    pin: Optional[str] = None
    current_pin: Optional[str] = None
    clear_pin: bool = False


class ParentSessionRequest(BaseModel):
    learner_id: str
    minutes: float = 1.0


class ParentPinVerifyRequest(BaseModel):
    learner_id: str
    pin: str


class AccessibilitySaveRequest(BaseModel):
    learner_id: str
    preferences: dict


class AssessmentObserveRequest(BaseModel):
    learner_id: str
    source: str
    grade: int = 0
    subject: str = ""
    topic: str = ""
    correct: Optional[bool] = None
    attempts: int = 1
    hints: int = 0
    response_ms: int = 0
    payload: dict = {}


def _build_adventure_messages(req: AdventureRequest) -> list[dict[str, str]]:
    messages: list[dict[str, str]] = []
    for msg in req.history:
        messages.append({"role": msg.role, "content": msg.content})
    if req.choice:
        messages.append({"role": "user", "content": adventure_consequence_user_message(req.choice)})
    else:
        messages.append({
            "role": "user",
            "content": (
                f"Grade: {req.grade}\nSubject: {req.subject}\nTopic: {req.topic}\n\n"
                f"Start a Choose Your Own Adventure that teaches this topic! Chapter 1."
            ),
        })
    return messages


def _normalize_doubt_history(history: Optional[list[DoubtMessage]]) -> list[DoubtMessage]:
    """Keep a clean alternating transcript for follow-up doubt turns."""
    out: list[DoubtMessage] = []
    for msg in history or []:
        role = (msg.role or "").strip().lower()
        content = (msg.content or "").strip()
        if not content or role not in ("user", "assistant"):
            continue
        out.append(DoubtMessage(role=role, content=content[:8000]))
    return out[-10:]


def _build_doubt_messages(req: DoubtRequest) -> list[dict[str, str]]:
    """Build a single-turn input that embeds prior chat (avoids Responses API multi-turn issues)."""
    question = (req.question or "").strip()
    if not question:
        question = "Can you help me understand this better?"

    history = _normalize_doubt_history(req.history)
    if not history:
        return [{"role": "user", "content": question}]

    lines: list[str] = []
    for msg in history:
        speaker = "Student" if msg.role == "user" else "Finn the Fox"
        lines.append(f"{speaker}: {msg.content}")

    return [{
        "role": "user",
        "content": (
            "Continue our tutoring conversation. Here is what we already discussed:\n\n"
            + "\n\n".join(lines)
            + f"\n\nStudent's new question:\n{question}"
        ),
    }]


def _build_doubt_system(req: DoubtRequest, lang: dict) -> str:
    context_parts = []
    if req.grade:
        context_parts.append(f"Grade: {req.grade}")
    if req.subject:
        context_parts.append(f"Subject: {req.subject}")
    if req.topic:
        context_parts.append(f"Topic: {req.topic}")
    context_line = " | ".join(context_parts) if context_parts else "General question"

    ncert_block = ""
    if req.grade and req.subject and req.topic:
        grounding = ncert_grounding_context(req.grade, req.subject, req.topic)
        if grounding:
            ncert_block = f"\n\nNCERT alignment:\n{grounding}"

    story_block = ""
    if req.story_excerpt and req.story_excerpt.strip():
        story_block = (
            "\n\nStory they just read (use for context, do not retell the whole story):\n"
            f"{req.story_excerpt.strip()[:3000]}"
        )

    return (
        DOUBT_PROMPT
        + f"\n\nStudent context: {context_line}\nLanguage: {lang['instruction']}"
        + f"\nDifficulty: {difficulty_instruction(req.difficulty)}"
        + ncert_block
        + story_block
    )


class TutorCoachRequest(BaseModel):
    coach_type: str
    topic: str = ""
    subject: str = ""
    question: str = ""
    hint: str = ""
    attempt: int = 1
    score_pct: Optional[int] = None
    child_name: str = ""


class HintRevealRequest(BaseModel):
    learner_id: str = ""
    context: str = "story_world"  # story_world | quiz
    world_id: str = ""
    scene_id: str = ""
    grade: int = 0
    subject: str = ""
    topic: str = ""
    language: str = "english"
    difficulty: str = "medium"
    question_index: int = 0
    current_level: int = 0


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})


@app.get("/api/companion/catalog")
async def get_companion_catalog():
    return companion_catalog()


@app.get("/api/choices/catalog")
async def get_choices_catalog():
    return choices_catalog()


@app.get("/api/multimodal/catalog")
async def get_multimodal_catalog():
    return multimodal_catalog()


@app.get("/api/multimodal/preferences")
async def get_multimodal_preferences(learner_id: str):
    lid = learner_id.strip()
    if not lid:
        return JSONResponse({"error": "learner_id required"}, status_code=400)
    return {"preferences": _load_multimodal_prefs(lid)}


@app.put("/api/multimodal/preferences")
async def put_multimodal_preferences(req: MultimodalPreferencesRequest):
    lid = req.learner_id.strip()
    if not lid:
        return JSONResponse({"error": "learner_id required"}, status_code=400)
    prefs = normalize_multimodal_preferences(req.preferences)
    _save_multimodal_prefs(lid, prefs)
    return {"ok": True, "preferences": prefs}


@app.post("/api/multimodal/writing/feedback")
async def multimodal_writing_feedback(req: MultimodalWritingRequest):
    child_name = ""
    if req.learner_id and req.learner_id.strip():
        cp = _load_child_profile(req.learner_id.strip())
        child_name = (cp or {}).get("name", "")
    feedback = build_writing_feedback(
        req.prompt_id,
        req.text,
        child_name=child_name,
        topic=req.topic,
    )
    if req.learner_id and req.learner_id.strip() and req.text.strip():
        _record_assessment(
            req.learner_id.strip(), "writing",
            grade=req.grade or 0, subject=req.subject or "", topic=req.topic or "",
            correct=True,
            payload={"writing": True, "has_explanation": True, "prompt_id": req.prompt_id},
        )
    return feedback


@app.get("/api/multimodal/comprehension")
async def multimodal_comprehension_prompt():
    return {"reflection_question": comprehension_reflection()}


@app.get("/api/projects/catalog")
async def get_projects_catalog():
    return project_catalog()


@app.get("/api/projects")
async def get_projects(learner_id: str, project_id: Optional[str] = None):
    lid = learner_id.strip()
    if not lid:
        return JSONResponse({"error": "learner_id required"}, status_code=400)
    state = _load_project_state(lid)
    view = build_project_view(state, project_id or state.get("active_project_id"))
    return {"state": state, **view, "catalog": project_catalog()["projects"]}


@app.post("/api/projects/start")
async def post_project_start(req: ProjectStartRequest):
    lid = req.learner_id.strip()
    if not lid:
        return JSONResponse({"error": "learner_id required"}, status_code=400)
    if req.project_id not in PROJECT_BY_ID:
        return JSONResponse({"error": "Unknown project"}, status_code=400)
    try:
        state = _load_project_state(lid)
        state, project = start_project(state, req.project_id)
        _save_project_state(lid, state)
        view = build_project_view(state, req.project_id)
        return {"ok": True, **view}
    except ValueError as e:
        return JSONResponse({"error": str(e)}, status_code=400)


@app.post("/api/projects/step/complete")
async def post_project_step_complete(req: ProjectStepCompleteRequest):
    lid = req.learner_id.strip()
    if not lid:
        return JSONResponse({"error": "learner_id required"}, status_code=400)
    payload = {
        "choice_id": req.choice_id,
        "design_id": req.design_id,
        "answer": req.answer,
        "answer_index": req.answer_index,
        "text": req.text,
    }
    try:
        state = _load_project_state(lid)
        state, result = complete_step(state, req.project_id, req.step_id, payload)
        _save_project_state(lid, state)
        companion_result = None
        try:
            companion_result = _record_companion_event(lid, "project_step")
        except Exception as ce:
            logger.warning(f"Companion project event: {ce}")
        view = build_project_view(state, req.project_id)
        try:
            cp_conn = _get_conn()
            try:
                cp = get_child_profile(cp_conn, lid)
                grade = int(cp.get("grade") or 0) if cp else 0
            finally:
                cp_conn.close()
            step_ok = result.get("correct") if isinstance(result.get("correct"), bool) else True
            _record_assessment(
                lid, "project_step",
                grade=grade,
                subject="Project Adventure",
                topic=req.project_id,
                correct=step_ok,
                payload={"project_id": req.project_id, "step_id": req.step_id, "cross_topic": True},
            )
        except Exception as ae:
            logger.warning(f"Assessment project step: {ae}")
        return {"ok": True, **result, "view": view, "companion": companion_result}
    except ValueError as e:
        return JSONResponse({"error": str(e)}, status_code=400)


@app.get("/api/companion")
async def get_companion(learner_id: str, level: int = 1, coins: int = 0):
    lid = learner_id.strip()
    if not lid:
        return JSONResponse({"error": "learner_id required"}, status_code=400)
    companion = _load_companion_state(lid)
    return build_companion_view(companion, level=level, coins=coins)


@app.put("/api/companion")
async def update_companion(req: CompanionUpdateRequest):
    lid = req.learner_id.strip()
    if not lid:
        return JSONResponse({"error": "learner_id required"}, status_code=400)
    companion = _load_companion_state(lid)
    companion["name"] = req.name.strip()[:30] or companion["name"]
    companion["species"] = req.species.strip()[:20] or "fox"
    companion["emoji"] = req.emoji.strip()[:4] or "🦊"
    _save_companion_state(lid, companion)
    return {"ok": True, "companion": companion}


@app.post("/api/companion/event")
async def companion_event(req: CompanionEventRequest):
    lid = req.learner_id.strip()
    if not lid:
        return JSONResponse({"error": "learner_id required"}, status_code=400)
    result = _record_companion_event(lid, req.event_type)
    return {"ok": True, **result}


@app.post("/api/companion/purchase")
async def companion_purchase(req: CompanionPurchaseRequest):
    lid = req.learner_id.strip()
    if not lid:
        return JSONResponse({"error": "learner_id required"}, status_code=400)
    companion = _load_companion_state(lid)
    updated, spent, err = purchase_unlock(
        companion, req.unlock_id, req.coins, req.level,
    )
    if err:
        return JSONResponse({"error": err}, status_code=400)
    _save_companion_state(lid, updated)
    item = next((u for u in updated["unlocked"] if u == req.unlock_id), req.unlock_id)
    return {
        "ok": True,
        "companion": updated,
        "coins_spent": spent,
        "unlock_id": item,
    }


@app.post("/api/companion/equip")
async def companion_equip(req: CompanionEquipRequest):
    lid = req.learner_id.strip()
    if not lid:
        return JSONResponse({"error": "learner_id required"}, status_code=400)
    companion = _load_companion_state(lid)
    updated, err = equip_item(companion, req.unlock_id)
    if err:
        return JSONResponse({"error": err}, status_code=400)
    _save_companion_state(lid, updated)
    return {"ok": True, "companion": updated}


@app.get("/api/tutor")
async def get_tutor_character():
    return finn_catalog()


@app.post("/api/tutor/coach")
async def tutor_coach(req: TutorCoachRequest):
    kwargs: dict = {
        "topic": req.topic,
        "subject": req.subject,
        "question": req.question,
        "hint": req.hint,
        "attempt": req.attempt,
        "child_name": req.child_name,
    }
    if req.coach_type == "quiz_done" and req.score_pct is not None:
        kwargs["correct"] = req.score_pct
    return coach_message(req.coach_type, **kwargs)


@app.get("/api/hints/catalog")
async def get_hints_catalog():
    return hint_catalog()


@app.post("/api/hints/reveal")
async def reveal_progressive_hint(req: HintRevealRequest):
    """Reveal the next progressive hint level (1–5). Answers only at level 5."""
    next_level = req.current_level + 1
    if next_level > 5:
        return JSONResponse({"error": "All hint levels already revealed"}, status_code=400)

    challenge: Optional[dict] = None

    if req.context == "story_world":
        lid = req.learner_id.strip()
        wid = req.world_id.strip()
        sid = req.scene_id.strip()
        if not lid or not wid or not sid:
            return JSONResponse({"error": "learner_id, world_id, scene_id required"}, status_code=400)
        conn = _get_conn()
        try:
            loaded = load_session(conn, wid, lid)
            if not loaded:
                return JSONResponse({"error": "Story world not found"}, status_code=404)
            world, _progress = loaded
            scene = scene_by_id(world, sid)
            if not scene:
                return JSONResponse({"error": "Scene not found"}, status_code=404)
            challenge = scene.get("challenge") or {}
        finally:
            conn.close()

    elif req.context == "quiz":
        if not req.grade or not req.subject or not req.topic:
            return JSONResponse({"error": "grade, subject, topic required"}, status_code=400)
        difficulty = normalize_difficulty(req.difficulty)
        qkey = _quiz_cache_key(req.grade, req.subject, req.topic, req.language, difficulty)
        cached = get_cached_quiz(qkey)
        if not cached:
            return JSONResponse({"error": "Quiz not found — generate a quiz first"}, status_code=404)
        questions = cached.get("quiz", {}).get("questions", [])
        if req.question_index < 0 or req.question_index >= len(questions):
            return JSONResponse({"error": "Invalid question_index"}, status_code=400)
        challenge = quiz_question_to_challenge(questions[req.question_index])

    else:
        return JSONResponse({"error": f"Unknown context: {req.context}"}, status_code=400)

    if get_interaction(normalize_challenge(challenge)) == "none":
        return JSONResponse({"error": "No challenge for hints"}, status_code=400)

    result = reveal_hint(challenge, next_level)
    cp = None
    if req.learner_id.strip():
        conn = _get_conn()
        try:
            cp = get_child_profile(conn, req.learner_id.strip())
        finally:
            conn.close()
    child_name = (cp or {}).get("name", "")
    finn = coach_message(
        "hint" if next_level < 5 else "reflect",
        question=challenge.get("question", ""),
        hint=result["text"][:200],
        child_name=child_name,
    )
    finn["message"] = result["finn_message"]
    finn["follow_up"] = result["persistence_nudge"]
    result["finn"] = finn
    return result


@app.get("/api/syllabus")
async def get_syllabus():
    """Return the full syllabus structure: grade -> subject -> topics."""
    result = {}
    for grade, subjects in CBSE_SYLLABUS.items():
        result[str(grade)] = {}
        ordered_names = [n for n in SUBJECT_DISPLAY_ORDER if n in subjects]
        ordered_names += [n for n in subjects if n not in SUBJECT_DISPLAY_ORDER]
        for subj_name in ordered_names:
            subj_info = subjects[subj_name]
            result[str(grade)][subj_name] = {
                "emoji": subj_info["emoji"],
                "topics": subj_info["topics"],
            }
    return result


@app.get("/api/genres")
async def get_genres():
    return {k: {"name": v["name"], "emoji": v["emoji"]} for k, v in GENRES.items()}


@app.get("/api/languages")
async def get_languages():
    return {k: {"name": v["name"], "emoji": v["emoji"]} for k, v in LANGUAGES.items()}


@app.get("/api/ai/models")
async def get_ai_models():
    """Expose model routing for ops / debugging."""
    story = current_model("story")
    fast = current_model("fast")
    return {
        "provider": current_provider_name(),
        "story": story,
        "fast": fast,
        "routing": {
            "story_stream": story,
            "adventure_narrative": story,
            "adventure_meta": fast,
            "doubt": fast,
            "flashcards": fast,
            "mindmap": fast,
            "quiz": fast,
            "puzzle": fast,
        },
    }


class AiSettingsRequest(BaseModel):
    provider: Optional[str] = None
    story: Optional[str] = None
    fast: Optional[str] = None


@app.get("/api/ai/settings")
async def get_ai_settings():
    """Current provider/model selection plus the catalog for the in-app picker."""
    settings = get_settings()
    return {
        "provider": settings["provider"],
        "models": settings["models"],
        "configured": configured_providers(),
        "catalog": provider_catalog(),
    }


@app.post("/api/ai/settings")
async def set_ai_settings(req: AiSettingsRequest):
    """Override the active provider and/or its tier models at runtime.

    Process-global for this self-hosted app; resets to env defaults on restart.
    """
    try:
        updated = update_settings(
            provider=req.provider, story=req.story, fast=req.fast,
        )
    except ValueError as e:
        return JSONResponse({"error": str(e)}, status_code=400)
    logger.info(
        f"AI settings updated — provider: {updated['provider']}, "
        f"story: {updated['models']['story']}, fast: {updated['models']['fast']}"
    )
    return {
        "provider": updated["provider"],
        "models": updated["models"],
        "configured": configured_providers(),
        "catalog": provider_catalog(),
    }


@app.get("/api/difficulties")
async def get_difficulties():
    return {k: {"name": v["name"], "emoji": v["emoji"]} for k, v in DIFFICULTY_LEVELS.items()}


@app.get("/api/progress")
async def get_progress(learner_id: str):
    learner_id = learner_id.strip()
    if not learner_id:
        return JSONResponse({"error": "learner_id required"}, status_code=400)
    topics = list_learning_progress(learner_id)
    profile = get_learner_profile(learner_id)
    return {"learner_id": learner_id, "topics": topics, "profile": profile}


@app.post("/api/progress")
async def post_progress_event(req: ProgressEventRequest):
    try:
        topic = record_learning_step(
            req.learner_id,
            req.grade,
            req.subject,
            req.topic,
            req.difficulty,
            req.step,
            quiz_tier=req.quiz_tier,
            quiz_pct=req.quiz_pct,
        )
        step_events = {
            "story": "story_complete",
            "mindmap": "mindmap_complete",
            "flashcards": "flashcards_complete",
        }
        companion_result = None
        if req.step in step_events:
            companion_result = _record_companion_event(req.learner_id, step_events[req.step])
        return {"ok": True, "topic": topic, "companion": companion_result}
    except ValueError as e:
        return JSONResponse({"error": str(e)}, status_code=400)
    except Exception as e:
        logger.error(f"Progress save failed: {type(e).__name__}: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)


@app.post("/api/progress/profile")
async def post_progress_profile(req: ProfileSaveRequest):
    if not req.learner_id.strip():
        return JSONResponse({"error": "learner_id required"}, status_code=400)
    try:
        save_learner_profile(req.learner_id, req.profile)
        return {"ok": True}
    except Exception as e:
        logger.error(f"Profile save failed: {type(e).__name__}: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)


@app.get("/api/child-profile/options")
async def get_child_profile_options():
    catalog = interest_catalog()
    return {
        "reading_levels": {
            k: {"name": v["name"], "emoji": v["emoji"]}
            for k, v in READING_LEVELS.items()
        },
        "languages": {k: {"name": v["name"], "emoji": v["emoji"]} for k, v in LANGUAGES.items()},
        "grades": list(range(5, 11)),
        "story_themes": catalog["story_themes"],
        "story_types": catalog["story_types"],
        "activity_types": catalog["activity_types"],
        "difficulties": catalog["difficulties"],
    }


@app.get("/api/child-profile")
async def get_child_profile_api(learner_id: str):
    learner_id = learner_id.strip()
    if not learner_id:
        return JSONResponse({"error": "learner_id required"}, status_code=400)
    conn = _get_conn()
    try:
        profile = get_child_profile(conn, learner_id)
        if not profile:
            profile = default_child_profile()
        return {"learner_id": learner_id, "profile": profile}
    finally:
        conn.close()


@app.put("/api/child-profile")
async def put_child_profile_api(req: ChildProfileSaveRequest):
    learner_id = req.learner_id.strip()
    if not learner_id:
        return JSONResponse({"error": "learner_id required"}, status_code=400)
    conn = _get_conn()
    try:
        profile = save_child_profile(
            conn, learner_id, req.model_dump(exclude={"learner_id"}),
        )
        sync_explicit_profile(conn, learner_id, profile)
        conn.commit()
        return {"ok": True, "learner_id": learner_id, "profile": profile}
    except Exception as e:
        logger.error(f"Child profile save failed: {type(e).__name__}: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)
    finally:
        conn.close()


@app.get("/api/parent/dashboard")
async def get_parent_dashboard(learner_id: str):
    learner_id = learner_id.strip()
    if not learner_id:
        return JSONResponse({"error": "learner_id required"}, status_code=400)
    conn = _get_conn()
    try:
        child = get_child_profile(conn, learner_id)
        dashboard = build_parent_dashboard(conn, learner_id, child_profile=child)
        dashboard["learning_profile"] = build_learning_profile(conn, learner_id)
        return dashboard
    finally:
        conn.close()


@app.get("/api/parent/controls/catalog")
async def get_parent_controls_catalog():
    return controls_catalog()


@app.get("/api/parent/controls")
async def get_parent_controls_api(learner_id: str):
    learner_id = learner_id.strip()
    if not learner_id:
        return JSONResponse({"error": "learner_id required"}, status_code=400)
    conn = _get_conn()
    try:
        return {"learner_id": learner_id, "controls": get_parent_controls(conn, learner_id)}
    finally:
        conn.close()


@app.put("/api/parent/controls")
async def put_parent_controls_api(req: ParentControlsSaveRequest):
    learner_id = req.learner_id.strip()
    if not learner_id:
        return JSONResponse({"error": "learner_id required"}, status_code=400)
    conn = _get_conn()
    try:
        controls = save_parent_controls(
            conn, learner_id, req.controls,
            pin=req.pin, current_pin=req.current_pin, clear_pin=req.clear_pin,
        )
        if controls.get("learning_goals"):
            sync_learning_goals_to_child(conn, learner_id, controls["learning_goals"])
        conn.commit()
        return {"ok": True, "learner_id": learner_id, "controls": controls}
    except PermissionError as e:
        return JSONResponse({"error": str(e)}, status_code=403)
    except ValueError as e:
        return JSONResponse({"error": str(e)}, status_code=400)
    except Exception as e:
        logger.error(f"Parent controls save failed: {type(e).__name__}: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)
    finally:
        conn.close()


@app.get("/api/parent/controls/status")
async def get_parent_controls_status(learner_id: str):
    learner_id = learner_id.strip()
    if not learner_id:
        return JSONResponse({"error": "learner_id required"}, status_code=400)
    conn = _get_conn()
    try:
        controls = get_parent_controls(conn, learner_id)
        return {
            "learner_id": learner_id,
            "controls": controls,
            "usage": build_usage_status(conn, learner_id, controls),
        }
    finally:
        conn.close()


@app.post("/api/parent/controls/session")
async def post_parent_session(req: ParentSessionRequest):
    learner_id = req.learner_id.strip()
    if not learner_id:
        return JSONResponse({"error": "learner_id required"}, status_code=400)
    conn = _get_conn()
    try:
        usage = record_session_minutes(conn, learner_id, req.minutes)
        controls = get_parent_controls(conn, learner_id)
        conn.commit()
        return {
            "ok": True,
            "usage": usage,
            "status": build_usage_status(conn, learner_id, controls),
        }
    finally:
        conn.close()


@app.post("/api/parent/controls/verify-pin")
async def verify_parent_pin_api(req: ParentPinVerifyRequest):
    learner_id = req.learner_id.strip()
    if not learner_id:
        return JSONResponse({"error": "learner_id required"}, status_code=400)
    conn = _get_conn()
    try:
        ok = verify_parent_pin(conn, learner_id, req.pin)
        return {"ok": ok}
    finally:
        conn.close()


@app.get("/api/parent/report")
async def get_parent_report(learner_id: str, days: int = 7):
    learner_id = learner_id.strip()
    if not learner_id:
        return JSONResponse({"error": "learner_id required"}, status_code=400)
    days = max(1, min(int(days), 30))
    conn = _get_conn()
    try:
        return build_progress_report(conn, learner_id, days=days)
    finally:
        conn.close()


@app.get("/api/accessibility/catalog")
async def get_accessibility_catalog():
    return accessibility_catalog()


@app.get("/api/accessibility/preferences")
async def get_accessibility_preferences_api(learner_id: str):
    learner_id = learner_id.strip()
    if not learner_id:
        return JSONResponse({"error": "learner_id required"}, status_code=400)
    prefs = _load_accessibility_prefs(learner_id)
    return {
        "learner_id": learner_id,
        "preferences": prefs,
        "css_variables": css_variables_for_prefs(prefs),
        "body_classes": body_classes_for_prefs(prefs),
    }


@app.put("/api/accessibility/preferences")
async def put_accessibility_preferences_api(req: AccessibilitySaveRequest):
    learner_id = req.learner_id.strip()
    if not learner_id:
        return JSONResponse({"error": "learner_id required"}, status_code=400)
    try:
        prefs = _save_accessibility_prefs(learner_id, req.preferences)
        return {
            "ok": True,
            "learner_id": learner_id,
            "preferences": prefs,
            "css_variables": css_variables_for_prefs(prefs),
            "body_classes": body_classes_for_prefs(prefs),
        }
    except Exception as e:
        logger.error(f"Accessibility save failed: {type(e).__name__}: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)


@app.get("/api/assessment/catalog")
async def get_assessment_catalog():
    return assessment_catalog()


@app.get("/api/assessment/profile")
async def get_assessment_profile(learner_id: str):
    learner_id = learner_id.strip()
    if not learner_id:
        return JSONResponse({"error": "learner_id required"}, status_code=400)
    conn = _get_conn()
    try:
        return build_learning_profile(conn, learner_id)
    finally:
        conn.close()


@app.post("/api/assessment/observe")
async def post_assessment_observe(req: AssessmentObserveRequest):
    learner_id = req.learner_id.strip()
    if not learner_id or not req.source.strip():
        return JSONResponse({"error": "learner_id and source required"}, status_code=400)
    conn = _get_conn()
    try:
        observe_gameplay(
            conn, learner_id, req.source.strip(),
            grade=req.grade, subject=req.subject, topic=req.topic,
            correct=req.correct, attempts=req.attempts, hints=req.hints,
            response_ms=req.response_ms, payload=req.payload,
        )
        conn.commit()
        return {"ok": True}
    except Exception as e:
        logger.error(f"Assessment observe failed: {type(e).__name__}: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)
    finally:
        conn.close()


def _seed_spaced_wrong_items(
    learner_id: str,
    grade: int,
    subject: str,
    topic: str,
    wrong_items: list,
) -> int:
    learner_id = learner_id.strip()
    if not learner_id or not wrong_items:
        return 0
    conn = _get_conn()
    seeded = 0
    try:
        for w in wrong_items:
            ident = question_identifier(w.question)
            key = make_item_key("quiz", grade, subject, topic, ident)
            upsert_spaced_item(
                conn, learner_id, key, "quiz", grade, subject, topic,
                w.question, w.answer, correct=False,
                extra={"explanation": getattr(w, "explanation", "") or ""},
            )
            seeded += 1
        conn.commit()
        return seeded
    finally:
        conn.close()


@app.get("/api/spaced/rules")
async def get_spaced_rules():
    return {"intervals_days": INTERVALS_DAYS, "description": "Review again after 1, 3, 7, or 14 days when you recall correctly."}


@app.get("/api/spaced/due")
async def get_spaced_due(learner_id: str, all_items: bool = False):
    learner_id = learner_id.strip()
    if not learner_id:
        return JSONResponse({"error": "learner_id required"}, status_code=400)
    conn = _get_conn()
    try:
        if all_items:
            items = list_all_items(conn, learner_id)
        else:
            items = list_due_items(conn, learner_id)
        due_count = count_due_items(conn, learner_id)
        return {"learner_id": learner_id, "due_count": due_count, "items": items, "intervals_days": INTERVALS_DAYS}
    finally:
        conn.close()


@app.post("/api/spaced/review")
async def post_spaced_review(req: SpacedReviewRequest):
    learner_id = req.learner_id.strip()
    if not learner_id or not req.item_key.strip():
        return JSONResponse({"error": "learner_id and item_key required"}, status_code=400)
    conn = _get_conn()
    try:
        row = conn.execute(
            """SELECT item_type, grade, subject, topic, prompt, answer, extra_json, level
               FROM spaced_items WHERE learner_id = ? AND item_key = ?""",
            (learner_id, req.item_key),
        ).fetchone()
        if not row:
            return JSONResponse({"error": "Item not found"}, status_code=404)
        extra = json.loads(row["extra_json"] or "{}")
        result = upsert_spaced_item(
            conn, learner_id, req.item_key, row["item_type"],
            row["grade"], row["subject"], row["topic"],
            row["prompt"], row["answer"], req.correct, extra=extra,
        )
        conn.commit()
        due_count = count_due_items(conn, learner_id)
        return {"ok": True, "item": result, "due_count": due_count}
    except Exception as e:
        logger.error(f"Spaced review failed: {type(e).__name__}: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)
    finally:
        conn.close()


@app.post("/api/spaced/rate")
async def post_spaced_rate(req: SpacedRateRequest):
    """Rate a flashcard or quiz item (creates or updates spaced schedule)."""
    learner_id = req.learner_id.strip()
    if not learner_id:
        return JSONResponse({"error": "learner_id required"}, status_code=400)
    item_type = req.item_type.strip().lower()
    if item_type not in ("flashcard", "quiz"):
        return JSONResponse({"error": "item_type must be flashcard or quiz"}, status_code=400)
    key = make_item_key(item_type, req.grade, req.subject, req.topic, req.identifier)
    conn = _get_conn()
    try:
        result = upsert_spaced_item(
            conn, learner_id, key, item_type,
            req.grade, req.subject, req.topic,
            req.prompt, req.answer, req.correct,
            extra={"explanation": req.explanation or ""},
        )
        conn.commit()
        due_count = count_due_items(conn, learner_id)
        _record_assessment(
            learner_id, "spaced_review",
            grade=req.grade, subject=req.subject, topic=req.topic,
            correct=req.correct,
            payload={"item_type": item_type},
        )
        return {"ok": True, "item_key": key, "schedule": result, "due_count": due_count}
    except Exception as e:
        logger.error(f"Spaced rate failed: {type(e).__name__}: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)
    finally:
        conn.close()


def _topic_access_guard(learner_id: Optional[str], grade: int, subject: str, topic: str):
    """Return a 403 JSONResponse if the topic is locked or parent limits apply."""
    lid = (learner_id or "").strip()
    if not lid:
        return None

    conn = _get_conn()
    try:
        controls = get_parent_controls(conn, lid)
        if not is_subject_allowed(controls, subject):
            return JSONResponse(
                {"error": "This subject is not available right now.", "reason": "subject_blocked"},
                status_code=403,
            )
        usage = build_usage_status(conn, lid, controls)
        if not usage["can_learn"]:
            return JSONResponse(
                {
                    "error": "Learning is paused for now — check back later!",
                    "reason": usage["blocked_reason"],
                    "usage": usage,
                },
                status_code=403,
            )
    finally:
        conn.close()

    from subject_gate import get_subject_topics

    topics = get_subject_topics(grade, subject)
    if topic not in topics:
        return None
    topic_index = topics.index(topic)
    conn = _get_conn()
    try:
        if not topic_is_unlocked(conn, lid, grade, subject, topic_index):
            gate_num = gates_required_before_topic(topic_index) - 1
            return JSONResponse(
                {
                    "error": "Subject checkpoint required before this topic.",
                    "gate_num": gate_num,
                    "pass_pct": GATE_PASS_PCT,
                },
                status_code=403,
            )
    finally:
        conn.close()
    return None


def _store_gate_exam(conn, exam_id: str, learner_id: str, gkey: str, exam: dict) -> None:
    conn.execute(
        """
        INSERT INTO subject_gate_exams (exam_id, learner_id, gate_key, exam_json, created_at)
        VALUES (?, ?, ?, ?, ?)
        """,
        (exam_id, learner_id, gkey, json.dumps(exam), time.time()),
    )


def _load_gate_exam(conn, exam_id: str, learner_id: str) -> Optional[dict]:
    row = conn.execute(
        "SELECT exam_json, created_at FROM subject_gate_exams WHERE exam_id = ? AND learner_id = ?",
        (exam_id, learner_id),
    ).fetchone()
    if not row:
        return None
    if time.time() - row["created_at"] > 86400:
        return None
    return json.loads(row["exam_json"])


@app.get("/api/subject-gate/status")
async def get_subject_gate_status(learner_id: str, grade: int, subject: str):
    learner_id = learner_id.strip()
    if not learner_id:
        return JSONResponse({"error": "learner_id required"}, status_code=400)
    if grade not in CBSE_SYLLABUS and str(grade) not in CBSE_SYLLABUS:
        return JSONResponse({"error": "Invalid grade"}, status_code=400)
    grade_key = grade if grade in CBSE_SYLLABUS else str(grade)
    if subject not in CBSE_SYLLABUS[grade_key]:
        return JSONResponse({"error": "Invalid subject"}, status_code=400)
    conn = _get_conn()
    try:
        return build_gate_status(conn, learner_id, grade, subject)
    finally:
        conn.close()


@app.post("/api/subject-gate/exam")
async def create_subject_gate_exam(req: SubjectGateExamRequest):
    learner_id = req.learner_id.strip()
    if not learner_id:
        return JSONResponse({"error": "learner_id required"}, status_code=400)
    if req.gate_num < 0:
        return JSONResponse({"error": "Invalid gate_num"}, status_code=400)

    conn = _get_conn()
    try:
        if is_gate_passed(conn, learner_id, req.grade, req.subject, req.gate_num):
            return JSONResponse({"error": "Checkpoint already passed"}, status_code=400)
        ready, reason = gate_ready_to_take(conn, learner_id, req.grade, req.subject, req.gate_num)
        if not ready:
            return JSONResponse({"error": reason}, status_code=400)

        batch_topics = topics_for_gate(req.grade, req.subject, req.gate_num)
        gkey = gate_key(req.grade, req.subject, req.gate_num)
        lang = LANGUAGES.get(req.language, LANGUAGES["english"])
        difficulty = normalize_difficulty(req.difficulty)

        topics_line = ", ".join(batch_topics)
        parsed = complete_json(
            "fast",
            "subject_gate",
            SUBJECT_GATE_PROMPT
            + f"\n\nLanguage: {lang['instruction']}\nGrade: {req.grade}\nSubject: {req.subject}"
            + f"\n{difficulty_instruction(difficulty)}",
            [{
                "role": "user",
                "content": (
                    f"Create the 20-question subject checkpoint for Grade {req.grade} "
                    f"{req.subject} covering these three topics: {topics_line}"
                ),
            }],
        )
        questions = validate_gate_questions(parsed.get("questions", []))
        exam_id = new_exam_id()
        full_exam = {
            "exam_id": exam_id,
            "gate_num": req.gate_num,
            "grade": req.grade,
            "subject": req.subject,
            "topics": batch_topics,
            "questions": questions,
        }
        _store_gate_exam(conn, exam_id, learner_id, gkey, full_exam)
        conn.commit()
        return {"exam": strip_exam_for_client(full_exam), "cached": False}
    except ValueError as ve:
        return JSONResponse({"error": str(ve)}, status_code=400)
    except Exception as e:
        logger.error(f"Subject gate exam failed: {type(e).__name__}: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)
    finally:
        conn.close()


@app.post("/api/subject-gate/submit")
async def submit_subject_gate(req: SubjectGateSubmitRequest):
    learner_id = req.learner_id.strip()
    if not learner_id or not req.exam_id.strip():
        return JSONResponse({"error": "learner_id and exam_id required"}, status_code=400)

    conn = _get_conn()
    try:
        exam = _load_gate_exam(conn, req.exam_id.strip(), learner_id)
        if not exam:
            return JSONResponse({"error": "Exam not found or expired"}, status_code=404)

        answer_map = {a.index: a.value for a in req.answers}
        ordered = [answer_map.get(i) for i in range(len(exam["questions"]))]
        result = grade_gate_exam(exam["questions"], ordered)

        store_gate_result(
            conn, learner_id,
            exam["grade"], exam["subject"], exam["gate_num"],
            exam["topics"],
            result["score"], result["total"], result["pct"], result["passed"],
        )
        conn.execute(
            "DELETE FROM subject_gate_exams WHERE exam_id = ?",
            (req.exam_id.strip(),),
        )
        conn.commit()

        status = build_gate_status(conn, learner_id, exam["grade"], exam["subject"])
        companion_result = None
        if result["passed"]:
            try:
                companion_result = _record_companion_event(learner_id, "gate_passed")
            except Exception as ce:
                logger.warning(f"Companion gate event: {ce}")
        _record_assessment(
            learner_id, "gate_exam",
            grade=exam["grade"], subject=exam["subject"],
            topic=f"gate_{exam['gate_num']}",
            correct=result["passed"],
            payload={"gate_exam": True, "pct": result["pct"], "is_novel": True},
        )
        return {
            "ok": True,
            "passed": result["passed"],
            "score": result["score"],
            "total": result["total"],
            "pct": result["pct"],
            "pass_pct": GATE_PASS_PCT,
            "results": result["results"],
            "gate_status": status,
            "companion": companion_result,
        }
    except Exception as e:
        logger.error(f"Subject gate submit failed: {type(e).__name__}: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)
    finally:
        conn.close()


@app.get("/api/gamification/catalog")
async def get_gamification_catalog():
    return gamification_catalog()


@app.get("/api/interests/catalog")
async def get_interests_catalog():
    return interest_catalog()


@app.get("/api/interests")
async def get_interests(learner_id: str):
    lid = learner_id.strip()
    if not lid:
        return JSONResponse({"error": "learner_id required"}, status_code=400)
    conn = _get_conn()
    try:
        cp = get_child_profile(conn, lid)
        return build_interest_model(conn, lid, cp)
    finally:
        conn.close()


@app.post("/api/interests/event")
async def post_interest_event(req: InterestEventRequest):
    lid = req.learner_id.strip()
    if not lid:
        return JSONResponse({"error": "learner_id required"}, status_code=400)
    conn = _get_conn()
    try:
        cp = get_child_profile(conn, lid)
        prefs = record_interest_event(conn, lid, req.event_type, req.payload, profile=cp)
        conn.commit()
        model = build_interest_model(conn, lid, cp)
        return {"ok": True, "preferences": prefs, "model": model}
    except Exception as e:
        logger.error(f"Interest event failed: {type(e).__name__}: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)
    finally:
        conn.close()


@app.get("/api/engagement/catalog")
async def get_engagement_catalog():
    return engagement_catalog()


@app.get("/api/know-more/catalog")
async def get_know_more_catalog():
    return know_more_catalog()


@app.post("/api/know-more/sparks")
async def know_more_sparks(req: KnowMoreSparksRequest):
    if req.grade not in CBSE_SYLLABUS:
        return JSONResponse({"error": "Invalid grade"}, status_code=400)
    if not req.story_text.strip():
        return JSONResponse({"error": "story_text required"}, status_code=400)

    embedded = extract_sparks_from_story(req.story_text)
    if len(embedded) >= 2:
        return {"sparks": embedded, "source": "embedded"}

    excerpt = req.story_text.strip()[:6000]
    try:
        parsed = complete_json(
            "fast",
            "know_more_sparks",
            sparks_detect_prompt(req.grade, req.subject, req.topic),
            [{
                "role": "user",
                "content": (
                    f"Story excerpt:\n{excerpt}\n\n"
                    f"Find curiosity sparks a Grade {req.grade} child might wonder about."
                ),
            }],
        )
        detected = validate_sparks(parsed)
        sparks = merge_sparks(embedded, detected)
        return {"sparks": sparks, "source": "detected"}
    except Exception as e:
        logger.error(f"Know-more sparks failed: {type(e).__name__}: {e}")
        if embedded:
            return {"sparks": embedded, "source": "embedded_fallback"}
        return JSONResponse({"error": str(e)}, status_code=500)


@app.post("/api/know-more/explore")
async def know_more_explore(req: KnowMoreExploreRequest):
    if req.grade not in CBSE_SYLLABUS:
        return JSONResponse({"error": "Invalid grade"}, status_code=400)
    question = req.question.strip()
    if not question:
        return JSONResponse({"error": "question required"}, status_code=400)

    path = [p.strip() for p in (req.path or []) if p.strip()]
    if question not in path:
        path = path + [question]
    depth = len(path)

    lang = LANGUAGES.get(req.language, LANGUAGES["english"])
    cache_key = exploration_cache_key(req.grade, question, path[:-1])
    conn = _get_conn()
    try:
        cached = get_cached_exploration(conn, cache_key)
        if cached:
            conn.commit()
            payload = {**cached, "cached": True}
            return payload

        system = explore_prompt(
            req.grade, req.subject, req.topic,
            lang["instruction"], path, depth,
        )
        user_content = f"Child's question: {question}\n"
        if req.story_excerpt.strip():
            user_content += f"\nStory context:\n{req.story_excerpt.strip()[:3000]}\n"
        if len(path) > 1:
            user_content += f"\nThey already explored: {' → '.join(path[:-1])}\n"

        parsed = complete_json(
            "fast",
            "know_more_explore",
            system,
            [{"role": "user", "content": user_content}],
        )
        exploration = validate_exploration(parsed, question, depth)
        exploration["path"] = path
        exploration["path_label"] = " → ".join(path)
        store_cached_exploration(conn, cache_key, req.grade, question, exploration)

        lid = (req.learner_id or "").strip()
        if lid:
            record_exploration_event(
                conn, lid, req.grade, req.subject, req.topic,
                question, path, depth,
            )
            try:
                _record_companion_event(lid, "know_more_explore")
            except Exception as ce:
                logger.warning(f"Companion know-more event: {ce}")
            try:
                record_interest_event(
                    conn, lid, "curiosity_explore",
                    {"subject": req.subject, "topic": req.topic, "question": question},
                )
            except Exception as ie:
                logger.warning(f"Interest know-more event: {ie}")
            _record_assessment(
                lid, "curiosity_explore",
                grade=req.grade, subject=req.subject, topic=req.topic,
                correct=True,
                payload={"depth": depth, "question_len": len(question)},
            )
        conn.commit()
        return {**exploration, "cached": False}
    except Exception as e:
        logger.error(f"Know-more explore failed: {type(e).__name__}: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)
    finally:
        conn.close()


@app.get("/api/create-story/catalog")
async def get_create_story_catalog():
    return creator_catalog()


@app.get("/api/create-story/mine")
async def get_my_created_stories(learner_id: str, limit: int = 12):
    lid = learner_id.strip()
    if not lid:
        return JSONResponse({"error": "learner_id required"}, status_code=400)
    conn = _get_conn()
    try:
        stories = list_created_stories(conn, lid, min(max(limit, 1), 24))
        return {"stories": stories}
    finally:
        conn.close()


@app.post("/api/create-story/generate")
async def create_story_generate(req: CreateStoryGenerateRequest):
    if req.grade not in CBSE_SYLLABUS:
        return JSONResponse({"error": "Invalid grade"}, status_code=400)
    try:
        choices = validate_choices(req.choices.model_dump())
    except ValueError as ve:
        return JSONResponse({"error": str(ve)}, status_code=400)

    cp = _load_child_profile(req.learner_id) if req.learner_id else None
    child_name = (cp or {}).get("name", "")
    reading_block = ""
    if cp and cp.get("reading_level"):
        reading_block = reading_level_instruction(cp["reading_level"])
    lang = LANGUAGES.get(req.language, LANGUAGES["english"])

    try:
        system = builder_story_prompt(
            req.grade, choices,
            child_name=child_name,
            subject=req.subject,
            topic=req.topic,
            language_instruction=lang["instruction"],
            reading_instruction=reading_block,
        )
        parsed = complete_json(
            "story",
            "child_story_generate",
            system,
            [{
                "role": "user",
                "content": (
                    f"Create a story from these choices for Grade {req.grade}.\n"
                    f"{choices_summary(choices)}"
                ),
            }],
        )
        result = validate_generated_story(parsed, choices)
        lid = (req.learner_id or "").strip()
        story_id = None
        if lid:
            conn = _get_conn()
            try:
                story_id = save_created_story(
                    conn, lid, "builder", result["title"], result["story"],
                    choices=choices,
                    meta={
                        "vocabulary": result["vocabulary"],
                        "structure": result["structure"],
                        "skills_practiced": result["skills_practiced"],
                        "praise": result["praise"],
                    },
                    grade=req.grade,
                    subject=req.subject,
                    topic=req.topic,
                )
                try:
                    _record_companion_event(lid, "story_created")
                except Exception as ce:
                    logger.warning(f"Companion story_created: {ce}")
                try:
                    record_interest_event(
                        conn, lid, "story_created",
                        {"subject": req.subject, "topic": req.topic, "mode": "builder"},
                        profile=cp,
                    )
                except Exception as ie:
                    logger.warning(f"Interest story_created: {ie}")
                _record_assessment(
                    lid, "story_creation",
                    grade=req.grade, subject=req.subject, topic=req.topic,
                    correct=True,
                    payload={"mode": "builder", "writing": True, "has_explanation": True},
                )
                conn.commit()
            finally:
                conn.close()
        return {**result, "story_id": story_id, "mode": "builder"}
    except Exception as e:
        logger.error(f"Create story generate failed: {type(e).__name__}: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)


@app.post("/api/create-story/continue")
async def create_story_continue(req: CreateStoryContinueRequest):
    if req.grade not in CBSE_SYLLABUS:
        return JSONResponse({"error": "Invalid grade"}, status_code=400)
    draft = (req.child_draft or "").strip()
    if len(draft) < 12:
        return JSONResponse(
            {"error": "Write at least a sentence or two — your ideas matter!"},
            status_code=400,
        )

    cp = _load_child_profile(req.learner_id) if req.learner_id else None
    child_name = (cp or {}).get("name", "")
    reading_block = ""
    if cp and cp.get("reading_level"):
        reading_block = reading_level_instruction(cp["reading_level"])
    lang = LANGUAGES.get(req.language, LANGUAGES["english"])

    try:
        system = continue_story_prompt(
            req.grade, draft,
            child_name=child_name,
            subject=req.subject,
            topic=req.topic,
            story_context=req.story_context,
            language_instruction=lang["instruction"],
            reading_instruction=reading_block,
        )
        parsed = complete_json(
            "story",
            "child_story_continue",
            system,
            [{"role": "user", "content": "Turn my draft into a full story, keeping my ideas."}],
        )
        result = validate_continued_story(parsed, draft)
        lid = (req.learner_id or "").strip()
        story_id = None
        if lid:
            conn = _get_conn()
            try:
                story_id = save_created_story(
                    conn, lid, "continue", result["title"], result["story"],
                    child_draft=draft,
                    meta={
                        "vocabulary": result["vocabulary"],
                        "skills_feedback": result["skills_feedback"],
                        "praise": result["praise"],
                        "child_words_preserved": result.get("child_words_preserved"),
                    },
                    grade=req.grade,
                    subject=req.subject,
                    topic=req.topic,
                )
                try:
                    _record_companion_event(lid, "story_created")
                except Exception as ce:
                    logger.warning(f"Companion story_created: {ce}")
                try:
                    record_interest_event(
                        conn, lid, "story_created",
                        {"subject": req.subject, "topic": req.topic, "mode": "continue"},
                        profile=cp,
                    )
                except Exception as ie:
                    logger.warning(f"Interest story_created: {ie}")
                _record_assessment(
                    lid, "story_creation",
                    grade=req.grade, subject=req.subject, topic=req.topic,
                    correct=True,
                    payload={"mode": "continue", "writing": True, "has_explanation": True},
                )
                conn.commit()
            finally:
                conn.close()
        return {**result, "story_id": story_id, "mode": "continue"}
    except Exception as e:
        logger.error(f"Create story continue failed: {type(e).__name__}: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)


@app.get("/api/reflection/catalog")
async def get_reflection_catalog():
    return reflection_catalog()


@app.get("/api/reflection/mine")
async def get_my_reflections(learner_id: str, limit: int = 20):
    lid = learner_id.strip()
    if not lid:
        return JSONResponse({"error": "learner_id required"}, status_code=400)
    conn = _get_conn()
    try:
        return {"reflections": list_reflections(conn, lid, min(max(limit, 1), 50))}
    finally:
        conn.close()


@app.post("/api/reflection/submit")
async def submit_reflection(req: ReflectionSubmitRequest):
    lid = req.learner_id.strip()
    if not lid:
        return JSONResponse({"error": "learner_id required"}, status_code=400)
    activity = (req.activity_type or "adventure").strip()
    if activity not in ACTIVITY_PROMPTS:
        return JSONResponse({"error": "Invalid activity_type"}, status_code=400)
    try:
        option = validate_option(req.option_id)
    except ValueError as ve:
        return JSONResponse({"error": str(ve)}, status_code=400)

    cp = _load_child_profile(lid)
    child_name = (cp or {}).get("name", "")
    own_words = (req.own_words or "").strip()
    reply = finn_reflection_reply(
        option,
        child_name=child_name,
        topic=req.topic,
        own_words=own_words,
    )

    if len(own_words) >= 40:
        try:
            ai_text = complete_text(
                "fast",
                own_words_prompt(
                    req.grade, activity, req.topic, option["id"],
                    own_words, child_name,
                ),
                [{"role": "user", "content": "Respond to the learner's reflection."}],
            ).strip()
            if ai_text:
                reply["message"] = ai_text
        except Exception as e:
            logger.warning(f"Reflection AI reply failed: {e}")

    conn = _get_conn()
    try:
        rid = save_reflection(
            conn, lid, activity, option["id"],
            grade=req.grade, subject=req.subject, topic=req.topic,
            own_words=own_words, finn_reply=reply["message"],
            meta={"next_step": reply.get("next_step")},
        )
        try:
            record_interest_event(
                conn, lid, "reflection",
                {
                    "option_id": option["id"],
                    "subject": req.subject,
                    "topic": req.topic,
                    "activity_type": activity,
                },
                profile=cp,
            )
        except Exception as ie:
            logger.warning(f"Interest reflection: {ie}")
        conn.commit()
    finally:
        conn.close()

    try:
        _record_companion_event(lid, "reflection_shared")
    except Exception as ce:
        logger.warning(f"Companion reflection: {ce}")

    _record_assessment(
        lid, "reflection",
        grade=req.grade, subject=req.subject, topic=req.topic,
        correct=True,
        payload={
            "option_id": option["id"],
            "has_own_words": bool(own_words),
            "reflection": True,
            "has_explanation": bool(own_words),
        },
    )

    if req.grade and req.subject and req.topic:
        try:
            adaptive_conn = _get_conn()
            engagement = "completed" if option["id"] == "want_challenge" else ""
            record_event(
                adaptive_conn, lid, "reflection", req.grade, req.subject, req.topic,
                correct=option["id"] != "difficult",
                engagement=engagement,
                payload={"option_id": option["id"]},
            )
            adaptive_conn.commit()
            adaptive_conn.close()
        except Exception as ae:
            logger.warning(f"Adaptive reflection: {ae}")

    prompt = ACTIVITY_PROMPTS.get(activity, ACTIVITY_PROMPTS["adventure"])
    return {
        "ok": True,
        "reflection_id": rid,
        "option": option,
        "finn_reply": reply["message"],
        "next_step": reply.get("next_step"),
        "prompt": prompt,
    }


@app.get("/api/adaptive/status")
async def adaptive_status(
    learner_id: str,
    grade: int,
    subject: str,
    topic: str,
):
    lid = learner_id.strip()
    if not lid:
        return JSONResponse({"error": "learner_id required"}, status_code=400)
    conn = _get_conn()
    try:
        return get_adaptive_status(conn, lid, grade, subject, topic)
    finally:
        conn.close()


@app.post("/api/adaptive/event")
async def adaptive_event(req: AdaptiveEventRequest):
    lid = req.learner_id.strip()
    if not lid:
        return JSONResponse({"error": "learner_id required"}, status_code=400)
    conn = _get_conn()
    try:
        state = record_event(
            conn, lid, req.event_type, req.grade, req.subject, req.topic,
            correct=req.correct, response_ms=req.response_ms, attempts=req.attempts,
            hints=req.hints, engagement=req.engagement, concept_tag=req.concept_tag,
        )
        conn.commit()
        return {
            "ok": True,
            "recommended_difficulty": state.get("difficulty", "medium"),
            "challenge_tier": state.get("challenge_tier", 3),
            "mastery_label": state.get("mastery_score", 0),
            "message": status_message(state),
        }
    except Exception as e:
        logger.error(f"Adaptive event failed: {type(e).__name__}: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)
    finally:
        conn.close()


@app.get("/api/story-world/activity-types")
async def story_world_activity_types():
    return activity_catalog_for_api()


@app.post("/api/story-world/start")
async def start_story_world(req: StoryWorldStartRequest):
    if req.grade not in CBSE_SYLLABUS:
        return JSONResponse({"error": "Invalid grade"}, status_code=400)

    blocked = _topic_access_guard(req.learner_id, req.grade, req.subject, req.topic)
    if blocked:
        return blocked

    learner_id = req.learner_id.strip()
    if not learner_id:
        return JSONResponse({"error": "learner_id required"}, status_code=400)

    lang = LANGUAGES.get(req.language, LANGUAGES["english"])
    genre = GENRES.get(req.genre, GENRES["realistic"])
    difficulty = _effective_difficulty(
        learner_id, req.grade, req.subject, req.topic, req.difficulty,
    )
    adaptive_block = _adaptive_prompt_for(learner_id, req.grade, req.subject, req.topic)
    cp = _load_child_profile(learner_id)
    interest_block = _learner_prompt_blocks(learner_id, req.genre)
    ncert_line = ncert_story_hint(req.grade, req.subject, req.topic)

    try:
        logger.info(f"Story World: Grade {req.grade} | {req.subject} > {req.topic}")
        parsed = complete_json(
            "story",
            "story_world",
            STORY_WORLD_PROMPT
            + f"\n\nLanguage: {lang['instruction']}\nGrade: {req.grade}\nSubject: {req.subject}\nTopic: {req.topic}"
            + f"\n{difficulty_instruction(difficulty)}"
            + f"\nGenre flavour: {genre['name']} — {genre['prompt'][:200]}"
            + child_profile_prompt_block(cp)
            + (f"\n{adaptive_block}" if adaptive_block else "")
            + (f"\n{_learner_prompt_blocks(learner_id, req.genre)}" if learner_id else ""),
            [{
                "role": "user",
                "content": (
                    f"Create a Story World teaching Grade {req.grade} {req.subject}: {req.topic}\n"
                    f"{ncert_line}\n"
                    f"Chapter 1 scene 1 should hook the reader like 'The Hidden Door' — "
                    f"discovery + an in-story puzzle that uses the topic."
                ),
            }],
        )
        world = validate_world(parsed)
        world_id = new_world_id()
        start_id = first_scene_id(world)
        progress = default_progress(start_id)
        cache_key = f"{req.grade}|{req.subject}|{req.topic}|{req.language}|{req.genre}|{difficulty}"

        conn = _get_conn()
        try:
            save_session(conn, world_id, learner_id, cache_key, world, progress)
            conn.commit()
        finally:
            conn.close()

        _record_interest(learner_id, "genre_pick", {"genre": req.genre})
        _record_interest(learner_id, "subject_pick", {"subject": req.subject})

        client_world = strip_world_for_client(world)
        return {
            "world_id": world_id,
            "world": client_world,
            "progress": progress,
            "current_scene": _scene_payload(client_world, start_id),
        }
    except ValueError as ve:
        return JSONResponse({"error": str(ve)}, status_code=400)
    except Exception as e:
        logger.error(f"Story World start failed: {type(e).__name__}: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)


def _scene_payload(world: dict, scene_id: str) -> Optional[dict]:
    sc = scene_by_id(world, scene_id)
    if not sc:
        return None
    sc = enrich_scene_for_playback(sc, world)
    loc = next((l for l in world.get("locations", []) if l.get("id") == sc.get("location_id")), None)
    chars = [c for c in world.get("characters", []) if c.get("id") in (sc.get("character_ids") or [])]
    return {"scene": sc, "location": loc, "characters": chars}


@app.post("/api/story-world/answer")
async def story_world_answer(req: StoryWorldAnswerRequest):
    learner_id = req.learner_id.strip()
    if not learner_id or not req.world_id.strip():
        return JSONResponse({"error": "learner_id and world_id required"}, status_code=400)

    conn = _get_conn()
    try:
        loaded = load_session(conn, req.world_id.strip(), learner_id)
        if not loaded:
            return JSONResponse({"error": "Story world not found"}, status_code=404)
        world, progress = loaded
        scene = scene_by_id(world, req.scene_id)
        if not scene:
            return JSONResponse({"error": "Scene not found"}, status_code=404)
        challenge = scene.get("challenge") or {}
        if (challenge.get("type") or "none") == "none":
            return JSONResponse({"error": "This scene has no challenge"}, status_code=400)

        correct = check_challenge_answer(challenge, req.answer)

        mistake_payload = None

        if not correct:
            mistake = analyze_mistake(challenge, req.answer)
            mini_bundle = build_mini_practice(challenge, req.scene_id)
            record_wrong_attempt(progress, req.scene_id, mini_bundle)
            cp = get_child_profile(conn, learner_id)
            child_name = (cp or {}).get("name", "")
            finn = coach_message(
                "wrong",
                question=challenge.get("question", ""),
                hint=challenge.get("hint", ""),
                attempt=req.attempts,
                child_name=child_name,
            )
            finn["message"] = mistake["finn_message"]
            finn["follow_up"] = "Complete the mini practice below, then retry the story challenge!"
            mistake_payload = {
                **mistake,
                "finn": finn,
                "mini_practice": mini_client,
                "recovery": get_recovery(progress, req.scene_id),
                "requires_mini_practice": True,
            }
            result = {
                "correct": False,
                "narrative": challenge.get("failure_narrative", ""),
                "explanation": challenge.get("explanation", ""),
                "reward": None,
                "next_scene_id": None,
                "progress": progress,
                "world_complete": False,
            }
        else:
            result = apply_challenge_result(world, progress, req.scene_id, correct)

        row = conn.execute(
            "SELECT cache_key FROM story_world_sessions WHERE world_id = ? AND learner_id = ?",
            (req.world_id.strip(), learner_id),
        ).fetchone()
        if row and row["cache_key"]:
            parts = row["cache_key"].split("|")
            if len(parts) >= 3:
                try:
                    record_event(
                        conn, learner_id, "story_challenge", int(parts[0]), parts[1], parts[2],
                        correct=correct, response_ms=req.response_ms,
                        attempts=req.attempts, hints=req.hints,
                    )
                    observe_gameplay(
                        conn, learner_id, "story_challenge",
                        grade=int(parts[0]), subject=parts[1], topic=parts[2],
                        correct=correct, response_ms=req.response_ms,
                        attempts=req.attempts, hints=req.hints,
                        payload={"activity_type": challenge.get("activity_type")},
                    )
                except Exception as ae:
                    logger.warning(f"Adaptive story challenge record: {ae}")

        save_session(conn, req.world_id.strip(), learner_id, "", world, progress)
        conn.commit()

        act_type = challenge.get("activity_type") or challenge.get("type") or ""
        if correct and act_type and act_type != "none":
            try:
                _record_interest(learner_id, "activity_complete", {"activity_type": act_type})
            except Exception as ie:
                logger.warning(f"Interest activity record: {ie}")

        client_world = strip_world_for_client(world)
        topic_name = ""
        if row and row["cache_key"]:
            parts = row["cache_key"].split("|")
            if len(parts) >= 3:
                topic_name = parts[2]
        cp = get_child_profile(conn, learner_id)
        child_name = (cp or {}).get("name", "")
        finn = None
        if correct:
            finn = coach_message(
                "celebrate",
                topic=topic_name,
                question=challenge.get("question", ""),
                attempt=req.attempts,
                child_name=child_name,
            )
        payload = {
            "ok": True,
            "correct": correct,
            "narrative": result["narrative"],
            "explanation": result.get("explanation", ""),
            "reward": result.get("reward"),
            "progress": progress,
            "world_complete": result.get("world_complete", False),
            "finn": finn,
        }
        if mistake_payload:
            payload["mistake_learning"] = mistake_payload
            payload["finn"] = mistake_payload.get("finn")
        if correct:
            try:
                evt = "story_world_complete" if result.get("world_complete") else "challenge_solved"
                payload["companion"] = _record_companion_event(learner_id, evt)
            except Exception as ce:
                logger.warning(f"Companion challenge event: {ce}")
        if result.get("next_scene_id"):
            payload["next_scene"] = _scene_payload(client_world, result["next_scene_id"])
        if progress.get("ending_id"):
            ending = get_ending(world, progress["ending_id"])
            if ending:
                payload["ending"] = ending
        if row and row["cache_key"]:
            parts = row["cache_key"].split("|")
            if len(parts) >= 3:
                try:
                    payload["adaptive"] = get_adaptive_status(
                        conn, learner_id, int(parts[0]), parts[1], parts[2],
                    )
                except Exception:
                    pass
        return payload
    except Exception as e:
        logger.error(f"Story World answer failed: {type(e).__name__}: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)
    finally:
        conn.close()


@app.post("/api/story-world/mini-practice/submit")
async def story_world_mini_practice(req: StoryWorldMiniPracticeRequest):
    learner_id = req.learner_id.strip()
    if not learner_id or not req.world_id.strip():
        return JSONResponse({"error": "learner_id and world_id required"}, status_code=400)

    conn = _get_conn()
    try:
        loaded = load_session(conn, req.world_id.strip(), learner_id)
        if not loaded:
            return JSONResponse({"error": "Story world not found"}, status_code=404)
        world, progress = loaded
        mini = load_mini_practice(progress, req.scene_id.strip())
        if not mini:
            return JSONResponse({"error": "No mini practice for this scene"}, status_code=404)

        correct = check_mini_practice(mini, req.answer)
        finn = coach_message("celebrate" if correct else "wrong", attempt=1)
        if correct:
            mark_mini_practice_done(progress, req.scene_id.strip())
            finn["message"] = (
                f"**Yes!** 🦊 {mini.get('success_narrative', 'Mini practice complete!')}"
            )
            finn["follow_up"] = "Now retry the story challenge — you've got this!"
        else:
            finn["message"] = (
                f"**Almost!** 🦊 {mini.get('failure_narrative', 'Try the mini practice once more.')}"
            )
            finn["follow_up"] = mini.get("hint", "Count carefully and try again.")

        save_session(conn, req.world_id.strip(), learner_id, "", world, progress)
        conn.commit()

        companion_result = None
        if correct:
            companion_result = _record_companion_event(learner_id, "mini_practice_done")
            row = conn.execute(
                "SELECT cache_key FROM story_world_sessions WHERE world_id = ? AND learner_id = ?",
                (req.world_id.strip(), learner_id),
            ).fetchone()
            parts = (row["cache_key"].split("|") if row and row["cache_key"] else [])
            if len(parts) >= 3:
                _record_assessment(
                    learner_id, "mini_practice",
                    grade=int(parts[0]), subject=parts[1], topic=parts[2],
                    correct=True, payload={"mistake_recovery": True},
                )
        else:
            row = conn.execute(
                "SELECT cache_key FROM story_world_sessions WHERE world_id = ? AND learner_id = ?",
                (req.world_id.strip(), learner_id),
            ).fetchone()
            parts = (row["cache_key"].split("|") if row and row["cache_key"] else [])
            if len(parts) >= 3:
                _record_assessment(
                    learner_id, "mini_practice",
                    grade=int(parts[0]), subject=parts[1], topic=parts[2],
                    correct=False,
                )

        return {
            "ok": True,
            "correct": correct,
            "explanation": mini.get("explanation", ""),
            "finn": finn,
            "recovery": get_recovery(progress, req.scene_id.strip()),
            "retry_unlocked": correct,
            "companion": companion_result,
        }
    except Exception as e:
        logger.error(f"Mini practice failed: {type(e).__name__}: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)
    finally:
        conn.close()


@app.post("/api/mistake/analyze")
async def mistake_analyze(req: MistakeAnalyzeRequest):
    """Diagnose a wrong answer and optionally return a mini practice."""
    ch = normalize_challenge(req.challenge)
    if get_interaction(ch) == "none":
        return JSONResponse({"error": "No challenge to analyze"}, status_code=400)
    mistake = analyze_mistake(ch, req.user_answer)
    mini_bundle = build_mini_practice(ch, req.context or "quiz")
    return {
        "ok": True,
        "mistake_learning": {
            **mistake,
            "mini_practice": mini_bundle["client"],
        },
    }


@app.post("/api/story-world/choose")
async def story_world_choose(req: StoryWorldChoiceRequest):
    learner_id = req.learner_id.strip()
    if not learner_id or not req.world_id.strip():
        return JSONResponse({"error": "learner_id and world_id required"}, status_code=400)

    conn = _get_conn()
    try:
        loaded = load_session(conn, req.world_id.strip(), learner_id)
        if not loaded:
            return JSONResponse({"error": "Story world not found"}, status_code=404)
        world, progress = loaded
        result = apply_choice(world, progress, req.scene_id, req.choice_id)
        save_session(conn, req.world_id.strip(), learner_id, "", world, progress)
        conn.commit()

        client_world = strip_world_for_client(world)
        payload = {
            "ok": True,
            "consequence": result["consequence"],
            "learning_note": result.get("learning_note", ""),
            "outcome": result.get("outcome"),
            "reward": result.get("reward"),
            "progress": progress,
            "world_complete": result.get("world_complete", False),
        }
        try:
            payload["companion"] = _record_companion_event(learner_id, "dilemma_choice")
        except Exception as ce:
            logger.warning(f"Companion dilemma event: {ce}")
        row = conn.execute(
            "SELECT cache_key FROM story_world_sessions WHERE world_id = ? AND learner_id = ?",
            (req.world_id.strip(), learner_id),
        ).fetchone()
        parts = (row["cache_key"].split("|") if row and row["cache_key"] else [])
        if len(parts) >= 3:
            _record_assessment(
                learner_id, "dilemma_choice",
                grade=int(parts[0]), subject=parts[1], topic=parts[2],
                correct=True,
                payload={
                    "choice_id": req.choice_id,
                    "prediction": True,
                    "reflection": bool(result.get("learning_note")),
                },
            )
        if result.get("next_scene_id"):
            payload["next_scene"] = _scene_payload(client_world, result["next_scene_id"])
        if progress.get("ending_id"):
            ending = get_ending(world, progress["ending_id"])
            if ending:
                payload["ending"] = ending
        return payload
    except ValueError as ve:
        return JSONResponse({"error": str(ve)}, status_code=400)
    except Exception as e:
        logger.error(f"Story World choose failed: {type(e).__name__}: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)
    finally:
        conn.close()


@app.get("/api/ncert")
async def get_ncert_chapter(grade: int, subject: str, topic: str):
    """Map a StorySchool topic to the closest official NCERT textbook chapter."""
    if grade not in CBSE_SYLLABUS:
        return JSONResponse({"error": "Invalid grade"}, status_code=400)
    if not topic.strip():
        return JSONResponse({"error": "Topic required"}, status_code=400)

    result = lookup_ncert_chapter(grade, subject, topic.strip())
    if not result:
        return JSONResponse(
            {"error": f"No NCERT book mapped for Grade {grade} {subject}"},
            status_code=404,
        )
    return result


@app.get("/api/study-videos/catalog")
async def get_study_videos_catalog():
    return study_videos_catalog()


@app.get("/api/study-videos")
async def get_study_videos(
    grade: int,
    subject: str,
    topic: str,
    learner_id: str = "",
):
    """Curated age-appropriate YouTube videos for further study on a topic."""
    if grade not in CBSE_SYLLABUS:
        return JSONResponse({"error": "Invalid grade"}, status_code=400)
    if not topic.strip():
        return JSONResponse({"error": "Topic required"}, status_code=400)

    controls = None
    lid = learner_id.strip()
    if lid:
        conn = _get_conn()
        try:
            controls = get_parent_controls(conn, lid)
        finally:
            conn.close()

    allowed = external_links_allowed(controls)
    result = lookup_study_videos(grade, subject, topic.strip())
    result["links_enabled"] = allowed
    if not allowed:
        result["parent_note"] = (
            "Ask a parent to enable “References to external websites” "
            "in Parent Controls to open YouTube links."
        )
    return result


@app.get("/api/explain/stream")
async def explain_topic_stream(
    grade: int,
    subject: str,
    topic: str,
    language: str = "english",
    genre: str = "realistic",
    novel_name: str = "",
    difficulty: str = "medium",
    skip_cache: bool = False,
    learner_id: str = "",
):
    """Streams the story as SSE events, plus a 'thinking' event stream showing
    the model's reasoning summary in real time (where the model supports it)."""
    if grade not in CBSE_SYLLABUS:
        return JSONResponse({"error": "Invalid grade"}, status_code=400)

    blocked = _topic_access_guard(learner_id, grade, subject, topic)
    if blocked:
        return blocked

    difficulty = _effective_difficulty(learner_id, grade, subject, topic, difficulty)
    adaptive_block = _adaptive_prompt_for(learner_id, grade, subject, topic)
    cache_key = _story_cache_key(
        grade, subject, topic, language, genre, novel_name, difficulty,
    )
    cp = _load_child_profile(learner_id)
    system = build_story_prompt(
        grade, language, genre, novel_name or "", difficulty,
        child_profile=cp, adaptive_block=adaptive_block,
        interest_block=_learner_prompt_blocks(learner_id, genre),
    )

    async def event_generator():
        try:
            if not skip_cache:
                cached = get_cached_story(cache_key)
                if cached:
                    logger.info(
                        f"Cache HIT story (stream): hits={cached['hits']} | "
                        f"Grade {grade} | {subject} > {topic} | diff={difficulty}"
                    )
                    yield f"event: token\ndata: {json.dumps({'delta': cached['story']})}\n\n"
                    yield "event: done\ndata: {}\n\n"
                    return

            logger.info(f"Story (stream): Grade {grade} | {subject} > {topic} | "
                        f"lang={language} genre={genre} diff={difficulty}")
            story_text = ""
            async for event_type, payload in stream_text(
                "story",
                system,
                [{
                    "role": "user",
                    "content": _build_story_user_message(grade, subject, topic),
                }],
            ):
                if event_type == "thinking":
                    yield f"event: thinking\ndata: {json.dumps({'delta': payload})}\n\n"

                elif event_type == "token":
                    story_text += payload
                    yield f"event: token\ndata: {json.dumps({'delta': payload})}\n\n"

                elif event_type == "completed":
                    if story_text:
                        try:
                            store_cached_story(
                                cache_key, grade, subject, topic,
                                language, genre, novel_name, story_text,
                            )
                        except Exception as ce:
                            logger.warning(f"Failed to store story cache: {ce}")
                    yield "event: done\ndata: {}\n\n"

                elif event_type == "error":
                    yield f"event: error\ndata: {json.dumps({'error': payload})}\n\n"

        except Exception as e:
            logger.error(f"Story stream failed: {type(e).__name__}: {e}")
            yield f"event: error\ndata: {json.dumps({'error': f'{type(e).__name__}: {e}'})}\n\n"

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache, no-store",
            "X-Accel-Buffering": "no",  # disable nginx buffering, if you're behind nginx
            "Connection": "keep-alive",
        },
    )


@app.post("/api/explain")
async def explain_topic(req: ExplainRequest):
    if req.grade not in CBSE_SYLLABUS:
        return JSONResponse({"error": "Invalid grade"}, status_code=400)

    # === Cache check ===
    difficulty = _effective_difficulty(
        req.learner_id, req.grade, req.subject, req.topic, req.difficulty,
    )
    cache_key = _story_cache_key(
        req.grade, req.subject, req.topic, req.language, req.genre, req.novel_name, difficulty,
    )
    if not req.skip_cache:
        cached = get_cached_story(cache_key)
        if cached:
            logger.info(f"Cache HIT story: hits={cached['hits']} | Grade {req.grade} | {req.subject} > {req.topic}")
            return {"story": cached["story"], "cached": True, "cache_hits": cached["hits"]}

    adaptive_block = _adaptive_prompt_for(req.learner_id, req.grade, req.subject, req.topic)
    system = build_story_prompt(
        req.grade, req.language, req.genre, req.novel_name or "", difficulty,
        child_profile=_load_child_profile(req.learner_id),
        adaptive_block=adaptive_block,
        interest_block=_learner_prompt_blocks(req.learner_id, req.genre),
    )

    try:
        logger.info(f"Story (MISS): Grade {req.grade} | {req.subject} > {req.topic} | "
                     f"lang={req.language} genre={req.genre} diff={difficulty}")
        story_text = complete_text(
            "story",
            system,
            [{
                "role": "user",
                "content": _build_story_user_message(req.grade, req.subject, req.topic),
            }],
        )

        # Save to cache in background
        try:
            store_cached_story(cache_key, req.grade, req.subject, req.topic,
                               req.language, req.genre, req.novel_name, story_text)
        except Exception as ce:
            logger.warning(f"Failed to store story cache: {ce}")

        return {"story": story_text, "cached": False}

    except Exception as e:
        logger.error(f"Story failed: {type(e).__name__}: {e}")
        return JSONResponse(
            {"error": f"{type(e).__name__}: {str(e)}"},
            status_code=500,
        )


@app.post("/api/document/generate")
async def generate_from_document(
    file: UploadFile = File(...),
    action: str = Form(...),
    grade: int = Form(...),
    subject: str = Form(""),
    topic: str = Form(""),
    language: str = Form("english"),
    genre: str = Form("realistic"),
    difficulty: str = Form("medium"),
    learner_id: str = Form(""),
):
    """Generate a story or a question set from a learner-uploaded document.

    The action is chosen by the user (no auto-classification):
    - "story"     → a Professor Giggles comedy story built around the uploaded chapter.
    - "questions" → a new question set matching the uploaded bank's pattern, one notch harder.

    Text is extracted server-side (PDF/DOCX/TXT) and passed through the normal text
    helpers. These outputs are intentionally NOT cached — each upload is ad-hoc and the
    story/quiz cache keys don't encode document identity, so caching would poison results.
    """
    act = (action or "").strip().lower()
    if act not in ("story", "questions"):
        raise HTTPException(status_code=400, detail="Unknown action (use 'story' or 'questions').")

    filename = file.filename or ""
    ext = document_ingest.file_ext(filename)
    if ext not in document_ingest.ALLOWED_EXTS:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file type '{ext or '?'}'. Upload a PDF, Word (.docx), or text (.txt) file.",
        )

    data = await file.read()
    if not data:
        raise HTTPException(status_code=400, detail="The uploaded file is empty.")
    if len(data) > document_ingest.MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=400, detail="File is too large (max 5 MB).")

    try:
        raw = document_ingest.extract_text(filename, data)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.warning(f"Document extract failed for {filename!r}: {type(e).__name__}: {e}")
        raise HTTPException(
            status_code=400,
            detail="Couldn't read that file. It may be corrupted or password-protected.",
        )

    text = document_ingest.clean_text(raw)
    if not text:
        raise HTTPException(
            status_code=400,
            detail="Couldn't read any text from that file. A scanned PDF (image only) has no text layer to read.",
        )
    if len(raw) > document_ingest.MAX_CHARS:
        logger.info(f"Document truncated to {document_ingest.MAX_CHARS} chars (from {len(raw)}).")

    diff = normalize_difficulty(difficulty)

    if act == "story":
        try:
            logger.info(f"Doc story: Grade {grade} | {subject} | file={filename!r} | {len(text)} chars")
            system = build_story_prompt(
                grade, language, genre, "", diff,
                child_profile=_load_child_profile(learner_id),
            )
            story_text = complete_text(
                "story",
                system,
                [{"role": "user", "content": _build_doc_story_user_message(grade, subject, topic, text)}],
            )
            return {"mode": "story", "story": story_text, "source_filename": filename}
        except Exception as e:
            logger.error(f"Doc story failed: {type(e).__name__}: {e}")
            return JSONResponse({"error": f"{type(e).__name__}: {str(e)}"}, status_code=500)

    # act == "questions"
    try:
        logger.info(f"Doc questions: Grade {grade} | {subject} | file={filename!r} | {len(text)} chars")
        instructions = (
            QUESTION_SET_PROMPT
            + f"\n\nGrade level: {grade}\nSubject: {subject or 'general'}\n"
            + difficulty_instruction(diff)
        )
        question_set = complete_json(
            "fast",
            "question_set",
            instructions,
            [{"role": "user", "content": _build_doc_questions_user_message(grade, subject, text)}],
        )
        return {"mode": "questions", "question_set": question_set, "source_filename": filename}
    except Exception as e:
        logger.error(f"Doc questions failed: {type(e).__name__}: {e}")
        return JSONResponse({"error": f"{type(e).__name__}: {str(e)}"}, status_code=500)


@app.post("/api/flashcards")
async def generate_flashcards(req: FlashcardRequest):
    lang = LANGUAGES.get(req.language, LANGUAGES["english"])
    difficulty = normalize_difficulty(req.difficulty)

    # === Flashcard cache check ===
    fkey = _flash_cache_key(req.grade, req.subject, req.topic, req.language, difficulty)
    cached = get_cached_flashcards(fkey)
    if cached:
        logger.info(f"Cache HIT flashcards: hits={cached['hits']} | Grade {req.grade} | {req.subject} > {req.topic}")
        return {"cards": cached["cards"], "cached": True, "cache_hits": cached["hits"]}

    try:
        logger.info(f"Flashcards (MISS): Grade {req.grade} | {req.subject} > {req.topic}")
        cp = _load_child_profile(req.learner_id)
        parsed = complete_json(
            "fast",
            "flashcards",
            FLASHCARD_PROMPT
            + f"\n\nLanguage: {lang['instruction']}\nGrade level: {req.grade}"
            + f"\n{difficulty_instruction(difficulty)}"
            + child_profile_prompt_block(cp),
            [{
                "role": "user",
                "content": f"Create flash cards for Grade {req.grade} {req.subject}: {req.topic}",
            }],
        )
        cards = parsed["cards"]
        # Save to cache
        try:
            store_cached_flashcards(fkey, req.grade, req.subject, req.topic, req.language, cards)
        except Exception as ce:
            logger.warning(f"Failed to store flashcard cache: {ce}")
        return {"cards": cards, "cached": False}
    except Exception as e:
        logger.error(f"Flashcards failed: {type(e).__name__}: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)


@app.post("/api/mindmap")
async def generate_mindmap(req: MindmapRequest):
    lang = LANGUAGES.get(req.language, LANGUAGES["english"])
    difficulty = normalize_difficulty(req.difficulty)

    mkey = _mindmap_cache_key(req.grade, req.subject, req.topic, req.language, difficulty)
    cached = get_cached_mindmap(mkey)
    if cached:
        logger.info(
            f"Cache HIT mindmap: hits={cached['hits']} | "
            f"Grade {req.grade} | {req.subject} > {req.topic}"
        )
        return {"diagram": cached["diagram"], "cached": True, "cache_hits": cached["hits"]}

    try:
        logger.info(f"Mindmap (MISS): Grade {req.grade} | {req.subject} > {req.topic}")
        cp = _load_child_profile(req.learner_id)
        diagram = complete_json(
            "fast",
            "mindmap",
            MINDMAP_PROMPT
            + f"\n\nLanguage: {lang['instruction']}\nGrade level: {req.grade}"
            + f"\n{difficulty_instruction(difficulty)}"
            + child_profile_prompt_block(cp),
            [{
                "role": "user",
                "content": f"Create a mind map for Grade {req.grade} {req.subject}: {req.topic}",
            }],
        )
        if not diagram.get("mermaid", "").strip().startswith("mindmap"):
            raise ValueError("Invalid mind map diagram from model")

        try:
            store_cached_mindmap(mkey, req.grade, req.subject, req.topic, req.language, diagram)
        except Exception as ce:
            logger.warning(f"Failed to store mindmap cache: {ce}")

        return {"diagram": diagram, "cached": False}
    except Exception as e:
        logger.error(f"Mindmap failed: {type(e).__name__}: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)


@app.post("/api/quiz")
async def generate_quiz(req: QuizRequest):
    blocked = _topic_access_guard(req.learner_id, req.grade, req.subject, req.topic)
    if blocked:
        return blocked
    lang = LANGUAGES.get(req.language, LANGUAGES["english"])
    difficulty = _effective_difficulty(
        req.learner_id, req.grade, req.subject, req.topic, req.difficulty,
    )
    adaptive_block = _adaptive_prompt_for(req.learner_id, req.grade, req.subject, req.topic)

    qkey = _quiz_cache_key(req.grade, req.subject, req.topic, req.language, difficulty)
    cached = get_cached_quiz(qkey)
    if cached:
        logger.info(
            f"Cache HIT quiz: hits={cached['hits']} | "
            f"Grade {req.grade} | {req.subject} > {req.topic}"
        )
        return {"quiz": cached["quiz"], "cached": True, "cache_hits": cached["hits"]}

    try:
        logger.info(f"Quiz (MISS): Grade {req.grade} | {req.subject} > {req.topic}")
        cp = _load_child_profile(req.learner_id)
        parsed = complete_json(
            "fast",
            "quiz",
            QUIZ_PROMPT
            + f"\n\nLanguage: {lang['instruction']}\nGrade level: {req.grade}"
            + f"\n{difficulty_instruction(difficulty)}"
            + child_profile_prompt_block(cp)
            + (f"\n{adaptive_block}" if adaptive_block else "")
            + (f"\n{_learner_prompt_blocks(req.learner_id, req.genre)}" if req.learner_id else ""),
            [{
                "role": "user",
                "content": f"Create a quiz for Grade {req.grade} {req.subject}: {req.topic}",
            }],
        )
        questions = _validate_quiz_questions(parsed.get("questions", []))
        quiz = {"questions": questions}

        try:
            store_cached_quiz(qkey, req.grade, req.subject, req.topic, req.language, quiz)
        except Exception as ce:
            logger.warning(f"Failed to store quiz cache: {ce}")

        return {"quiz": quiz, "cached": False}
    except Exception as e:
        logger.error(f"Quiz failed: {type(e).__name__}: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)


@app.post("/api/quiz/submit")
async def submit_quiz(req: QuizSubmitRequest):
    if req.total <= 0 or req.score < 0 or req.score > req.total:
        return JSONResponse({"error": "Invalid score"}, status_code=400)

    pct = round((req.score / req.total) * 100)
    if pct >= 90:
        tier = "gold"
    elif pct >= 60:
        tier = "silver"
    else:
        tier = "bronze"

    topic_key = _quiz_topic_key(req.grade, req.subject, req.topic)
    try:
        best_tier = store_quiz_mastery(
            topic_key, req.grade, req.subject, req.topic,
            req.score, req.total, pct, tier,
        )
        logger.info(
            f"Quiz submit: {topic_key} | {req.score}/{req.total} ({pct}%) tier={tier}"
        )
        mastery = get_quiz_mastery(topic_key)
        if req.learner_id and req.learner_id.strip():
            try:
                record_learning_step(
                    req.learner_id.strip(),
                    req.grade,
                    req.subject,
                    req.topic,
                    req.difficulty,
                    "quiz",
                    quiz_tier=tier,
                    quiz_pct=pct,
                )
            except Exception as pe:
                logger.warning(f"Learning progress quiz step failed: {pe}")
            if req.wrong_items:
                try:
                    seeded = _seed_spaced_wrong_items(
                        req.learner_id.strip(),
                        req.grade, req.subject, req.topic,
                        req.wrong_items,
                    )
                    logger.info(f"Spaced rep: seeded {seeded} wrong quiz items for {topic_key}")
                except Exception as se:
                    logger.warning(f"Spaced rep seed failed: {se}")
            _record_adaptive(
                req.learner_id, "quiz", req.grade, req.subject, req.topic,
                correct=(pct >= 60),
                hints=len(req.wrong_items or []),
            )
        adaptive_info = None
        if req.learner_id and req.learner_id.strip():
            conn = _get_conn()
            try:
                adaptive_info = get_adaptive_status(
                    conn, req.learner_id.strip(), req.grade, req.subject, req.topic,
                )
            finally:
                conn.close()
        companion_result = None
        if req.learner_id and req.learner_id.strip():
            companion_result = _record_companion_event(
                req.learner_id.strip(), f"quiz_{tier}",
            )
        return {
            "ok": True, "tier": tier, "pct": pct, "mastery": mastery,
            "adaptive": adaptive_info,
            "companion": companion_result,
        }
    except Exception as e:
        logger.error(f"Quiz submit failed: {type(e).__name__}: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)


_recent_puzzles: list[str] = []  # in-memory history to avoid repeats


@app.get("/api/puzzle")
async def get_puzzle():
    try:
        puzzle_type = random.choice(PUZZLE_TYPES)
        logger.info(f"Puzzle: type={puzzle_type}")
        nonce = uuid.uuid4().hex[:8]

        avoid_block = ""
        if _recent_puzzles:
            recent_list = "\n".join(f"- {p}" for p in _recent_puzzles[-5:])
            avoid_block = (
                f"\n\nDo NOT repeat or closely resemble any of these recent puzzles:\n{recent_list}"
            )

        puzzle = complete_json(
            "fast",
            "puzzle",
            PUZZLE_PROMPT,
            [{
                "role": "user",
                "content": (
                    f"Give me a fun brain break puzzle of this type: {puzzle_type}. "
                    f"(request id: {nonce}){avoid_block}"
                ),
            }],
        )

        content_key = puzzle.get("content", "")[:120]
        _recent_puzzles.append(content_key)
        if len(_recent_puzzles) > 10:
            _recent_puzzles.pop(0)

        return JSONResponse(
            puzzle,
            headers={"Cache-Control": "no-store, no-cache, must-revalidate", "Pragma": "no-cache"},
        )
    except Exception as e:
        logger.error(f"Puzzle failed: {type(e).__name__}: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)


@app.post("/api/puzzle")
async def get_puzzle_topic(req: PuzzleRequest):
    """If grade + subject + topic are provided, generate a topic-relevant puzzle.
    Otherwise, falls back to a random brain-break puzzle (identical to GET /api/puzzle)."""
    has_context = bool(req.grade and req.subject and req.topic)

    try:
        nonce = uuid.uuid4().hex[:8]
        if has_context:
            puzzle_type = random.choice(TOPIC_PUZZLE_TYPES)
            lang = LANGUAGES.get(req.language, LANGUAGES["english"])
            logger.info(f"Topic Puzzle [{puzzle_type[:30]}]: Grade {req.grade} | {req.subject} > {req.topic}")
            difficulty = normalize_difficulty(req.difficulty)
            puzzle = complete_json(
                "fast",
                "puzzle",
                TOPIC_PUZZLE_PROMPT
                + f"\n\nLanguage: {lang['instruction']}\n{difficulty_instruction(difficulty)}",
                [{
                    "role": "user",
                    "content": (
                        f"Grade: {req.grade}\nSubject: {req.subject}\nTopic: {req.topic}\n\n"
                        f"Puzzle type to use: {puzzle_type}\n\n"
                        f"Generate an educational, topic-relevant puzzle! (request id: {nonce})"
                    ),
                }],
            )
        else:
            puzzle_type = random.choice(PUZZLE_TYPES)
            logger.info(f"Puzzle (POST no context): type={puzzle_type}")
            avoid_block = ""
            if _recent_puzzles:
                recent_list = "\n".join(f"- {p}" for p in _recent_puzzles[-5:])
                avoid_block = (
                    f"\n\nDo NOT repeat or closely resemble any of these recent puzzles:\n{recent_list}"
                )
            puzzle = complete_json(
                "fast",
                "puzzle",
                PUZZLE_PROMPT,
                [{
                    "role": "user",
                    "content": (
                        f"Give me a fun brain break puzzle of this type: {puzzle_type}. "
                        f"(request id: {nonce}){avoid_block}"
                    ),
                }],
            )

        if not has_context:
            content_key = puzzle.get("content", "")[:120]
            _recent_puzzles.append(content_key)
            if len(_recent_puzzles) > 10:
                _recent_puzzles.pop(0)

        return JSONResponse(
            puzzle,
            headers={"Cache-Control": "no-store, no-cache, must-revalidate", "Pragma": "no-cache"},
        )
    except Exception as e:
        logger.error(f"Topic Puzzle failed: {type(e).__name__}: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)


@app.post("/api/adventure")
async def adventure_chapter(req: AdventureRequest):
    if req.grade not in CBSE_SYLLABUS:
        return JSONResponse({"error": "Invalid grade"}, status_code=400)

    difficulty = normalize_difficulty(req.difficulty)
    cp = _load_child_profile(req.learner_id)
    interest_block = _learner_prompt_blocks(req.learner_id, req.genre)
    system = build_adventure_prompt(
        req.grade, req.language, req.genre, req.novel_name or "", difficulty,
        child_profile=cp, interest_block=interest_block,
    )
    messages = _build_adventure_messages(req)

    try:
        chapter_num = len([m for m in messages if m["role"] == "assistant"]) + 1
        logger.info(f"Adventure ch{chapter_num}: Grade {req.grade} | {req.subject} > {req.topic}")
        chapter = complete_json(
            "fast",
            "adventure",
            system,
            messages,
        )
        return chapter
    except Exception as e:
        logger.error(f"Adventure failed: {type(e).__name__}: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)


@app.post("/api/adventure/stream")
async def adventure_chapter_stream(req: AdventureRequest):
    """Stream adventure narrative tokens, then emit structured chapter metadata."""
    if req.grade not in CBSE_SYLLABUS:
        return JSONResponse({"error": "Invalid grade"}, status_code=400)

    difficulty = normalize_difficulty(req.difficulty)
    cp = _load_child_profile(req.learner_id)
    interest_block = _learner_prompt_blocks(req.learner_id, req.genre)
    narrative_system = build_adventure_narrative_prompt(
        req.grade, req.language, req.genre, req.novel_name or "", difficulty,
        child_profile=cp, interest_block=interest_block,
    )
    messages = _build_adventure_messages(req)
    chapter_num = len([m for m in messages if m["role"] == "assistant"]) + 1
    ncert_line = ncert_story_hint(req.grade, req.subject, req.topic)

    async def event_generator():
        narrative = ""
        try:
            logger.info(
                f"Adventure stream ch{chapter_num}: "
                f"Grade {req.grade} | {req.subject} > {req.topic}"
            )
            async for event_type, payload in stream_text(
                "story",
                narrative_system,
                messages,
                reasoning=False,
            ):
                if event_type == "token":
                    narrative += payload
                    yield f"event: token\ndata: {json.dumps({'delta': payload})}\n\n"
                elif event_type == "error":
                    yield f"event: error\ndata: {json.dumps({'error': payload})}\n\n"
                    return

            meta = complete_json(
                "fast",
                "adventure_meta",
                ADVENTURE_META_PROMPT,
                [{
                    "role": "user",
                    "content": (
                        f"Grade: {req.grade}\nSubject: {req.subject}\nTopic: {req.topic}\n"
                        f"Chapter number: {chapter_num}\n{ncert_line}\n\n"
                        f"Narrative:\n{narrative}"
                    ),
                }],
            )
            chapter = {**meta, "content": narrative}
            if req.learner_id and req.learner_id.strip():
                try:
                    obs_conn = _get_conn()
                    try:
                        source = "adventure_choice" if req.choice else "adventure"
                        observe_gameplay(
                            obs_conn, req.learner_id.strip(), source,
                            grade=req.grade, subject=req.subject, topic=req.topic,
                            correct=True if req.choice else None,
                            payload={"chapter": chapter_num, "choice": req.choice or ""},
                        )
                        obs_conn.commit()
                    finally:
                        obs_conn.close()
                except Exception as ae:
                    logger.warning(f"Assessment adventure stream: {ae}")
            yield f"event: chapter\ndata: {json.dumps(chapter)}\n\n"
            yield "event: done\ndata: {}\n\n"
        except Exception as e:
            logger.error(f"Adventure stream failed: {type(e).__name__}: {e}")
            yield f"event: error\ndata: {json.dumps({'error': f'{type(e).__name__}: {e}'})}\n\n"

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache, no-store", "X-Accel-Buffering": "no"},
    )


@app.post("/api/ask-doubt/stream")
async def ask_doubt_stream(req: DoubtRequest):
    """POST streaming endpoint — since it needs a JSON body (history), the frontend
    must consume this with fetch()+ReadableStream rather than EventSource (which only
    supports GET)."""
    lang = LANGUAGES.get(req.language, LANGUAGES["english"])
    system = _build_doubt_system(req, lang)
    messages = _build_doubt_messages(req)

    context_line = system.split("Student context: ", 1)[-1].split("\n", 1)[0]

    async def event_generator():
        try:
            logger.info(f"Doubt (stream): {context_line} | Q: {req.question[:80]}")
            async for event_type, payload in stream_text(
                "fast",
                system,
                messages,
                reasoning=False,
            ):
                if event_type == "thinking":
                    yield f"event: thinking\ndata: {json.dumps({'delta': payload})}\n\n"
                elif event_type == "token":
                    yield f"event: token\ndata: {json.dumps({'delta': payload})}\n\n"
                elif event_type == "completed":
                    yield "event: done\ndata: {}\n\n"
                elif event_type == "error":
                    yield f"event: error\ndata: {json.dumps({'error': payload})}\n\n"
        except Exception as e:
            logger.error(f"Doubt stream failed: {type(e).__name__}: {e}")
            yield f"event: error\ndata: {json.dumps({'error': f'{type(e).__name__}: {e}'})}\n\n"

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache, no-store", "X-Accel-Buffering": "no"},
    )


@app.post("/api/ask-doubt")
async def ask_doubt(req: DoubtRequest):
    lang = LANGUAGES.get(req.language, LANGUAGES["english"])
    system = _build_doubt_system(req, lang)
    messages = _build_doubt_messages(req)

    context_line = system.split("Student context: ", 1)[-1].split("\n", 1)[0]

    try:
        logger.info(f"Doubt: {context_line} | Q: {req.question[:80]}")
        answer = complete_text("fast", system, messages)
        if req.learner_id and req.learner_id.strip():
            _record_assessment(
                req.learner_id.strip(), "doubt",
                grade=req.grade or 0, subject=req.subject or "",
                topic=req.topic or "",
                correct=True,
                payload={"has_explanation": True, "question_len": len(req.question or "")},
            )
        return {"answer": answer}
    except Exception as e:
        logger.error(f"Doubt failed: {type(e).__name__}: {e}")
        return JSONResponse({"error": str(e)}, status_code=500)


@app.get("/api/image-search")
async def search_image(q: str):
    """Search Wikipedia for a relevant image thumbnail."""
    try:
        headers = {"User-Agent": "StorySchool/1.0 (educational-app; contact@storyschool.dev)"}
        async with httpx.AsyncClient(timeout=8.0, headers=headers) as http:
            resp = await http.get("https://en.wikipedia.org/w/api.php", params={
                "action": "query",
                "generator": "search",
                "gsrsearch": q,
                "gsrlimit": 5,
                "prop": "pageimages",
                "format": "json",
                "pithumbsize": 500,
            })
            data = resp.json()
            pages = data.get("query", {}).get("pages", {})
            for page in pages.values():
                thumb = page.get("thumbnail", {}).get("source")
                if thumb:
                    return {"url": thumb, "title": page.get("title", "")}
        return {"url": "", "title": ""}
    except Exception as e:
        logger.warning(f"Image search failed: {e}")
        return {"url": "", "title": ""}


if __name__ == "__main__":
    import uvicorn
    port = int(os.environ.get("PORT", "8000"))
    uvicorn.run(app, host="127.0.0.1", port=port)
