"""Mistake → Learning: diagnose errors, mini practice, then retry."""

from __future__ import annotations

import copy
import re
from typing import Any, Optional

from story_challenges import (
    check_challenge_answer,
    get_interaction,
    normalize_challenge,
    prepare_challenge_for_client,
)

MISTAKE_HEADLINES = [
    "Almost!",
    "Good try — not quite!",
    "You're thinking hard — let's adjust!",
    "Close! Mistakes help us learn.",
]


def _nums_in_text(text: str) -> list[float]:
    found = []
    for m in re.finditer(r"-?\d+(?:\.\d+)?", str(text or "")):
        try:
            found.append(float(m.group()))
        except ValueError:
            pass
    return found


def _user_display_answer(challenge: dict, user_answer: Any) -> str:
    interaction = get_interaction(challenge)
    if interaction == "mcq":
        try:
            idx = int(user_answer)
            opts = challenge.get("options") or []
            if 0 <= idx < len(opts):
                return str(opts[idx]).strip()
        except (TypeError, ValueError):
            pass
    if user_answer is None:
        return ""
    if isinstance(user_answer, dict):
        return str(user_answer)
    return str(user_answer).strip()


def _correct_display(challenge: dict) -> str:
    interaction = get_interaction(challenge)
    if interaction == "mcq":
        opts = challenge.get("options") or []
        idx = int(challenge.get("correct_index", -1))
        if 0 <= idx < len(opts):
            return str(opts[idx]).strip()
    return str(challenge.get("correct_answer") or "").strip()


def _diagnose_numeric(challenge: dict, user_answer: Any, correct: str) -> tuple[str, str]:
    """Return (diagnosis, remembrance)."""
    try:
        u = float(normalize_numeric(user_answer))
        c = float(normalize_numeric(correct))
    except (TypeError, ValueError):
        return (
            "Your answer doesn't match what the question is asking for.",
            "Re-read the question — are you finding groups, a total, or a part?",
        )

    q_nums = _nums_in_text(challenge.get("question", ""))
    remembrance = challenge.get("explanation", "") or "Check which operation the story is asking for."

    if abs(u - c) < 0.001:
        return ("You had the right idea — double-check your steps.", remembrance)

    if len(q_nums) >= 2:
        a, b = q_nums[0], q_nums[1]
        if abs(u - a * b) < 0.001:
            return (
                f"You got **{int(u) if u == int(u) else u}** because you multiplied "
                f"**{int(a) if a == int(a) else a} × {int(b) if b == int(b) else b}**. "
                f"But the story might need a different operation.",
                "Ask: am I combining groups, sharing equally, or finding a part of a whole?",
            )
        if abs(u - a + b) < 0.001:
            return (
                f"You added **{int(a) if a == int(a) else a} + {int(b) if b == int(b) else b}** "
                f"to get **{int(u) if u == int(u) else u}**. This question needs a different step.",
                "Addition joins amounts; multiplication makes equal groups.",
            )
        if abs(u - a - b) < 0.001:
            return (
                f"You subtracted and got **{int(u) if u == int(u) else u}**. "
                f"Check whether the story wants equal groups instead.",
                "Picture the groups in the story before you calculate.",
            )
        if b and abs(u - a / b) < 0.01:
            return (
                f"You divided **{int(a) if a == int(a) else a} ÷ {int(b) if b == int(b) else b}**. "
                f"That can be right for sharing — but re-read what the question asks.",
                remembrance,
            )

    if c and abs(u - c * 2) < 0.001:
        return (
            f"**{int(u) if u == int(u) else u}** is double the answer we need — "
            f"you may have counted twice.",
            "Count each group once, not twice.",
        )

    return (
        f"**{int(u) if u == int(u) else u}** isn't what we need here — "
        f"but your effort counts! Let's fix the method.",
        remembrance[:200] if remembrance else "Try the mini practice below.",
    )


def _diagnose_mcq(challenge: dict, user_answer: Any) -> tuple[str, str]:
    opts = challenge.get("options") or []
    correct_idx = int(challenge.get("correct_index", -1))
    try:
        uidx = int(user_answer)
    except (TypeError, ValueError):
        uidx = -1

    chosen = opts[uidx] if 0 <= uidx < len(opts) else "that option"
    correct = opts[correct_idx] if 0 <= correct_idx < len(opts) else ""
    remembrance = challenge.get("explanation", "") or "Think about what the story scene is really asking."

    chosen_nums = _nums_in_text(chosen)
    q_nums = _nums_in_text(challenge.get("question", ""))
    if len(q_nums) >= 2 and len(chosen_nums) == 1:
        a, b = q_nums[0], q_nums[1]
        if abs(chosen_nums[0] - a * b) < 0.001:
            return (
                f"You chose **{chosen}** because you multiplied "
                f"**{int(a) if a == int(a) else a} × {int(b) if b == int(b) else b}**. "
                f"But remember what the story is asking for.",
                remembrance,
            )

    wrong_opts = [o for i, o in enumerate(opts) if i != correct_idx and o]
    if chosen in wrong_opts and correct:
        return (
            f"You picked **{chosen}** — that's a common trap! "
            f"The story points toward **{correct}** instead.",
            remembrance,
        )

    return (
        f"**{chosen}** isn't the best fit. Re-read the clue in the story.",
        remembrance,
    )


def normalize_numeric(text: Any) -> str:
    from story_challenges import normalize_numeric_answer
    return normalize_numeric_answer(str(text or ""))


def visual_learning_tip(challenge: dict, user_answer: Any) -> str:
    """Suggest a drawing / concrete model."""
    q = (challenge.get("question") or "").lower()
    interaction = get_interaction(challenge)

    if any(w in q for w in ("group", "groups", "each", "per", "share", "equally")):
        nums = _nums_in_text(challenge.get("question", ""))
        if len(nums) >= 2:
            g, n = int(nums[0]), int(nums[1])
            if g > n:
                g, n = n, g
            return (
                f"Let's draw them: make **{n} circles** (groups) and put **{g} dots** in each. "
                f"Count all the dots — does that match your answer?"
            )
        return "Let's draw them: sketch equal groups and count dots in each group."

    if any(w in q for w in ("fraction", "half", "quarter", "third", "part")):
        return "Draw a bar or circle, split it into equal parts, and shade the fraction the story mentions."

    if interaction == "mcq":
        return "Cross out options that don't match the story. What's left?"

    if interaction == "ordering":
        return "Write each step on a sticky note and arrange them in time order."

    if interaction == "matching":
        return "Draw lines only when you're sure two items belong together — one match at a time."

    return "Sketch the scene from the story and label the numbers you see."


def analyze_mistake(challenge: dict, user_answer: Any) -> dict[str, Any]:
    """Build rich mistake feedback — never just 'Wrong'."""
    ch = normalize_challenge(challenge)
    interaction = get_interaction(ch)
    chosen = _user_display_answer(ch, user_answer)
    correct = _correct_display(ch)

    if interaction == "mcq":
        diagnosis, remembrance = _diagnose_mcq(ch, user_answer)
    elif interaction in ("numeric", "fill_blank"):
        diagnosis, remembrance = _diagnose_numeric(ch, user_answer, correct)
    else:
        diagnosis = (
            f"You answered **{chosen or '…'}** — not quite what we need here."
            if chosen
            else "Let's look at this together."
        )
        remembrance = ch.get("explanation", "") or "Use the story clues and try the mini practice."

    visual = visual_learning_tip(ch, user_answer)
    headline = MISTAKE_HEADLINES[hash(chosen) % len(MISTAKE_HEADLINES)]

    finn_message = (
        f"**{headline}** 🦊\n\n{diagnosis}\n\n"
        f"**Remember:** {remembrance}\n\n"
        f"**Let's visualize:** {visual}"
    )

    return {
        "headline": headline,
        "chosen_answer": chosen,
        "correct_answer": correct if interaction != "mcq" else None,
        "diagnosis": diagnosis,
        "remembrance": remembrance,
        "visual_tip": visual,
        "finn_message": finn_message,
        "next_step": "mini_practice",
    }


def _simpler_numeric_question(challenge: dict) -> tuple[str, str, list[str]]:
    """Return question, correct_answer, options for mini MCQ."""
    q = challenge.get("question", "")
    nums = _nums_in_text(q)
    explanation = challenge.get("explanation", "")

    if len(nums) >= 2:
        a, b = int(nums[0]), int(nums[1])
        if a > 20:
            a, b = min(a, 12), min(b, 5)
        # Mini: groups practice
        groups, each = (b, a) if a <= b else (a, b)
        if groups > 6:
            groups, each = 3, 4
        correct = str(groups * each)
        question = (
            f"Mini practice: There are **{groups} bags** with **{each} marbles** in each. "
            f"How many marbles in total?"
        )
        try:
            c = int(correct)
            wrong = [str(c + each), str(max(1, c - each)), str(groups + each)]
        except ValueError:
            wrong = ["6", "10", "14"]
        options = [correct] + wrong[:3]
        return question, correct, options

    correct = str(challenge.get("correct_answer") or "4")
    question = f"Mini practice: What is half of **8**?"
    options = ["4", "2", "6", "16"]
    return question, "4", options


def build_mini_practice(challenge: dict, scene_id: str) -> dict:
    """Server-side mini practice (full answers) + client payload."""
    ch = normalize_challenge(challenge)
    interaction = get_interaction(ch)
    mp_id = f"mp_{scene_id}"

    # Mini practice is always MCQ-style for a smooth retry loop (even for numeric originals).
    question, correct, options = _simpler_numeric_question(ch)
    seen = set()
    opts = []
    for o in options:
        if o not in seen:
            seen.add(o)
            opts.append(o)
    while len(opts) < 4:
        opts.append(str(len(opts) + 1))
    correct_idx = opts.index(correct) if correct in opts else 0
    full = {
        "mini_practice_id": mp_id,
        "scene_id": scene_id,
        "type": "mcq",
        "activity_type": "mcq",
        "category": ch.get("category", "mathematics"),
        "question": question,
        "hint": ch.get("hint", "") or "Multiply groups × items in each group.",
        "options": opts[:4],
        "correct_index": correct_idx,
        "correct_answer": correct,
        "explanation": (
            f"Great! **{correct}** is right. "
            + (ch.get("explanation", "")[:120] or "Now retry the story challenge!")
        ),
        "success_narrative": "Nice! You nailed the mini practice! 🦊",
        "failure_narrative": "Almost — count the groups again.",
    }

    client = prepare_challenge_for_client(full, f"{scene_id}_mini")
    client["mini_practice_id"] = mp_id
    client.pop("correct_index", None)
    client.pop("correct_answer", None)
    return {"full": full, "client": client}


def check_mini_practice(mini: dict, user_answer: Any) -> bool:
    return check_challenge_answer(mini, user_answer)


def mistake_recovery_default() -> dict:
    return {}


def get_recovery(progress: dict, scene_id: str) -> dict:
    rec = (progress.get("mistake_recovery") or {}).get(scene_id) or {}
    return {
        "attempts": rec.get("attempts", 0),
        "mini_practice_done": bool(rec.get("mini_practice_done")),
        "retry_unlocked": bool(rec.get("retry_unlocked")),
    }


def record_wrong_attempt(progress: dict, scene_id: str, mini_bundle: dict) -> dict:
    if "mistake_recovery" not in progress:
        progress["mistake_recovery"] = {}
    if "mini_practices" not in progress:
        progress["mini_practices"] = {}

    rec = progress["mistake_recovery"].get(scene_id) or {}
    rec["attempts"] = rec.get("attempts", 0) + 1
    rec["mini_practice_done"] = False
    rec["retry_unlocked"] = False
    progress["mistake_recovery"][scene_id] = rec
    progress["mini_practices"][scene_id] = mini_bundle["full"]
    return rec


def mark_mini_practice_done(progress: dict, scene_id: str) -> dict:
    if "mistake_recovery" not in progress:
        progress["mistake_recovery"] = {}
    rec = progress["mistake_recovery"].get(scene_id) or {}
    rec["mini_practice_done"] = True
    rec["retry_unlocked"] = True
    progress["mistake_recovery"][scene_id] = rec
    return rec


def load_mini_practice(progress: dict, scene_id: str) -> Optional[dict]:
    return (progress.get("mini_practices") or {}).get(scene_id)
