"""Multimodal learning — reading, listening, visual, speaking, and writing modes."""

from __future__ import annotations

import copy
import re
from typing import Any, Optional

MODALITIES: dict[str, dict[str, Any]] = {
    "reading": {
        "name": "Reading",
        "emoji": "📖",
        "features": {
            "text": "Story and lesson text tuned to reading level",
            "highlighting": "Tap or drag to highlight important lines",
            "reading_level": "Beginner → fluent (in Child Profile)",
            "vocabulary_popups": "Tap marked words for kid-friendly definitions",
        },
    },
    "listening": {
        "name": "Listening",
        "emoji": "🎧",
        "features": {
            "narration": "Listen to stories and Story World dialogue",
            "character_voices": "Different voice pitch per character",
            "adjustable_speed": "Slow down or speed up read-aloud",
            "audio_comprehension": "Quick reflection after listening",
        },
    },
    "visual": {
        "name": "Visual",
        "emoji": "🎨",
        "features": {
            "illustrations": "Topic images woven into stories",
            "diagrams": "ASCII and diagram blocks for concepts",
            "animations": "Gentle motion on key story moments",
            "interactive_maps": "Tap hotspots in Story World scenes",
        },
    },
    "speaking": {
        "name": "Speaking",
        "emoji": "🎤",
        "features": {
            "read_aloud": "Practice reading a paragraph aloud",
            "pronunciation": "Say vocabulary words — we listen along",
            "answer_verbally": "Answer open questions with your voice",
            "storytelling": "Tell what happens next in your own words",
        },
    },
    "writing": {
        "name": "Writing",
        "emoji": "✍️",
        "features": {
            "short_answers": "Brief written responses",
            "creative_writing": "Imagine a new scene or ending",
            "complete_the_story": "Continue where the story paused",
            "write_dialogue": "Write lines for a character",
            "explain_reasoning": "Explain why you chose an answer",
        },
    },
}

VOCAB_PATTERN = re.compile(r"\{\{VOCAB:\s*([^|]+?)\s*\|\s*([^}]+?)\}\}", re.IGNORECASE)
DIAGRAM_PATTERN = re.compile(r"\{\{DIAGRAM:\s*(.+?)\}\}", re.IGNORECASE | re.DOTALL)
ANIMATE_PATTERN = re.compile(r"\{\{ANIMATE:\s*(.+?)\}\}", re.IGNORECASE)

WRITING_PROMPTS: list[dict[str, str]] = [
    {
        "id": "complete_story",
        "modality": "writing",
        "emoji": "📜",
        "title": "Complete the story",
        "instruction": "Write 3–5 sentences continuing the story. Use what you learned about the topic!",
    },
    {
        "id": "write_dialogue",
        "modality": "writing",
        "emoji": "💬",
        "title": "Write dialogue",
        "instruction": "Write a short conversation (4–6 lines) between two characters explaining the topic.",
    },
    {
        "id": "creative_scene",
        "modality": "writing",
        "emoji": "✨",
        "title": "Creative writing",
        "instruction": "Invent a new scene that teaches the same idea in a different setting.",
    },
    {
        "id": "explain_reasoning",
        "modality": "writing",
        "emoji": "🧠",
        "title": "Explain your reasoning",
        "instruction": "Explain WHY your answer makes sense — use at least two reasons or examples.",
    },
    {
        "id": "short_answer",
        "modality": "writing",
        "emoji": "📝",
        "title": "Short answer",
        "instruction": "Answer in 1–3 sentences: What is the most important thing you learned?",
    },
]

SPEAKING_PROMPTS: list[dict[str, str]] = [
    {
        "id": "read_aloud",
        "modality": "speaking",
        "emoji": "🔊",
        "title": "Read aloud",
        "instruction": "Read the highlighted paragraph out loud clearly.",
    },
    {
        "id": "pronunciation",
        "modality": "speaking",
        "emoji": "🗣️",
        "title": "Pronunciation practice",
        "instruction": "Say each vocabulary word, then use it in your own sentence.",
    },
    {
        "id": "tell_next",
        "modality": "speaking",
        "emoji": "🎭",
        "title": "Storytelling",
        "instruction": "Tell what happens next in the story using your own words.",
    },
    {
        "id": "verbal_answer",
        "modality": "speaking",
        "emoji": "🎤",
        "title": "Answer verbally",
        "instruction": "Answer the question out loud as if teaching a friend.",
    },
]

COMPREHENSION_REFLECTIONS = [
    "What was the main idea you heard?",
    "Name one new word or fact from the story.",
    "How would you explain this to a friend in one sentence?",
]


def default_multimodal_preferences() -> dict:
    return {
        "reading": {
            "enabled": True,
            "highlighting": True,
            "vocabulary_popups": True,
        },
        "listening": {
            "enabled": True,
            "narration": True,
            "character_voices": True,
            "speed": 1.0,
            "comprehension_checks": True,
        },
        "visual": {
            "enabled": True,
            "illustrations": True,
            "diagrams": True,
            "animations": True,
            "interactive_maps": True,
        },
        "speaking": {
            "enabled": True,
            "read_aloud": True,
            "pronunciation": True,
            "verbal_answers": True,
            "storytelling": True,
        },
        "writing": {
            "enabled": True,
            "short_answers": True,
            "creative_writing": True,
            "complete_story": True,
            "dialogue": True,
            "explain_reasoning": True,
        },
    }


def normalize_multimodal_preferences(data: Optional[dict]) -> dict:
    base = default_multimodal_preferences()
    if not data:
        return base
    for mode, defaults in base.items():
        incoming = data.get(mode) or {}
        if not isinstance(incoming, dict):
            continue
        merged = {**defaults, **incoming}
        if mode == "listening":
            try:
                merged["speed"] = max(0.6, min(1.6, float(merged.get("speed", 1.0))))
            except (TypeError, ValueError):
                merged["speed"] = 1.0
        for key, val in merged.items():
            if key == "speed":
                continue
            if isinstance(val, bool):
                merged[key] = val
            elif key.endswith("enabled") or key in defaults:
                merged[key] = bool(val)
        base[mode] = merged
    return base


def multimodal_catalog() -> dict:
    return {
        "modalities": [
            {"id": k, **{kk: vv for kk, vv in v.items() if kk != "features"}, "features": v["features"]}
            for k, v in MODALITIES.items()
        ],
        "writing_prompts": WRITING_PROMPTS,
        "speaking_prompts": SPEAKING_PROMPTS,
        "comprehension_reflections": COMPREHENSION_REFLECTIONS,
        "markers": {
            "vocabulary": "{{VOCAB: word|definition}}",
            "diagram": "{{DIAGRAM: description or mermaid}}",
            "illustration": "{{IMAGE: search query}}",
            "animation": "{{ANIMATE: short label}}",
        },
    }


def multimodal_prompt_block(prefs: Optional[dict] = None) -> str:
    p = normalize_multimodal_preferences(prefs)
    lines = [
        "\nMULTIMODAL LEARNING — weave these into the content:",
    ]
    if p["reading"]["vocabulary_popups"]:
        lines.append(
            "- Mark 3–5 key topic words with EXACT format: {{VOCAB: word|kid-friendly definition}}"
        )
    if p["visual"]["diagrams"]:
        lines.append(
            "- Add 1–2 visual diagrams using {{DIAGRAM: ...}} — ASCII art in a code block "
            "or a one-line mermaid mindmap/graph when it helps."
        )
    if p["visual"]["illustrations"]:
        lines.append("- Keep using {{IMAGE: descriptive search query}} for illustrations (3–4 per story).")
    if p["visual"]["animations"]:
        lines.append(
            "- Optionally mark 1–2 exciting story beats with {{ANIMATE: short label}} "
            "(e.g. {{ANIMATE: water flows to the village}})."
        )
    if p["writing"]["enabled"]:
        lines.append(
            "- Leave a natural pause where the learner could continue writing or tell the next scene."
        )
    return "\n".join(lines)


def extract_vocabulary(text: str) -> list[dict[str, str]]:
    found = []
    seen = set()
    for match in VOCAB_PATTERN.finditer(text or ""):
        word = match.group(1).strip()
        definition = match.group(2).strip()
        key = word.lower()
        if key and key not in seen:
            seen.add(key)
            found.append({"word": word, "definition": definition})
    return found[:12]


def strip_multimodal_markers(text: str) -> str:
    out = text or ""
    out = VOCAB_PATTERN.sub(r"\1", out)
    out = DIAGRAM_PATTERN.sub("", out)
    out = ANIMATE_PATTERN.sub(r"\1", out)
    return out


def character_voice_settings(character_id: str, mood: str = "neutral") -> dict[str, float]:
    """Pitch/rate hints for Web Speech API — narrative allies, not stereotypes."""
    base_rate = 1.0
    base_pitch = 1.0
    cid = (character_id or "narrator").lower()
    if cid == "narrator":
        return {"rate": base_rate * 0.95, "pitch": 1.0}
    mood_pitch = {
        "happy": 1.15, "excited": 1.2, "curious": 1.08,
        "worried": 0.92, "surprised": 1.12, "neutral": 1.0,
    }
    pitch = mood_pitch.get(mood, 1.0)
    if "owl" in cid or "wise" in cid:
        pitch *= 0.9
        base_rate *= 0.92
    elif "fox" in cid or "finn" in cid:
        pitch *= 1.05
    elif "lion" in cid or "brave" in cid:
        pitch *= 0.88
        base_rate *= 0.95
    return {"rate": round(base_rate, 2), "pitch": round(pitch, 2)}


def build_writing_feedback(
    prompt_id: str,
    text: str,
    *,
    child_name: str = "",
    topic: str = "",
) -> dict:
    """Lightweight encouragement — full AI feedback optional via tutor API."""
    cleaned = (text or "").strip()
    name = child_name.strip() or "friend"
    word_count = len(cleaned.split())
    prompt = next((p for p in WRITING_PROMPTS if p["id"] == prompt_id), None)
    title = prompt["title"] if prompt else "Writing"

    if not cleaned:
        return {
            "ok": False,
            "message": f"Try jotting a few ideas, {name} — even one sentence is a great start! ✍️",
            "word_count": 0,
        }

    if word_count < 8:
        msg = (
            f"Nice start, {name}! 🦊 Add one more detail about "
            f"{topic or 'the topic'} — what happened or why it matters?"
        )
    elif word_count < 25:
        msg = (
            f"Good thinking, {name}! Your {title.lower()} shows you understood "
            f"something about {topic or 'the lesson'}. Want to add an example?"
        )
    else:
        msg = (
            f"Wonderful writing, {name}! 🌟 You explained "
            f"{topic or 'the idea'} in your own words — that is real learning."
        )

    return {
        "ok": True,
        "message": msg,
        "word_count": word_count,
        "prompt_id": prompt_id,
    }


def comprehension_reflection() -> str:
    import random
    return random.choice(COMPREHENSION_REFLECTIONS)
