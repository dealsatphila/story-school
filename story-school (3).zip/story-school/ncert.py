"""NCERT textbook chapter lookup — maps StorySchool topics to official NCERT PDFs."""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional

# Official NCERT PDF pattern: https://ncert.nic.in/textbook/pdf/{code}{chapter:02d}.pdf
NCERT_PDF_BASE = "https://ncert.nic.in/textbook/pdf"
NCERT_READER_BASE = "https://ncert.nic.in/textbook.php"


@dataclass(frozen=True)
class NcertChapter:
    num: int
    title: str
    keywords: tuple[str, ...] = ()


@dataclass(frozen=True)
class NcertBook:
    code: str
    title: str
    chapters: tuple[NcertChapter, ...]


# StorySchool subject name -> NCERT book registry key per grade
SUBJECT_BOOK_KEY: dict[tuple[int, str], str] = {
    (5, "Mathematics"): "g5_math",
    (5, "Science"): "g5_evs",
    (6, "Mathematics"): "g6_math",
    (6, "Science"): "g6_science",
    (7, "Mathematics"): "g7_math",
    (7, "Science"): "g7_science",
    (8, "Mathematics"): "g8_math",
    (8, "Science"): "g8_science",
    (9, "Mathematics"): "g9_math",
    (9, "Science"): "g9_science",
    (10, "Mathematics"): "g10_math",
    (10, "Science"): "g10_science",
    (5, "Social Science"): "g5_sst",
    (6, "Social Science"): "g6_sst",
    (7, "Social Science"): "g7_sst",
    (8, "Social Science"): "g8_sst",
    (9, "Social Science"): "g9_sst",
    (10, "Social Science"): "g10_sst",
    (5, "English"): "g5_english",
    (6, "English"): "g6_english",
    (7, "English"): "g7_english",
    (8, "English"): "g8_english",
    (9, "English"): "g9_english",
    (10, "English"): "g10_english",
}

NCERT_BOOKS: dict[str, NcertBook] = {
    # Grade 5 — Maths Mela (2025)
    "g5_math": NcertBook("eemm1", "Maths Mela", (
        NcertChapter(1, "We the Travellers—I", ("travellers", "numbers", "large")),
        NcertChapter(2, "Fractions", ("fraction",)),
        NcertChapter(3, "Angles as Turns", ("angle", "turn")),
        NcertChapter(4, "We the Travellers—II", ("travellers",)),
        NcertChapter(5, "Far and Near", ("distance", "measurement", "length")),
        NcertChapter(6, "The Dairy Farm", ("farm", "multiplication", "division")),
        NcertChapter(7, "Shapes and Patterns", ("shape", "pattern", "geometry")),
        NcertChapter(8, "Weight and Capacity", ("weight", "capacity", "measurement")),
        NcertChapter(9, "Coconut Farm", ("farm", "area")),
        NcertChapter(10, "Symmetrical Designs", ("symmetry",)),
        NcertChapter(11, "Grandmother's Quilt", ("quilt", "fraction")),
        NcertChapter(12, "Racing Seconds", ("time", "second")),
        NcertChapter(13, "Animal Jumps", ("jump", "measurement")),
        NcertChapter(14, "Maps and Locations", ("map", "location")),
        NcertChapter(15, "Data Through Pictures", ("data", "graph", "pictograph", "bar")),
    )),
    # Grade 5 EVS — Looking Around (legacy alignment for science-style topics)
    "g5_evs": NcertBook("fees1", "Looking Around", (
        NcertChapter(1, "Super Senses", ("sense", "animal")),
        NcertChapter(2, "A Snake Charmer's Story", ("snake",)),
        NcertChapter(3, "From Tasting to Digesting", ("food", "digest", "nutrient")),
        NcertChapter(4, "Mangoes Round the Year", ("food", "preserve")),
        NcertChapter(5, "Seeds and Seeds", ("seed", "germination", "plant")),
        NcertChapter(6, "Every Drop Counts", ("water", "conservation")),
        NcertChapter(7, "Experiments with Water", ("water", "soluble", "matter")),
        NcertChapter(8, "A Treat for Mosquitoes", ("health",)),
        NcertChapter(9, "Up You Go!", ("mountain",)),
        NcertChapter(10, "Walls Tell Stories", ("history", "fort")),
        NcertChapter(11, "Sunita in Space", ("space", "earth")),
        NcertChapter(12, "What if it Finishes...?", ("resource", "fuel", "energy")),
        NcertChapter(13, "A Shelter so High!", ("shelter", "habitat")),
        NcertChapter(14, "When the Earth Shook!", ("earthquake",)),
        NcertChapter(15, "Blow Hot, Blow Cold", ("weather", "air")),
        NcertChapter(16, "Who will do this Work?", ("work", "force")),
        NcertChapter(17, "Across the Wall", ("gender", "rights")),
        NcertChapter(18, "No Place for Us?", ("migration",)),
        NcertChapter(19, "A Seed tells a Farmer's Story", ("seed", "agriculture")),
        NcertChapter(20, "Whose Forests?", ("forest", "environment")),
        NcertChapter(21, "Like Father, Like Daughter", ("inheritance",)),
        NcertChapter(22, "On the Move Again", ("migration", "livelihood")),
    )),
    # Grade 6 — Ganita Prakash
    "g6_math": NcertBook("fegp1", "Ganita Prakash", (
        NcertChapter(1, "Patterns in Mathematics", ("pattern",)),
        NcertChapter(2, "Lines and Angles", ("line", "angle", "geometry")),
        NcertChapter(3, "Number Play", ("number", "divisibility")),
        NcertChapter(4, "Data Handling and Presentation", ("data", "mean", "median", "mode", "graph")),
        NcertChapter(5, "Prime Time", ("prime", "factor", "multiple", "hcf", "lcm")),
        NcertChapter(6, "Perimeter and Area", ("perimeter", "area", "mensuration")),
        NcertChapter(7, "Fractions", ("fraction",)),
        NcertChapter(8, "Playing with Constructions", ("construction", "geometry")),
        NcertChapter(9, "Symmetry", ("symmetry",)),
        NcertChapter(10, "The Other Side of Zero", ("integer", "negative", "number")),
    )),
    # Grade 6 — Curiosity (Science)
    "g6_science": NcertBook("fecu1", "Curiosity", (
        NcertChapter(1, "The Wonderful World of Science", ("science",)),
        NcertChapter(2, "Diversity in the Living World", ("living", "organism", "habitat", "adaptation")),
        NcertChapter(3, "Mindful Eating: A Path to a Healthy Body", ("food", "nutrient", "body")),
        NcertChapter(4, "Exploring Magnets", ("magnet",)),
        NcertChapter(5, "Measurement of Length and Motion", ("motion", "measurement", "distance")),
        NcertChapter(6, "Materials Around Us", ("material", "sorting", "group")),
        NcertChapter(7, "Temperature and its Measurement", ("temperature", "heat")),
        NcertChapter(8, "A Journey through States of Water", ("water", "state", "matter", "cycle")),
        NcertChapter(9, "Methods of Separation in Everyday Life", ("separation", "substance")),
        NcertChapter(10, "Living Creatures: Exploring their Characteristics", ("living", "movement", "body")),
        NcertChapter(11, "Nature's Treasures", ("resource", "environment", "garbage", "waste")),
        NcertChapter(12, "Beyond Earth", ("earth", "space", "light", "shadow")),
    )),
    # Grade 7 — Ganita (standard middle-school math topics)
    "g7_math": NcertBook("gemh1", "Ganit", (
        NcertChapter(1, "Integers", ("integer", "negative")),
        NcertChapter(2, "Fractions and Decimals", ("fraction", "decimal")),
        NcertChapter(3, "Data Handling", ("data", "mean", "median", "mode", "bar")),
        NcertChapter(4, "Simple Equations", ("equation", "algebra", "variable")),
        NcertChapter(5, "Lines and Angles", ("line", "angle", "parallel", "transversal")),
        NcertChapter(6, "The Triangle and Its Properties", ("triangle",)),
        NcertChapter(7, "Comparing Quantities", ("ratio", "proportion", "percentage", "percent")),
        NcertChapter(8, "Rational Numbers", ("rational", "number")),
        NcertChapter(9, "Perimeter and Area", ("perimeter", "area", "circle")),
        NcertChapter(10, "Algebraic Expressions", ("algebra", "expression")),
        NcertChapter(11, "Exponents and Powers", ("exponent", "power")),
        NcertChapter(12, "Symmetry", ("symmetry", "solid", "shape")),
        NcertChapter(13, "Visualising Solid Shapes", ("solid", "shape", "3d")),
    )),
    "g7_science": NcertBook("gecu1", "Science", (
        NcertChapter(1, "Nutrition in Plants", ("photosynthesis", "nutrition", "plant")),
        NcertChapter(2, "Nutrition in Animals", ("nutrition", "animal", "digestion")),
        NcertChapter(3, "Fibre to Fabric", ("fibre", "fabric", "wool", "silk")),
        NcertChapter(4, "Heat", ("heat", "temperature", "conduction")),
        NcertChapter(5, "Acids, Bases and Salts", ("acid", "base", "salt")),
        NcertChapter(6, "Physical and Chemical Changes", ("physical", "chemical", "change")),
        NcertChapter(7, "Weather, Climate and Adaptations", ("weather", "climate", "adaptation")),
        NcertChapter(8, "Winds, Storms and Cyclones", ("wind", "storm", "cyclone")),
        NcertChapter(9, "Soil", ("soil",)),
        NcertChapter(10, "Respiration in Organisms", ("respiration",)),
        NcertChapter(11, "Transportation in Animals and Plants", ("transportation", "circulation")),
        NcertChapter(12, "Reproduction in Plants", ("reproduction", "plant")),
        NcertChapter(13, "Motion and Time", ("motion", "time", "speed")),
        NcertChapter(14, "Electric Current and its Effects", ("electric", "current", "circuit")),
        NcertChapter(15, "Light", ("light", "reflection", "lens")),
        NcertChapter(16, "Water: A Precious Resource", ("water", "resource")),
        NcertChapter(17, "Forests: Our Lifeline", ("forest",)),
        NcertChapter(18, "Wastewater Story", ("waste", "water")),
    )),
    # Grade 8
    "g8_math": NcertBook("gemh1", "Ganit", (
        NcertChapter(1, "Rational Numbers", ("rational",)),
        NcertChapter(2, "Linear Equations in One Variable", ("linear", "equation")),
        NcertChapter(3, "Understanding Quadrilaterals", ("quadrilateral", "polygon")),
        NcertChapter(4, "Data Handling", ("data", "probability")),
        NcertChapter(5, "Squares and Square Roots", ("square", "root")),
        NcertChapter(6, "Cubes and Cube Roots", ("cube", "root")),
        NcertChapter(7, "Comparing Quantities", ("percentage", "interest", "ratio")),
        NcertChapter(8, "Algebraic Expressions and Identities", ("algebra", "identity")),
        NcertChapter(9, "Mensuration", ("mensuration", "volume", "surface")),
        NcertChapter(10, "Exponents and Powers", ("exponent",)),
        NcertChapter(11, "Direct and Inverse Proportions", ("proportion",)),
        NcertChapter(12, "Factorisation", ("factor",)),
        NcertChapter(13, "Introduction to Graphs", ("graph",)),
    )),
    "g8_science": NcertBook("gecu2", "Science", (
        NcertChapter(1, "Crop Production and Management", ("crop", "agriculture")),
        NcertChapter(2, "Microorganisms: Friend and Foe", ("microorganism",)),
        NcertChapter(3, "Synthetic Fibres and Plastics", ("fibre", "plastic", "synthetic")),
        NcertChapter(4, "Materials: Metals and Non-Metals", ("metal", "material")),
        NcertChapter(5, "Coal and Petroleum", ("coal", "petroleum", "fuel")),
        NcertChapter(6, "Combustion and Flame", ("combustion", "flame")),
        NcertChapter(7, "Conservation of Plants and Animals", ("conservation", "biodiversity")),
        NcertChapter(8, "Cell — Structure and Functions", ("cell",)),
        NcertChapter(9, "Reproduction in Animals", ("reproduction", "animal")),
        NcertChapter(10, "Reaching the Age of Adolescence", ("adolescence",)),
        NcertChapter(11, "Force and Pressure", ("force", "pressure")),
        NcertChapter(12, "Friction", ("friction",)),
        NcertChapter(13, "Sound", ("sound",)),
        NcertChapter(14, "Chemical Effects of Electric Current", ("chemical", "electric")),
        NcertChapter(15, "Some Natural Phenomena", ("lightning", "earthquake")),
        NcertChapter(16, "Light", ("light",)),
        NcertChapter(17, "Stars and the Solar System", ("star", "solar", "planet")),
        NcertChapter(18, "Pollution of Air and Water", ("pollution", "air", "water")),
    )),
    # Grade 9 — use standard NCERT codes (jemh1 / jesc1 style)
    "g9_math": NcertBook("iemh1", "Mathematics", (
        NcertChapter(1, "Number Systems", ("number", "real", "rational")),
        NcertChapter(2, "Polynomials", ("polynomial", "algebra")),
        NcertChapter(3, "Coordinate Geometry", ("coordinate", "geometry")),
        NcertChapter(4, "Linear Equations in Two Variables", ("linear", "equation")),
        NcertChapter(5, "Introduction to Euclid's Geometry", ("euclid", "geometry")),
        NcertChapter(6, "Lines and Angles", ("line", "angle")),
        NcertChapter(7, "Triangles", ("triangle", "congruence")),
        NcertChapter(8, "Quadrilaterals", ("quadrilateral",)),
        NcertChapter(9, "Circles", ("circle",)),
        NcertChapter(10, "Heron's Formula", ("heron", "area")),
        NcertChapter(11, "Surface Areas and Volumes", ("surface", "volume")),
        NcertChapter(12, "Statistics", ("statistics", "mean", "median")),
        NcertChapter(13, "Probability", ("probability",)),
    )),
    "g9_science": NcertBook("iesc1", "Science", (
        NcertChapter(1, "Matter in Our Surroundings", ("matter", "state")),
        NcertChapter(2, "Is Matter Around Us Pure", ("mixture", "solution")),
        NcertChapter(3, "Atoms and Molecules", ("atom", "molecule")),
        NcertChapter(4, "Structure of the Atom", ("atom", "structure")),
        NcertChapter(5, "The Fundamental Unit of Life", ("cell",)),
        NcertChapter(6, "Tissues", ("tissue",)),
        NcertChapter(7, "Motion", ("motion", "velocity", "acceleration")),
        NcertChapter(8, "Force and Laws of Motion", ("force", "newton")),
        NcertChapter(9, "Gravitation", ("gravity", "gravitation")),
        NcertChapter(10, "Work and Energy", ("work", "energy")),
        NcertChapter(11, "Sound", ("sound",)),
        NcertChapter(12, "Improvement in Food Resources", ("food", "resource")),
    )),
    "g10_math": NcertBook("jemh1", "Mathematics", (
        NcertChapter(1, "Real Numbers", ("real", "number")),
        NcertChapter(2, "Polynomials", ("polynomial",)),
        NcertChapter(3, "Pair of Linear Equations in Two Variables", ("linear", "equation")),
        NcertChapter(4, "Quadratic Equations", ("quadratic",)),
        NcertChapter(5, "Arithmetic Progressions", ("arithmetic", "progression")),
        NcertChapter(6, "Triangles", ("triangle", "similarity")),
        NcertChapter(7, "Coordinate Geometry", ("coordinate",)),
        NcertChapter(8, "Introduction to Trigonometry", ("trigonometry",)),
        NcertChapter(9, "Some Applications of Trigonometry", ("trigonometry", "height")),
        NcertChapter(10, "Circles", ("circle", "tangent")),
        NcertChapter(11, "Areas Related to Circles", ("area", "circle")),
        NcertChapter(12, "Surface Areas and Volumes", ("surface", "volume")),
        NcertChapter(13, "Statistics", ("statistics",)),
        NcertChapter(14, "Probability", ("probability",)),
    )),
    "g10_science": NcertBook("jesc1", "Science", (
        NcertChapter(1, "Chemical Reactions and Equations", ("chemical", "reaction")),
        NcertChapter(2, "Acids, Bases and Salts", ("acid", "base")),
        NcertChapter(3, "Metals and Non-metals", ("metal",)),
        NcertChapter(4, "Carbon and its Compounds", ("carbon", "compound")),
        NcertChapter(5, "Life Processes", ("life", "process", "nutrition")),
        NcertChapter(6, "Control and Coordination", ("control", "coordination", "nervous")),
        NcertChapter(7, "How do Organisms Reproduce?", ("reproduction",)),
        NcertChapter(8, "Heredity", ("heredity", "genetics")),
        NcertChapter(9, "Light — Reflection and Refraction", ("light", "reflection", "refraction")),
        NcertChapter(10, "The Human Eye and the Colourful World", ("eye", "light")),
        NcertChapter(11, "Electricity", ("electricity", "current")),
        NcertChapter(12, "Magnetic Effects of Electric Current", ("magnetic", "electric")),
        NcertChapter(13, "Our Environment", ("environment", "ecosystem")),
        NcertChapter(14, "Sources of Energy", ("energy", "source")),
    )),
    # SST / English — book index only (chapter-level sync varies by reader edition)
    "g6_sst": NcertBook("fees1", "Social and Political Life", (
        NcertChapter(1, "Understanding Diversity", ("diversity",)),
        NcertChapter(2, "Diversity and Discrimination", ("discrimination", "rights")),
        NcertChapter(3, "What is Government?", ("government", "democracy")),
        NcertChapter(4, "Key Elements of a Democratic Government", ("democracy", "panchayat")),
        NcertChapter(5, "Panchayati Raj", ("panchayat",)),
        NcertChapter(6, "Rural Administration", ("rural", "livelihood")),
        NcertChapter(7, "Urban Administration", ("urban", "livelihood")),
        NcertChapter(8, "Rural Livelihoods", ("rural",)),
        NcertChapter(9, "Urban Livelihoods", ("urban",)),
    )),
}

# Alias lower grades SST to closest available book keys
for g in (5, 7, 8, 9, 10):
    SUBJECT_BOOK_KEY.setdefault((g, "Social Science"), "g6_sst")
for g in range(5, 11):
    SUBJECT_BOOK_KEY.setdefault((g, "English"), f"g{g}_english")

# English books — index pages only (literature readers vary)
for g in range(5, 11):
    NCERT_BOOKS[f"g{g}_english"] = NcertBook(
        f"fehb{max(1, g - 4)}", f"Honeycomb / English Reader (Grade {g})", ()
    )


def _tokenize(text: str) -> set[str]:
    text = text.lower().replace("—", " ").replace("-", " ")
    text = re.sub(r"[^\w\s]", " ", text)
    tokens = {t for t in text.split() if len(t) > 2}
    extras: set[str] = set()
    for t in tokens:
        if t.endswith("s") and len(t) > 3:
            extras.add(t[:-1])
        if t.endswith("ies") and len(t) > 4:
            extras.add(t[:-3] + "y")
    return tokens | extras


def _score_topic_chapter(topic: str, chapter: NcertChapter) -> float:
    norm_topic = topic.lower().strip()
    norm_title = chapter.title.lower().strip()
    if norm_topic == norm_title or norm_topic in norm_title or norm_title in norm_topic:
        return 100.0

    topic_tokens = _tokenize(topic)
    if not topic_tokens:
        return 0.0
    title_tokens = _tokenize(chapter.title)
    keyword_tokens = set()
    for kw in chapter.keywords:
        keyword_tokens.update(_tokenize(kw))
    overlap_title = len(topic_tokens & title_tokens)
    overlap_kw = len(topic_tokens & keyword_tokens)
    # Weight keyword hits higher
    return overlap_title * 2.0 + overlap_kw * 3.0 + (0.5 if overlap_title else 0)


def chapter_pdf_url(book_code: str, chapter_num: int) -> str:
    return f"{NCERT_PDF_BASE}/{book_code}{chapter_num:02d}.pdf"


def book_index_url(book_code: str) -> str:
    return f"{NCERT_READER_BASE}?{book_code}=0-0"


def lookup_ncert_chapter(grade: int, subject: str, topic: str) -> Optional[dict]:
    """Return best-matching NCERT chapter for a StorySchool topic, or None."""
    book_key = SUBJECT_BOOK_KEY.get((grade, subject))
    if not book_key:
        return None
    book = NCERT_BOOKS.get(book_key)
    if not book:
        return None

    if not book.chapters:
        return {
            "book_title": book.title,
            "book_code": book.code,
            "chapter_num": None,
            "chapter_title": None,
            "pdf_url": None,
            "reader_url": book_index_url(book.code),
            "match_score": 0,
            "note": "Open the NCERT reader to find your chapter.",
        }

    best: Optional[NcertChapter] = None
    best_score = 0.0
    for ch in book.chapters:
        score = _score_topic_chapter(topic, ch)
        if score > best_score:
            best_score = score
            best = ch

    if not best or best_score < 3.0:
        return {
            "book_title": book.title,
            "book_code": book.code,
            "chapter_num": None,
            "chapter_title": None,
            "pdf_url": None,
            "reader_url": book_index_url(book.code),
            "match_score": best_score,
            "note": "No close chapter match — browse the full textbook.",
        }

    return {
        "book_title": book.title,
        "book_code": book.code,
        "chapter_num": best.num,
        "chapter_title": best.title,
        "pdf_url": chapter_pdf_url(book.code, best.num),
        "reader_url": book_index_url(book.code),
        "match_score": best_score,
        "note": None,
    }


def ncert_story_hint(grade: int, subject: str, topic: str) -> str:
    """Optional prompt line aligning stories with the matched NCERT chapter."""
    info = lookup_ncert_chapter(grade, subject, topic)
    if not info:
        return ""
    if info.get("chapter_num") and info.get("chapter_title"):
        return (
            f"NCERT textbook: {info['book_title']}, "
            f"Chapter {info['chapter_num']}: {info['chapter_title']}. "
            "Align vocabulary and examples with this official CBSE chapter.\n"
        )
    if info.get("book_title"):
        return (
            f"NCERT textbook: {info['book_title']}. "
            "Keep explanations aligned with official CBSE/NCERT curriculum.\n"
        )
    return ""


def ncert_grounding_context(grade: int, subject: str, topic: str) -> str:
    """NCERT-aligned context for doubt answers (lightweight RAG without PDF upload)."""
    info = lookup_ncert_chapter(grade, subject, topic)
    if not info:
        return ""
    lines = [f"Official NCERT textbook: {info['book_title']}"]
    if info.get("chapter_num") and info.get("chapter_title"):
        lines.append(f"Chapter {info['chapter_num']}: {info['chapter_title']}")
    if info.get("pdf_url"):
        lines.append(f"NCERT PDF: {info['pdf_url']}")
    lines.append(
        "Ground explanations in CBSE/NCERT curriculum for this grade. "
        "Use standard textbook terminology; do not contradict core definitions."
    )
    return "\n".join(lines)
