"""OpenAI provider — structured JSON, text, and streaming via the Responses API.

Kept in its own module so the OpenAI SDK never shares a file with the Anthropic
SDK. The tier/model/provider selection lives in ai_config.py, which owns an
instance of this class.
"""

from __future__ import annotations

import json
import os
from typing import Any

from openai import AsyncOpenAI, OpenAI

REASONING_ENABLED = os.environ.get("OPENAI_REASONING", "").strip().lower() in (
    "1", "true", "yes",
)


def model_supports_reasoning_summary(model: str) -> bool:
    """Reasoning summaries only work on select OpenAI models."""
    if not REASONING_ENABLED:
        return False
    m = model.lower()
    return "gpt-5" in m or m.startswith("o1") or m.startswith("o3")


class OpenAIProvider:
    """Adapts the OpenAI Responses API to the provider interface."""

    name = "openai"
    label = "OpenAI"

    def __init__(self) -> None:
        self._client: OpenAI | None = None
        self._async_client: AsyncOpenAI | None = None

    @staticmethod
    def has_key() -> bool:
        return bool(os.environ.get("OPENAI_API_KEY"))

    def _sync(self) -> OpenAI:
        if self._client is None:
            key = os.environ.get("OPENAI_API_KEY")
            if not key:
                raise RuntimeError("OPENAI_API_KEY environment variable is required")
            self._client = OpenAI(api_key=key)
        return self._client

    def _async(self) -> AsyncOpenAI:
        if self._async_client is None:
            key = os.environ.get("OPENAI_API_KEY")
            if not key:
                raise RuntimeError("OPENAI_API_KEY environment variable is required")
            self._async_client = AsyncOpenAI(api_key=key)
        return self._async_client

    def complete_json(
        self,
        model: str,
        schema: dict[str, Any],
        schema_name: str,
        instructions: str,
        input_messages: list[dict[str, str]],
    ) -> Any:
        """Blocking structured JSON completion via the Responses API."""
        response = self._sync().responses.create(
            model=model,
            instructions=instructions,
            input=input_messages,
            text={
                "format": {
                    "type": "json_schema",
                    "name": schema_name,
                    "schema": schema,
                    "strict": True,
                }
            },
        )
        return json.loads(response.output_text.strip())

    def complete_text(
        self,
        model: str,
        instructions: str,
        input_messages: list[dict[str, str]],
    ) -> str:
        """Blocking free-text completion via the Responses API."""
        response = self._sync().responses.create(
            model=model,
            instructions=instructions,
            input=input_messages,
        )
        return response.output_text or ""

    async def stream_text(
        self,
        model: str,
        instructions: str,
        input_messages: list[dict[str, str]],
        *,
        reasoning: bool | None = None,
    ):
        """Yield (event_type, payload) tuples from a streaming Responses call."""
        if reasoning is None:
            reasoning = model_supports_reasoning_summary(model)

        kwargs: dict[str, Any] = {
            "model": model,
            "instructions": instructions,
            "input": input_messages,
            "stream": True,
        }
        if reasoning:
            kwargs["reasoning"] = {"summary": "auto"}

        stream = await self._async().responses.create(**kwargs)
        async for event in stream:
            etype = getattr(event, "type", "")
            if etype == "response.reasoning_summary_text.delta":
                yield "thinking", getattr(event, "delta", "")
            elif etype == "response.output_text.delta":
                yield "token", getattr(event, "delta", "")
            elif etype == "response.completed":
                yield "completed", None
            elif etype in ("response.error", "error"):
                yield "error", str(getattr(event, "error", event))
