"""Parent controls — goals, limits, filters, and gentle guardrails."""

from __future__ import annotations

import hashlib
import json
import re
import time
from datetime import date, datetime, timedelta
from typing import Any, Optional

from parent_dashboard import build_parent_dashboard, estimate_learning_minutes

DIFFICULTIES = ("easy", "medium", "hard")
REPORT_FREQUENCIES = ("off", "weekly", "monthly")
WEEKDAYS = (
    "monday", "tuesday", "wednesday", "thursday",
    "friday", "saturday", "sunday",
)

CONTENT_FILTER_KEYS = (
    "mild_scary",
    "conflict_themes",
    "competitive_themes",
    "external_links",
)


def default_parent_controls() -> dict:
    return {
        "learning_goals": [],
        "daily_learning_minutes": 45,
        "bedtime_enabled": False,
        "bedtime_start": "21:00",
        "bedtime_end": "07:00",
        "allowed_subjects": [],
        "blocked_subjects": [],
        "difficulty_mode": "cap",  # cap | lock
        "max_difficulty": "hard",
        "locked_difficulty": "medium",
        "content_filters": {
            "mild_scary": True,
            "conflict_themes": True,
            "competitive_themes": True,
            "external_links": False,
        },
        "audio_controls": {
            "narration": True,
            "music": True,
            "sfx": True,
            "max_volume": 1.0,
        },
        "screen_time_limit_minutes": 0,
        "session_break_minutes": 25,
        "offline_access_enabled": True,
        "progress_report_frequency": "weekly",
        "progress_report_day": "sunday",
        "pin_set": False,
    }


def init_parent_tables(conn) -> None:
    conn.execute("""
        CREATE TABLE IF NOT EXISTS parent_controls (
            learner_id TEXT PRIMARY KEY,
            controls_json TEXT NOT NULL,
            pin_hash TEXT,
            updated_at REAL
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS parent_daily_usage (
            learner_id TEXT NOT NULL,
            usage_date TEXT NOT NULL,
            minutes_used REAL DEFAULT 0,
            session_count INTEGER DEFAULT 0,
            updated_at REAL,
            PRIMARY KEY (learner_id, usage_date)
        )
    """)
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_parent_usage_learner "
        "ON parent_daily_usage(learner_id, usage_date)"
    )


def _split_tags(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, list):
        items = value
    else:
        items = re.split(r"[,;\n]+", str(value))
    out, seen = [], set()
    for item in items:
        text = str(item).strip()
        if not text:
            continue
        key = text.lower()
        if key in seen:
            continue
        seen.add(key)
        out.append(text[:80])
    return out[:20]


def _parse_time_hhmm(value: str, default: str = "21:00") -> str:
    text = str(value or default).strip()
    m = re.match(r"^(\d{1,2}):(\d{2})$", text)
    if not m:
        return default
    hour, minute = int(m.group(1)), int(m.group(2))
    if 0 <= hour <= 23 and 0 <= minute <= 59:
        return f"{hour:02d}:{minute:02d}"
    return default


def _difficulty_rank(level: str) -> int:
    return {"easy": 0, "medium": 1, "hard": 2}.get(level, 1)


def _hash_pin(learner_id: str, pin: str) -> str:
    raw = f"{learner_id.strip()}:{pin.strip()}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def normalize_parent_controls(data: Optional[dict], *, pin_set: bool = False) -> dict:
    base = default_parent_controls()
    if not data:
        base["pin_set"] = pin_set
        return base

    base["learning_goals"] = _split_tags(data.get("learning_goals"))
    try:
        daily = int(data.get("daily_learning_minutes", 45))
        base["daily_learning_minutes"] = max(0, min(daily, 480))
    except (TypeError, ValueError):
        pass

    base["bedtime_enabled"] = bool(data.get("bedtime_enabled"))
    base["bedtime_start"] = _parse_time_hhmm(data.get("bedtime_start"), "21:00")
    base["bedtime_end"] = _parse_time_hhmm(data.get("bedtime_end"), "07:00")

    base["allowed_subjects"] = _split_tags(data.get("allowed_subjects"))
    base["blocked_subjects"] = _split_tags(data.get("blocked_subjects"))

    mode = str(data.get("difficulty_mode") or "cap").strip().lower()
    base["difficulty_mode"] = mode if mode in ("cap", "lock") else "cap"

    max_diff = str(data.get("max_difficulty") or "hard").strip().lower()
    base["max_difficulty"] = max_diff if max_diff in DIFFICULTIES else "hard"

    locked = str(data.get("locked_difficulty") or "medium").strip().lower()
    base["locked_difficulty"] = locked if locked in DIFFICULTIES else "medium"

    filters = data.get("content_filters") if isinstance(data.get("content_filters"), dict) else {}
    base["content_filters"] = {
        key: bool(filters.get(key, base["content_filters"][key]))
        for key in CONTENT_FILTER_KEYS
    }

    audio = data.get("audio_controls") if isinstance(data.get("audio_controls"), dict) else {}
    try:
        vol = float(audio.get("max_volume", 1.0))
        vol = max(0.0, min(vol, 1.0))
    except (TypeError, ValueError):
        vol = 1.0
    base["audio_controls"] = {
        "narration": bool(audio.get("narration", True)),
        "music": bool(audio.get("music", True)),
        "sfx": bool(audio.get("sfx", True)),
        "max_volume": vol,
    }

    try:
        screen = int(data.get("screen_time_limit_minutes", 0))
        base["screen_time_limit_minutes"] = max(0, min(screen, 480))
    except (TypeError, ValueError):
        pass

    try:
        brk = int(data.get("session_break_minutes", 25))
        base["session_break_minutes"] = max(0, min(brk, 120))
    except (TypeError, ValueError):
        pass

    base["offline_access_enabled"] = bool(data.get("offline_access_enabled", True))

    freq = str(data.get("progress_report_frequency") or "weekly").strip().lower()
    base["progress_report_frequency"] = freq if freq in REPORT_FREQUENCIES else "weekly"

    day = str(data.get("progress_report_day") or "sunday").strip().lower()
    base["progress_report_day"] = day if day in WEEKDAYS else "sunday"

    base["pin_set"] = pin_set
    return base


def get_parent_controls(conn, learner_id: str) -> dict:
    row = conn.execute(
        "SELECT controls_json, pin_hash FROM parent_controls WHERE learner_id = ?",
        (learner_id.strip(),),
    ).fetchone()
    if not row:
        return default_parent_controls()
    try:
        raw = json.loads(row["controls_json"])
    except (json.JSONDecodeError, TypeError):
        raw = {}
    return normalize_parent_controls(raw, pin_set=bool(row["pin_hash"]))


def save_parent_controls(
    conn,
    learner_id: str,
    controls: dict,
    *,
    pin: Optional[str] = None,
    current_pin: Optional[str] = None,
    clear_pin: bool = False,
) -> dict:
    lid = learner_id.strip()
    existing = conn.execute(
        "SELECT pin_hash FROM parent_controls WHERE learner_id = ?",
        (lid,),
    ).fetchone()
    pin_hash = existing["pin_hash"] if existing else None

    if existing and pin_hash:
        if not current_pin or _hash_pin(lid, current_pin) != pin_hash:
            raise PermissionError("Parent PIN required")

    if clear_pin:
        pin_hash = None
    elif pin:
        if not re.match(r"^\d{4}$", str(pin).strip()):
            raise ValueError("PIN must be 4 digits")
        pin_hash = _hash_pin(lid, pin)

    normalized = normalize_parent_controls(controls, pin_set=bool(pin_hash))
    now = time.time()
    conn.execute(
        """
        INSERT INTO parent_controls (learner_id, controls_json, pin_hash, updated_at)
        VALUES (?, ?, ?, ?)
        ON CONFLICT(learner_id) DO UPDATE SET
            controls_json = excluded.controls_json,
            pin_hash = excluded.pin_hash,
            updated_at = excluded.updated_at
        """,
        (lid, json.dumps(normalized), pin_hash, now),
    )
    return normalized


def verify_parent_pin(conn, learner_id: str, pin: str) -> bool:
    row = conn.execute(
        "SELECT pin_hash FROM parent_controls WHERE learner_id = ?",
        (learner_id.strip(),),
    ).fetchone()
    if not row or not row["pin_hash"]:
        return True
    return _hash_pin(learner_id, pin) == row["pin_hash"]


def _today_key() -> str:
    return date.today().isoformat()


def get_daily_usage(conn, learner_id: str, usage_date: Optional[str] = None) -> dict:
    day = usage_date or _today_key()
    row = conn.execute(
        """SELECT minutes_used, session_count FROM parent_daily_usage
           WHERE learner_id = ? AND usage_date = ?""",
        (learner_id.strip(), day),
    ).fetchone()
    if not row:
        return {"date": day, "minutes_used": 0.0, "session_count": 0}
    return {
        "date": day,
        "minutes_used": float(row["minutes_used"] or 0),
        "session_count": int(row["session_count"] or 0),
    }


def record_session_minutes(
    conn,
    learner_id: str,
    minutes: float,
    *,
    usage_date: Optional[str] = None,
) -> dict:
    lid = learner_id.strip()
    mins = max(0.0, min(float(minutes), 60.0))
    if mins <= 0:
        return get_daily_usage(conn, lid, usage_date)

    day = usage_date or _today_key()
    now = time.time()
    conn.execute(
        """
        INSERT INTO parent_daily_usage (learner_id, usage_date, minutes_used, session_count, updated_at)
        VALUES (?, ?, ?, 1, ?)
        ON CONFLICT(learner_id, usage_date) DO UPDATE SET
            minutes_used = minutes_used + excluded.minutes_used,
            session_count = session_count + 1,
            updated_at = excluded.updated_at
        """,
        (lid, day, mins, now),
    )
    return get_daily_usage(conn, lid, day)


def _minutes_since_midnight(now: datetime) -> int:
    return now.hour * 60 + now.minute


def _hhmm_to_minutes(hhmm: str) -> int:
    hour, minute = map(int, hhmm.split(":"))
    return hour * 60 + minute


def is_bedtime_active(controls: dict, now: Optional[datetime] = None) -> bool:
    if not controls.get("bedtime_enabled"):
        return False
    now = now or datetime.now()
    start = _hhmm_to_minutes(controls.get("bedtime_start", "21:00"))
    end = _hhmm_to_minutes(controls.get("bedtime_end", "07:00"))
    current = _minutes_since_midnight(now)
    if start < end:
        return start <= current < end
    return current >= start or current < end


def is_subject_allowed(controls: dict, subject: str) -> bool:
    name = (subject or "").strip()
    if not name:
        return True
    blocked = {s.lower() for s in controls.get("blocked_subjects") or []}
    if name.lower() in blocked:
        return False
    allowed = controls.get("allowed_subjects") or []
    if not allowed:
        return True
    allowed_lower = {s.lower() for s in allowed}
    return name.lower() in allowed_lower


def get_effective_difficulty(
    controls: dict,
    selected: str = "medium",
    child_preferred: Optional[str] = None,
) -> str:
    selected = selected if selected in DIFFICULTIES else "medium"
    if controls.get("difficulty_mode") == "lock":
        return controls.get("locked_difficulty", "medium")
    cap = controls.get("max_difficulty", "hard")
    best = selected
    if child_preferred in DIFFICULTIES:
        best = child_preferred
    if _difficulty_rank(best) > _difficulty_rank(cap):
        return cap
    if _difficulty_rank(selected) > _difficulty_rank(cap):
        return cap
    return selected


def effective_daily_limit(controls: dict) -> int:
    screen = int(controls.get("screen_time_limit_minutes") or 0)
    daily = int(controls.get("daily_learning_minutes") or 0)
    if screen > 0 and daily > 0:
        return min(screen, daily)
    return screen or daily


def build_usage_status(conn, learner_id: str, controls: Optional[dict] = None) -> dict:
    controls = controls or get_parent_controls(conn, learner_id)
    usage = get_daily_usage(conn, learner_id)
    limit = effective_daily_limit(controls)
    minutes_used = usage["minutes_used"]
    remaining = None if limit <= 0 else max(0.0, limit - minutes_used)
    bedtime = is_bedtime_active(controls)
    blocked_reason = None
    can_learn = True
    if bedtime:
        can_learn = False
        blocked_reason = "bedtime"
    elif remaining is not None and remaining <= 0:
        can_learn = False
        blocked_reason = "daily_limit"

    return {
        "can_learn": can_learn,
        "blocked_reason": blocked_reason,
        "bedtime_active": bedtime,
        "bedtime_window": {
            "start": controls.get("bedtime_start"),
            "end": controls.get("bedtime_end"),
        },
        "daily_limit_minutes": limit,
        "minutes_used_today": round(minutes_used, 1),
        "minutes_remaining": round(remaining, 1) if remaining is not None else None,
        "session_break_minutes": int(controls.get("session_break_minutes") or 0),
        "offline_access_enabled": bool(controls.get("offline_access_enabled")),
        "effective_difficulty": get_effective_difficulty(controls),
        "audio_controls": controls.get("audio_controls") or {},
        "content_filters": controls.get("content_filters") or {},
        "allowed_subjects": controls.get("allowed_subjects") or [],
        "blocked_subjects": controls.get("blocked_subjects") or [],
    }


def controls_catalog() -> dict:
    return {
        "difficulties": list(DIFFICULTIES),
        "difficulty_modes": [
            {"id": "cap", "label": "Cap maximum difficulty"},
            {"id": "lock", "label": "Lock to one difficulty"},
        ],
        "report_frequencies": list(REPORT_FREQUENCIES),
        "report_days": list(WEEKDAYS),
        "content_filters": [
            {"id": "mild_scary", "label": "Mild scary or suspenseful themes"},
            {"id": "conflict_themes", "label": "Conflict & dilemma storylines"},
            {"id": "competitive_themes", "label": "Competitive/win-lose framing"},
            {"id": "external_links", "label": "References to external websites"},
        ],
        "defaults": default_parent_controls(),
    }


def content_filter_prompt_block(controls: Optional[dict]) -> str:
    if not controls:
        return ""
    filters = controls.get("content_filters") or {}
    lines = ["PARENT CONTENT GUIDELINES:"]
    if not filters.get("mild_scary", True):
        lines.append("- Avoid scary, spooky, or intense suspense.")
    if not filters.get("conflict_themes", True):
        lines.append("- Keep conflict gentle; emphasize cooperation over confrontation.")
    if not filters.get("competitive_themes", True):
        lines.append("- Avoid harsh competition; focus on curiosity and growth.")
    if not filters.get("external_links", False):
        lines.append("- Do not mention external websites or apps.")
    goals = controls.get("learning_goals") or []
    if goals:
        lines.append(f"- Weave parent learning goals when natural: {', '.join(goals)}.")
    return "\n".join(lines) + "\n" if len(lines) > 1 else ""


def parent_controls_prompt_block(controls: Optional[dict]) -> str:
    if not controls:
        return ""
    block = content_filter_prompt_block(controls)
    goals = controls.get("learning_goals") or []
    if goals and "learning goals" not in block.lower():
        block += "PARENT LEARNING GOALS: " + ", ".join(goals) + ".\n"
    diff = get_effective_difficulty(controls)
    block += f"PARENT DIFFICULTY GUIDANCE: Keep activities at {diff} level unless adaptive engine adjusts.\n"
    return block


def sync_learning_goals_to_child(conn, learner_id: str, goals: list[str]) -> None:
    from child_profile import get_child_profile, save_child_profile

    profile = get_child_profile(conn, learner_id) or {}
    profile["learning_goals"] = goals
    save_child_profile(conn, learner_id, profile)


def build_progress_report(conn, learner_id: str, *, days: int = 7) -> dict:
    dashboard = build_parent_dashboard(conn, learner_id)
    controls = get_parent_controls(conn, learner_id)
    lid = learner_id.strip()
    since = (date.today() - timedelta(days=days - 1)).isoformat()
    rows = conn.execute(
        """SELECT usage_date, minutes_used, session_count FROM parent_daily_usage
           WHERE learner_id = ? AND usage_date >= ?
           ORDER BY usage_date ASC""",
        (lid, since),
    ).fetchall()
    daily_log = [
        {
            "date": r["usage_date"],
            "minutes": round(float(r["minutes_used"] or 0), 1),
            "sessions": int(r["session_count"] or 0),
        }
        for r in rows
    ]
    total_tracked = sum(d["minutes"] for d in daily_log)
    gamification = dashboard.get("time_spent") or {}
    return {
        "learner_id": lid,
        "child_name": dashboard.get("child_name"),
        "period_days": days,
        "generated_at": time.time(),
        "summary": {
            "stories_completed": dashboard.get("stories_completed"),
            "topics_explored": dashboard.get("topics_explored"),
            "skills_mastered": dashboard.get("skills", {}).get("mastered_count"),
            "streak": dashboard.get("streak"),
            "estimated_minutes": gamification.get("total_minutes"),
            "tracked_minutes_this_period": round(total_tracked, 1),
        },
        "daily_usage": daily_log,
        "strengths": dashboard.get("strengths"),
        "learning_gaps": dashboard.get("learning_gaps"),
        "topic_highlights": (dashboard.get("topic_insights") or [])[:5],
        "recent_achievements": dashboard.get("recent_achievements"),
        "controls_snapshot": {
            "daily_learning_minutes": controls.get("daily_learning_minutes"),
            "bedtime_enabled": controls.get("bedtime_enabled"),
            "progress_report_frequency": controls.get("progress_report_frequency"),
        },
        "report_note": (
            "Growth-focused summary for family conversations — "
            "not a surveillance log."
        ),
    }
