"""Parent dashboard — actionable learning insights (not surveillance)."""

from __future__ import annotations

import json
import time
from typing import Any, Optional

from adaptive_learning import concept_key, infer_concept_tag, list_concept_states, mastery_label
from child_profile import READING_LEVELS, get_child_profile
from interest_engine import STORY_THEMES, build_interest_model
from spaced_rep import count_due_items, list_all_items

# Sub-skill facets per concept tag — parent-facing labels
SKILL_FACETS: dict[str, list[tuple[str, str]]] = {
    "fractions": [
        ("basics", "basic fractions"),
        ("compare", "comparing fractions"),
        ("equivalent", "equivalent fractions"),
    ],
    "multiplication": [
        ("facts", "multiplication facts"),
        ("word_problems", "multiplication word problems"),
        ("multi_step", "multi-step problems"),
    ],
    "division": [
        ("basics", "division basics"),
        ("remainders", "remainders"),
        ("word_problems", "division word problems"),
    ],
    "addition": [
        ("mental", "mental addition"),
        ("carrying", "carrying/regrouping"),
        ("word_problems", "addition word problems"),
    ],
    "subtraction": [
        ("mental", "mental subtraction"),
        ("borrowing", "borrowing/regrouping"),
        ("word_problems", "subtraction word problems"),
    ],
    "percentages": [
        ("basics", "percent basics"),
        ("compare", "comparing percentages"),
        ("real_world", "real-world percent problems"),
    ],
    "geometry": [
        ("shapes", "shapes & angles"),
        ("area", "area & perimeter"),
        ("reasoning", "spatial reasoning"),
    ],
    "grammar": [
        ("parts_of_speech", "parts of speech"),
        ("sentences", "sentence structure"),
        ("punctuation", "punctuation"),
    ],
    "vocabulary": [
        ("meaning", "word meanings"),
        ("context", "context clues"),
        ("usage", "using words in writing"),
    ],
    "forces": [
        ("motion", "motion basics"),
        ("energy", "energy transfers"),
        ("experiments", "hands-on reasoning"),
    ],
    "classification": [
        ("observe", "observation skills"),
        ("groups", "sorting & classifying"),
        ("habitats", "habitats & adaptation"),
    ],
    "general": [
        ("explore", "exploring the topic"),
        ("practice", "guided practice"),
        ("apply", "applying ideas"),
    ],
}

STATUS_EMOJI = {"green": "🟢", "yellow": "🟡", "red": "🔴"}
STATUS_LABELS = {
    "green": "Understands",
    "yellow": "Needs practice",
    "red": "Needs reinforcement",
}

READING_LEVEL_ORDER = list(READING_LEVELS.keys())

MINUTES_PER_ACTIVITY = {
    "stories": 8,
    "quizzes": 6,
    "flashcards": 2,
    "adventures": 12,
    "storyWorlds": 15,
    "mindmaps": 5,
    "puzzles": 4,
    "doubts": 3,
    "projects": 12,
}


def _facet_status(
    facet_index: int,
    mastery: float,
    quiz_tier: Optional[str],
    recent_misses: int,
) -> str:
    """Map mastery + quiz to green/yellow/red per facet depth."""
    tier_bonus = {"gold": 0.15, "silver": 0.08, "bronze": 0.0}.get(quiz_tier or "", 0)
    effective = mastery + tier_bonus - (0.05 * min(recent_misses, 4))
    thresholds = (0.35 + facet_index * 0.18, 0.55 + facet_index * 0.12)
    if effective >= thresholds[1]:
        return "green"
    if effective >= thresholds[0]:
        return "yellow"
    return "red"


def build_topic_insights(
    topic: str,
    subject: str,
    *,
    quiz_tier: Optional[str] = None,
    quiz_pct: Optional[int] = None,
    concept_state: Optional[dict] = None,
) -> list[dict]:
    """Actionable sub-skills for one topic (e.g. Fractions with 🟢🟡🔴 lines)."""
    tag = infer_concept_tag(subject, topic)
    facets = SKILL_FACETS.get(tag) or SKILL_FACETS["general"]
    mastery = float((concept_state or {}).get("mastery_score") or 0)
    if quiz_pct is not None and quiz_pct >= 90:
        mastery = max(mastery, 0.85)
    elif quiz_pct is not None and quiz_pct >= 60:
        mastery = max(mastery, 0.55)
    recent_misses = int((concept_state or {}).get("recent_misses") or 0)

    insights = []
    for i, (_key, label) in enumerate(facets):
        status = _facet_status(i, mastery, quiz_tier, recent_misses)
        insights.append({
            "status": status,
            "emoji": STATUS_EMOJI[status],
            "label": label,
            "message": f"{STATUS_LABELS[status]} {label}",
        })
    return insights


def estimate_learning_minutes(gamification: dict) -> dict:
    stats = gamification.get("stats") or {}
    by_activity = {}
    total = 0
    for key, mins in MINUTES_PER_ACTIVITY.items():
        count = int(stats.get(key) or 0)
        if count:
            est = count * mins
            by_activity[key] = est
            total += est
    days_active = len(gamification.get("daysActive") or {})
    return {
        "total_minutes": total,
        "total_hours": round(total / 60, 1) if total else 0,
        "by_activity": by_activity,
        "days_active": days_active,
        "note": "Estimated from stories, quizzes, and adventures — not screen monitoring.",
    }


def _reading_progress(child_profile: Optional[dict], stories_done: int) -> dict:
    level = (child_profile or {}).get("reading_level") or "grade_level"
    meta = READING_LEVELS.get(level, READING_LEVELS["grade_level"])
    idx = READING_LEVEL_ORDER.index(level) if level in READING_LEVEL_ORDER else 2
    return {
        "level": level,
        "label": meta["name"],
        "emoji": meta["emoji"],
        "stories_read": stories_done,
        "message": (
            f"Reading at {meta['name']} level with {stories_done} stories completed."
            if stories_done
            else f"Profile set to {meta['name']} — stories will match this level."
        ),
        "progress_index": idx,
        "max_index": len(READING_LEVEL_ORDER) - 1,
    }


def _math_progress(topics: list[dict], concept_states: list[dict]) -> dict:
    math_topics = [
        t for t in topics
        if "math" in (t.get("subject") or "").lower()
    ]
    if not math_topics:
        return {"topics_explored": 0, "message": "Math adventures will appear here as they explore."}

    mastered = sum(1 for t in math_topics if t.get("quiz_tier") == "gold")
    practicing = sum(1 for t in math_topics if t.get("quiz_tier") in ("silver", "bronze"))
    concept_math = [c for c in concept_states if "math" in (c.get("subject") or "").lower()]
    avg_mastery = 0.0
    if concept_math:
        avg_mastery = sum(c.get("mastery_score", 0) for c in concept_math) / len(concept_math)

    return {
        "topics_explored": len(math_topics),
        "quiz_mastered": mastered,
        "still_practicing": practicing,
        "average_mastery": round(avg_mastery, 2),
        "mastery_label": mastery_label(avg_mastery),
        "message": (
            f"Explored {len(math_topics)} math topics — "
            f"{mastered} with strong quiz mastery."
        ),
    }


def _vocabulary_growth(topics: list[dict], interest_model: dict) -> dict:
    lang_topics = [
        t for t in topics
        if any(s in (t.get("subject") or "").lower() for s in ("english", "hindi", "language"))
    ]
    themes = interest_model.get("top_themes") or []
    word_topics = [t for t in topics if "vocab" in (t.get("topic") or "").lower()
                   or "spell" in (t.get("topic") or "").lower()]

    return {
        "language_topics": len(lang_topics),
        "vocabulary_topics": len(word_topics),
        "favorite_themes": [STORY_THEMES.get(t, {}).get("name", t) for t in themes[:3]],
        "message": (
            "Vocabulary grows through stories, flashcards, and word play — "
            f"{len(lang_topics)} language topics explored so far."
        ),
    }


def _skills_summary(concept_states: list[dict], topics: list[dict]) -> dict:
    practiced_tags: set[str] = set()
    mastered_tags: set[str] = set()
    reinforce_tags: set[str] = set()

    for state in concept_states:
        tag = state.get("concept_tag") or "general"
        practiced_tags.add(tag)
        score = float(state.get("mastery_score") or 0)
        if score >= 0.75:
            mastered_tags.add(tag)
        elif score < 0.4 or int(state.get("recent_misses") or 0) >= 2:
            reinforce_tags.add(tag)

    for t in topics:
        if t.get("quiz_tier") == "gold":
            tag = infer_concept_tag(t.get("subject", ""), t.get("topic", ""))
            mastered_tags.add(tag)
        elif t.get("steps", {}).get("quiz") and t.get("quiz_tier") != "gold":
            tag = infer_concept_tag(t.get("subject", ""), t.get("topic", ""))
            practiced_tags.add(tag)

    def _tag_name(tag: str) -> str:
        return tag.replace("_", " ").title()

    return {
        "practiced_count": len(practiced_tags),
        "mastered_count": len(mastered_tags),
        "reinforcement_count": len(reinforce_tags),
        "practiced": sorted(_tag_name(t) for t in practiced_tags)[:8],
        "mastered": sorted(_tag_name(t) for t in mastered_tags)[:8],
        "needs_reinforcement": sorted(_tag_name(t) for t in reinforce_tags - mastered_tags)[:8],
    }


def _strengths_and_gaps(topic_insights: list[dict]) -> tuple[list[str], list[str]]:
    strengths = []
    gaps = []
    for block in topic_insights:
        greens = [i for i in block.get("insights") or [] if i["status"] == "green"]
        reds = [i for i in block.get("insights") or [] if i["status"] == "red"]
        if greens:
            strengths.append(f"{block['topic']}: {greens[0]['label']}")
        if reds:
            gaps.append(f"{block['topic']}: {reds[0]['label']}")
    return strengths[:6], gaps[:6]


def _recent_achievements(gamification: dict, learner_profile: dict) -> list[dict]:
    achievements = []
    badges = gamification.get("badges") or []
    badge_names = {
        "first_story": ("📖", "First story finished"),
        "quiz_bronze": ("🥉", "First quiz completed"),
        "quiz_silver": ("🥈", "Silver quiz mastery"),
        "quiz_gold": ("🥇", "Gold quiz mastery"),
        "streak_3": ("🔥", "3-day learning streak"),
        "streak_7": ("🔥", "Week-long streak"),
        "adventure_1": ("🗺️", "First adventure"),
        "story_world_1": ("🌍", "First Story World"),
    }
    for bid in badges[-8:]:
        emoji, label = badge_names.get(bid, ("🏆", bid.replace("_", " ").title()))
        achievements.append({"id": bid, "emoji": emoji, "label": label})

    companion = learner_profile.get("companion") or {}
    if companion.get("unlocked"):
        achievements.append({
            "id": "companion_growth",
            "emoji": companion.get("emoji", "🦊"),
            "label": f"{companion.get('name', 'Companion')} is growing!",
        })

    projects = learner_profile.get("project_adventures") or {}
    for pid, run in (projects.get("projects") or {}).items():
        done = len(run.get("completed_steps") or [])
        if done:
            achievements.append({
                "id": f"project_{pid}",
                "emoji": "🚀",
                "label": f"Project mission: {done} steps completed",
            })

    stats = gamification.get("stats") or {}
    if stats.get("quizzes", 0) >= 5:
        achievements.append({"id": "quiz_5", "emoji": "🎯", "label": "Five quizzes completed"})
    return achievements[-10:]


def _favorite_topics(interest_model: dict, topics: list[dict]) -> list[dict]:
    favorites = []
    for theme_id in (interest_model.get("top_themes") or [])[:5]:
        meta = STORY_THEMES.get(theme_id, {})
        favorites.append({
            "type": "theme",
            "id": theme_id,
            "label": meta.get("name", theme_id.replace("_", " ").title()),
            "emoji": meta.get("emoji", "✨"),
        })

    subject_counts: dict[str, int] = {}
    for t in topics:
        subj = t.get("subject") or "General"
        subject_counts[subj] = subject_counts.get(subj, 0) + 1
    for subj, count in sorted(subject_counts.items(), key=lambda x: -x[1])[:4]:
        favorites.append({
            "type": "subject",
            "id": subj,
            "label": subj,
            "emoji": "📚",
            "activity_count": count,
        })
    return favorites


def _list_learning_progress(conn, learner_id: str) -> list[dict]:
    rows = conn.execute(
        """SELECT topic_key, grade, subject, topic, difficulty,
                  story_done, mindmap_done, flashcards_done, quiz_done,
                  quiz_tier, quiz_pct, updated_at
           FROM learning_progress WHERE learner_id = ?
           ORDER BY updated_at DESC""",
        (learner_id.strip(),),
    ).fetchall()
    out = []
    for row in rows:
        steps = {
            "story": bool(row["story_done"]),
            "mindmap": bool(row["mindmap_done"]),
            "flashcards": bool(row["flashcards_done"]),
            "quiz": bool(row["quiz_done"]),
        }
        done = sum(1 for v in steps.values() if v)
        out.append({
            "topic_key": row["topic_key"],
            "grade": row["grade"],
            "subject": row["subject"],
            "topic": row["topic"],
            "difficulty": row["difficulty"],
            "steps": steps,
            "quiz_tier": row["quiz_tier"],
            "quiz_pct": row["quiz_pct"],
            "completion_pct": round(done / 4 * 100),
            "updated_at": row["updated_at"],
        })
    return out


def _get_learner_profile(conn, learner_id: str) -> dict:
    row = conn.execute(
        "SELECT profile_json FROM learner_profile WHERE learner_id = ?",
        (learner_id.strip(),),
    ).fetchone()
    if not row:
        return {}
    try:
        return json.loads(row["profile_json"])
    except (json.JSONDecodeError, TypeError):
        return {}


def build_parent_dashboard(
    conn,
    learner_id: str,
    *,
    child_profile: Optional[dict] = None,
) -> dict:
    """Aggregate parent-facing insights — growth-focused, not surveillance."""
    lid = learner_id.strip()
    learner_profile = _get_learner_profile(conn, lid)
    gamification = learner_profile

    topics = _list_learning_progress(conn, lid)
    concept_states = list_concept_states(conn, lid)
    concept_by_key = {c.get("concept_key"): c for c in concept_states}

    cp = child_profile
    if not cp:
        cp = get_child_profile(conn, lid)

    interest_model = build_interest_model(conn, lid, cp)
    spaced_due = count_due_items(conn, lid)
    spaced_total = len(list_all_items(conn, lid, limit=200))

    stories_done = int((gamification.get("stats") or {}).get("stories") or 0)
    if not stories_done:
        stories_done = sum(1 for t in topics if t.get("steps", {}).get("story"))

    topic_insight_blocks = []
    for t in topics:
        tag = infer_concept_tag(t.get("subject", ""), t.get("topic", ""))
        key = concept_key(t.get("grade", 0), t.get("subject", ""), t.get("topic", ""), tag)
        state = concept_by_key.get(key)
        insights = build_topic_insights(
            t.get("topic", ""),
            t.get("subject", ""),
            quiz_tier=t.get("quiz_tier"),
            quiz_pct=t.get("quiz_pct"),
            concept_state=state,
        )
        steps = t.get("steps") or {}
        topic_insight_blocks.append({
            "topic": t.get("topic"),
            "subject": t.get("subject"),
            "grade": t.get("grade"),
            "quiz_tier": t.get("quiz_tier"),
            "path_complete": all([
                steps.get("story"), steps.get("mindmap"),
                steps.get("flashcards"), steps.get("quiz"),
            ]),
            "insights": insights,
        })

    topic_insight_blocks.sort(
        key=lambda x: (0 if any(i["status"] == "red" for i in x["insights"]) else 1, x["topic"]),
    )

    strengths, gaps = _strengths_and_gaps(topic_insight_blocks)
    skills = _skills_summary(concept_states, topics)
    child_name = (cp or {}).get("name") or "Your learner"

    return {
        "learner_id": lid,
        "child_name": child_name,
        "privacy_note": (
            "This dashboard highlights learning growth — not minute-by-minute monitoring. "
            "Use it to celebrate progress and support practice together."
        ),
        "time_spent": estimate_learning_minutes(gamification),
        "stories_completed": stories_done,
        "topics_explored": len(topics),
        "skills": skills,
        "topic_insights": topic_insight_blocks[:12],
        "favorite_topics": _favorite_topics(interest_model, topics),
        "strengths": strengths,
        "learning_gaps": gaps,
        "reading_progress": _reading_progress(cp, stories_done),
        "math_progress": _math_progress(topics, concept_states),
        "vocabulary_growth": _vocabulary_growth(topics, interest_model),
        "spaced_repetition": {
            "due_count": spaced_due,
            "total_items": spaced_total,
            "message": (
                f"{spaced_due} friendly review{'s' if spaced_due != 1 else ''} ready "
                "when they want to practice."
            ) if spaced_due else "No reviews due — great recall!",
        },
        "recent_achievements": _recent_achievements(gamification, learner_profile),
        "streak": int(gamification.get("streak") or 0),
        "level": int(gamification.get("level") or 1),
        "generated_at": time.time(),
    }
