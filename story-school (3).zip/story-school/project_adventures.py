"""Project-based adventures — multi-day, multi-subject learning quests."""

from __future__ import annotations

import copy
import time
from datetime import date
from typing import Any, Optional

MAX_STEPS_PER_DAY = 2

PROJECT_ADVENTURES: list[dict[str, Any]] = [
    {
        "id": "build_a_rocket",
        "title": "Build a Rocket",
        "emoji": "🚀",
        "tagline": "A multi-day mission across science, math, and engineering.",
        "duration_days": "5–7",
        "subjects": ["Science", "Mathematics", "Geography", "Critical Thinking"],
        "synopsis": (
            "You are a young engineer at the StorySchool Space Agency. "
            "Over several days, learn the solar system, calculate a course, "
            "design your rocket, choose fuel, solve a real engineering puzzle, launch, "
            "and analyze what happened — just like real scientists!"
        ),
        "steps": [
            {
                "id": "learn_planets",
                "order": 1,
                "title": "Learn the Planets",
                "emoji": "🪐",
                "suggested_day": 1,
                "subjects": ["Science", "Geography"],
                "activity": "learn",
                "brief": (
                    "Explore the solar system! Learn which planets are rocky vs gas giants, "
                    "how far they are from the Sun, and pick a destination for your mission."
                ),
                "objectives": [
                    "Name at least 4 planets",
                    "Explain one difference between inner and outer planets",
                    "Choose a target planet and say why",
                ],
                "interaction": "choice",
                "choices": [
                    {"id": "mars", "label": "Mars — close enough to practice, exciting red dust!", "emoji": "🔴"},
                    {"id": "jupiter", "label": "Jupiter — huge gas giant, wild storms to study", "emoji": "🟠"},
                    {"id": "moon", "label": "Earth's Moon — nearest neighbor, perfect first flight", "emoji": "🌙"},
                ],
                "xp": 25,
            },
            {
                "id": "calculate_distance",
                "order": 2,
                "title": "Calculate Distance",
                "emoji": "📐",
                "suggested_day": 2,
                "subjects": ["Mathematics", "Science"],
                "activity": "calculate",
                "brief": (
                    "Your rocket must travel millions of kilometers. "
                    "Use multiplication and unit conversion to estimate how far your mission will go."
                ),
                "objectives": [
                    "Convert km to millions of km",
                    "Estimate travel time at rocket speed",
                ],
                "interaction": "numeric",
                "problem": (
                    "If your target is 384,400 km away (like the Moon) and your rocket travels "
                    "40,000 km per day, about how many days will the trip take? (Round to nearest whole day.)"
                ),
                "acceptable_answers": ["10", "9", "9.61", "9.6"],
                "correct_answer": "10",
                "explanation": "384,400 ÷ 40,000 ≈ 9.6, so about 10 days.",
                "xp": 30,
            },
            {
                "id": "design_rocket",
                "order": 3,
                "title": "Design the Rocket",
                "emoji": "🛠️",
                "suggested_day": 3,
                "subjects": ["Science", "Creativity", "Engineering"],
                "activity": "design",
                "brief": (
                    "Sketch your rocket in words: nose cone, body, fins, and crew capsule. "
                    "Each part has a job — stability, speed, or safety."
                ),
                "objectives": [
                    "Name 3 rocket parts and their jobs",
                    "Choose a design priority: speed, safety, or cargo",
                ],
                "interaction": "design",
                "design_options": [
                    {"id": "speed", "label": "Sleek & fast", "emoji": "⚡"},
                    {"id": "safety", "label": "Extra-safe crew capsule", "emoji": "🛡️"},
                    {"id": "cargo", "label": "Big science lab inside", "emoji": "🔬"},
                ],
                "min_words": 20,
                "xp": 28,
            },
            {
                "id": "choose_fuel",
                "order": 4,
                "title": "Choose Fuel",
                "emoji": "⛽",
                "suggested_day": 4,
                "subjects": ["Science", "Ethics", "Resource Management"],
                "activity": "choose",
                "brief": (
                    "Every fuel has trade-offs: power, pollution, and cost. "
                    "There is no single right answer — your choice shapes the mission!"
                ),
                "objectives": [
                    "Compare two fuel types",
                    "Explain a trade-off in your choice",
                ],
                "interaction": "dilemma",
                "choices": [
                    {
                        "id": "hydrogen",
                        "label": "Liquid hydrogen — powerful & clean burn",
                        "emoji": "💧",
                        "consequence": "Strong thrust but needs huge cold tanks.",
                    },
                    {
                        "id": "kerosene",
                        "label": "Kerosene — reliable and easier to store",
                        "emoji": "🛢️",
                        "consequence": "Heavier but simpler for a first test flight.",
                    },
                    {
                        "id": "hybrid",
                        "label": "Hybrid mix — balance power and safety",
                        "emoji": "⚖️",
                        "consequence": "Slower to build but flexible for learners.",
                    },
                ],
                "xp": 25,
            },
            {
                "id": "engineering_problem",
                "order": 5,
                "title": "Solve an Engineering Problem",
                "emoji": "🧩",
                "suggested_day": 5,
                "subjects": ["Mathematics", "Science", "Problem Solving"],
                "activity": "solve",
                "brief": (
                    "Mission Control found a wobble in your rocket! "
                    "The fins are uneven — fix the load so the rocket flies straight."
                ),
                "objectives": [
                    "Balance weight on both sides",
                    "Explain why symmetry matters in flight",
                ],
                "interaction": "mcq",
                "question": "Each fin must carry equal weight. You have 12 kg to split across 3 fins per side. How many kg per fin?",
                "options": ["2 kg", "4 kg", "6 kg", "12 kg"],
                "correct_index": 1,
                "explanation": "12 kg ÷ 3 fins = 4 kg on each fin.",
                "xp": 35,
            },
            {
                "id": "launch",
                "order": 6,
                "title": "Launch!",
                "emoji": "🚀",
                "suggested_day": 6,
                "subjects": ["Science", "Language"],
                "activity": "launch",
                "brief": (
                    "Countdown… 3… 2… 1… LIFTOFF! "
                    "Describe what you see, hear, and feel as your rocket rises."
                ),
                "objectives": [
                    "Use sensory details (sight, sound, feeling)",
                    "Celebrate teamwork on the mission",
                ],
                "interaction": "launch",
                "min_words": 15,
                "xp": 40,
            },
            {
                "id": "analyze_result",
                "order": 7,
                "title": "Analyze the Result",
                "emoji": "📊",
                "suggested_day": 7,
                "subjects": ["Science", "Critical Thinking", "Mathematics"],
                "activity": "analyze",
                "brief": (
                    "Every mission teaches something — even surprises! "
                    "Review your flight data: Did you reach the target? What would you change next time?"
                ),
                "objectives": [
                    "State one success from the mission",
                    "Name one improvement for Mission 2",
                    "Connect results to a science idea you learned",
                ],
                "interaction": "reflect",
                "min_words": 25,
                "xp": 45,
            },
        ],
    },
    {
        "id": "community_garden",
        "title": "Grow a Community Garden",
        "emoji": "🌻",
        "tagline": "Plan, plant, and share — ecology meets math and kindness.",
        "duration_days": "5–6",
        "subjects": ["Science", "Mathematics", "Social Studies", "Life Skills"],
        "synopsis": (
            "Turn an empty plot into a thriving garden for your neighborhood. "
            "Study soil and sunlight, budget seeds, design beds, solve a water puzzle, "
            "harvest, and reflect on feeding your community."
        ),
        "steps": [
            {
                "id": "study_soil",
                "order": 1,
                "title": "Study Soil & Sunlight",
                "emoji": "☀️",
                "suggested_day": 1,
                "subjects": ["Science", "Geography"],
                "activity": "learn",
                "brief": "Observe where the sun hits the plot and what soil needs for plants to grow.",
                "objectives": ["Name what plants need", "Pick the sunniest bed location"],
                "interaction": "choice",
                "choices": [
                    {"id": "north", "label": "North bed — shady, good for lettuce", "emoji": "🥬"},
                    {"id": "south", "label": "South bed — sunniest, great for tomatoes", "emoji": "🍅"},
                    {"id": "east", "label": "East bed — morning sun, herbs love it", "emoji": "🌿"},
                ],
                "xp": 22,
            },
            {
                "id": "budget_seeds",
                "order": 2,
                "title": "Budget the Seeds",
                "emoji": "🪙",
                "suggested_day": 2,
                "subjects": ["Mathematics", "Financial Literacy"],
                "activity": "calculate",
                "brief": "You have 100 coins. Seed packs cost 15 coins each. How many packs can you buy?",
                "objectives": ["Use division with remainders", "Plan spending"],
                "interaction": "numeric",
                "problem": "With 100 coins and packs at 15 coins each, how many full packs can you buy?",
                "acceptable_answers": ["6"],
                "correct_answer": "6",
                "explanation": "100 ÷ 15 = 6 remainder 10 — six full packs.",
                "xp": 28,
            },
            {
                "id": "design_beds",
                "order": 3,
                "title": "Design Garden Beds",
                "emoji": "📐",
                "suggested_day": 3,
                "subjects": ["Mathematics", "Creativity"],
                "activity": "design",
                "brief": "Draw beds in words: rows, paths, and water access.",
                "objectives": ["Plan spacing", "Leave room to walk"],
                "interaction": "design",
                "design_options": [
                    {"id": "rows", "label": "Long rows", "emoji": "📏"},
                    {"id": "circles", "label": "Round keyhole beds", "emoji": "⭕"},
                    {"id": "mixed", "label": "Mix of flowers & veggies", "emoji": "🌸"},
                ],
                "min_words": 18,
                "xp": 25,
            },
            {
                "id": "water_puzzle",
                "order": 4,
                "title": "Solve the Water Puzzle",
                "emoji": "💧",
                "suggested_day": 4,
                "subjects": ["Science", "Problem Solving"],
                "activity": "solve",
                "brief": "The hose reaches 8 meters. The far bed is 10 m away. What can you do?",
                "objectives": ["Propose a fair solution", "Think about sharing water"],
                "interaction": "dilemma",
                "choices": [
                    {"id": "extend", "label": "Add a longer hose section", "emoji": "🔗"},
                    {"id": "buckets", "label": "Carry buckets as a team", "emoji": "🪣"},
                    {"id": "rain", "label": "Collect rainwater barrels", "emoji": "🌧️"},
                ],
                "xp": 30,
            },
            {
                "id": "harvest",
                "order": 5,
                "title": "Harvest & Share",
                "emoji": "🧺",
                "suggested_day": 5,
                "subjects": ["Life Skills", "Kindness"],
                "activity": "launch",
                "brief": "Harvest day! Describe sharing food with neighbors.",
                "objectives": ["Celebrate community", "Reflect on kindness"],
                "interaction": "launch",
                "min_words": 15,
                "xp": 35,
            },
            {
                "id": "garden_reflect",
                "order": 6,
                "title": "Analyze the Season",
                "emoji": "📊",
                "suggested_day": 6,
                "subjects": ["Science", "Critical Thinking"],
                "activity": "analyze",
                "brief": "What grew well? What will you plant next season?",
                "objectives": ["Name a success", "Plan an improvement"],
                "interaction": "reflect",
                "min_words": 20,
                "xp": 38,
            },
        ],
    },
]

PROJECT_BY_ID = {p["id"]: p for p in PROJECT_ADVENTURES}


def project_catalog() -> dict:
    return {
        "projects": [
            {
                "id": p["id"],
                "title": p["title"],
                "emoji": p["emoji"],
                "tagline": p["tagline"],
                "duration_days": p["duration_days"],
                "subjects": p["subjects"],
                "synopsis": p["synopsis"],
                "step_count": len(p["steps"]),
            }
            for p in PROJECT_ADVENTURES
        ],
        "note": (
            "Projects span multiple days and subjects — complete up to "
            f"{MAX_STEPS_PER_DAY} steps per day to build real-world stamina."
        ),
    }


def default_learner_projects() -> dict:
    return {"active_project_id": None, "projects": {}}


def _today_key() -> str:
    return date.today().isoformat()


def _project_def(project_id: str) -> Optional[dict]:
    return PROJECT_BY_ID.get(project_id)


def _step_def(project: dict, step_id: str) -> Optional[dict]:
    return next((s for s in project.get("steps", []) if s["id"] == step_id), None)


def start_project(state: dict, project_id: str) -> tuple[dict, dict]:
    project = _project_def(project_id)
    if not project:
        raise ValueError("Unknown project")
    out = copy.deepcopy(state) if state else default_learner_projects()
    if project_id not in out["projects"]:
        first_step = project["steps"][0]["id"]
        out["projects"][project_id] = {
            "started_at": time.time(),
            "completed_steps": [],
            "current_step_id": first_step,
            "step_data": {},
            "status": "in_progress",
            "completed_at": None,
            "daily_log": {},
        }
    out["active_project_id"] = project_id
    return out, project


def steps_with_status(project: dict, run: dict) -> list[dict]:
    completed = set(run.get("completed_steps") or [])
    current = run.get("current_step_id")
    result = []
    for step in project["steps"]:
        sid = step["id"]
        if sid in completed:
            status = "completed"
        elif sid == current:
            status = "active"
        elif not completed and sid == project["steps"][0]["id"]:
            status = "active"
        else:
            prev_done = all(
                s["id"] in completed
                for s in project["steps"]
                if s["order"] < step["order"]
            )
            status = "available" if prev_done else "locked"
        result.append({
            "id": sid,
            "order": step["order"],
            "title": step["title"],
            "emoji": step["emoji"],
            "suggested_day": step.get("suggested_day"),
            "subjects": step.get("subjects", []),
            "activity": step.get("activity"),
            "status": status,
        })
    return result


def step_for_client(project: dict, step: dict, run: dict) -> dict:
    """Step payload without answer keys for MCQ/numeric."""
    payload = {
        "id": step["id"],
        "order": step["order"],
        "title": step["title"],
        "emoji": step["emoji"],
        "suggested_day": step.get("suggested_day"),
        "subjects": step.get("subjects", []),
        "activity": step.get("activity"),
        "brief": step.get("brief", ""),
        "objectives": step.get("objectives", []),
        "interaction": step.get("interaction", "reflect"),
        "xp": step.get("xp", 20),
    }
    if step.get("interaction") == "choice" or step.get("interaction") == "dilemma":
        payload["choices"] = [
            {k: c[k] for k in ("id", "label", "emoji") if k in c}
            for c in (step.get("choices") or [])
        ]
    if step.get("interaction") == "design":
        payload["design_options"] = step.get("design_options", [])
        payload["min_words"] = step.get("min_words", 15)
    if step.get("interaction") in ("numeric", "calculate"):
        payload["problem"] = step.get("problem", "")
    if step.get("interaction") == "mcq":
        payload["question"] = step.get("question", "")
        payload["options"] = step.get("options", [])
    for key in ("launch", "reflect"):
        if step.get("interaction") == key or step.get("interaction") in ("launch", "reflect"):
            payload["min_words"] = step.get("min_words", 15)
    return payload


def _check_daily_limit(run: dict) -> Optional[str]:
    log = run.get("daily_log") or {}
    today = _today_key()
    if log.get(today, 0) >= MAX_STEPS_PER_DAY:
        return (
            f"Amazing focus today! You've finished {MAX_STEPS_PER_DAY} project steps. "
            "Come back tomorrow to continue your mission. 🌙"
        )
    return None


def _normalize_answer(val: Any) -> str:
    return str(val or "").strip().lower().replace(",", "")


def validate_step_submission(step: dict, payload: dict) -> tuple[bool, str, dict]:
    """Returns (ok, message, extras)."""
    interaction = step.get("interaction", "reflect")
    extras: dict[str, Any] = {}

    if interaction in ("choice", "dilemma"):
        choice_id = (payload.get("choice_id") or "").strip()
        valid = {c["id"] for c in (step.get("choices") or [])}
        if choice_id not in valid:
            return False, "Pick one option to continue.", extras
        choice = next(c for c in step["choices"] if c["id"] == choice_id)
        extras["choice_label"] = choice.get("label", "")
        if choice.get("consequence"):
            extras["consequence"] = choice["consequence"]
        return True, "Choice recorded!", extras

    if interaction in ("numeric", "calculate"):
        ans = _normalize_answer(payload.get("answer"))
        acceptable = {_normalize_answer(a) for a in (step.get("acceptable_answers") or [])}
        acceptable.add(_normalize_answer(step.get("correct_answer", "")))
        if ans not in acceptable:
            hint = step.get("explanation", "Try estimating step by step.")
            return False, f"Not quite — {hint}", extras
        extras["explanation"] = step.get("explanation", "")
        return True, "Correct calculation! 🎯", extras

    if interaction == "mcq":
        try:
            idx = int(payload.get("answer_index"))
        except (TypeError, ValueError):
            return False, "Select an answer.", extras
        if idx != step.get("correct_index"):
            return False, step.get("explanation", "Review the problem and try again."), extras
        extras["explanation"] = step.get("explanation", "")
        return True, "Engineering puzzle solved! 🧩", extras

    if interaction == "design":
        text = (payload.get("text") or "").strip()
        design_id = (payload.get("design_id") or "").strip()
        min_w = step.get("min_words", 15)
        if len(text.split()) < min_w:
            return False, f"Add a bit more detail — at least {min_w} words describing your design.", extras
        if step.get("design_options") and not design_id:
            return False, "Pick a design priority too.", extras
        extras["word_count"] = len(text.split())
        return True, "Blueprint saved! 🛠️", extras

    if interaction in ("launch", "reflect"):
        text = (payload.get("text") or "").strip()
        min_w = step.get("min_words", 15)
        if len(text.split()) < min_w:
            return False, f"Share a bit more — at least {min_w} words.", extras
        extras["word_count"] = len(text.split())
        msg = "Launch log saved! 🚀" if interaction == "launch" else "Mission analysis complete! 📊"
        return True, msg, extras

    return True, "Step complete!", extras


def complete_step(
    state: dict,
    project_id: str,
    step_id: str,
    payload: dict,
) -> tuple[dict, dict]:
    project = _project_def(project_id)
    if not project:
        raise ValueError("Unknown project")
    run = (state.get("projects") or {}).get(project_id)
    if not run:
        raise ValueError("Project not started")

    limit_msg = _check_daily_limit(run)
    if limit_msg:
        raise ValueError(limit_msg)

    step = _step_def(project, step_id)
    if not step:
        raise ValueError("Unknown step")

    if step_id in (run.get("completed_steps") or []):
        raise ValueError("Step already completed")

    statuses = {s["id"]: s["status"] for s in steps_with_status(project, run)}
    if statuses.get(step_id) not in ("active", "available"):
        raise ValueError("Complete earlier steps first")

    ok, message, extras = validate_step_submission(step, payload)
    if not ok:
        raise ValueError(message)

    out = copy.deepcopy(state)
    run = out["projects"][project_id]
    run["completed_steps"] = list(run.get("completed_steps") or []) + [step_id]
    run["step_data"][step_id] = {**payload, **extras}
    today = _today_key()
    log = dict(run.get("daily_log") or {})
    log[today] = log.get(today, 0) + 1
    run["daily_log"] = log

    next_step = next(
        (s for s in project["steps"] if s["id"] not in run["completed_steps"]),
        None,
    )
    if next_step:
        run["current_step_id"] = next_step["id"]
    else:
        run["status"] = "complete"
        run["completed_at"] = time.time()
        run["current_step_id"] = None

    result = {
        "ok": True,
        "message": message,
        "xp": step.get("xp", 20),
        "extras": extras,
        "step_complete": True,
        "project_complete": run["status"] == "complete",
        "next_step_id": run.get("current_step_id"),
    }
    return out, result


def build_project_view(state: dict, project_id: Optional[str] = None) -> dict:
    pid = project_id or (state or {}).get("active_project_id")
    if not pid:
        return {"active": None, "projects": []}

    project = _project_def(pid)
    if not project:
        return {"active": None, "projects": []}

    run = (state.get("projects") or {}).get(pid) or {}
    cat_item = next((p for p in project_catalog()["projects"] if p["id"] == pid), None)
    if not run:
        return {
            "active": {
                "project": cat_item,
                "project_id": pid,
                "not_started": True,
            },
        }

    current_step = None
    if run.get("current_step_id"):
        step = _step_def(project, run["current_step_id"])
        if step:
            current_step = step_for_client(project, step, run)

    completed = len(run.get("completed_steps") or [])
    total = len(project["steps"])
    return {
        "active": {
            "project_id": pid,
            "title": project["title"],
            "emoji": project["emoji"],
            "synopsis": project["synopsis"],
            "subjects": project["subjects"],
            "status": run.get("status", "in_progress"),
            "progress_pct": round(100 * completed / total) if total else 0,
            "completed_steps": completed,
            "total_steps": total,
            "steps": steps_with_status(project, run),
            "current_step": current_step,
            "step_data": run.get("step_data", {}),
            "daily_steps_today": (run.get("daily_log") or {}).get(_today_key(), 0),
            "daily_limit": MAX_STEPS_PER_DAY,
        },
    }


def project_prompt_block(project_id: str, step_id: str) -> str:
    project = _project_def(project_id)
    step = _step_def(project, step_id) if project else None
    if not project or not step:
        return ""
    subjects = ", ".join(step.get("subjects", []))
    return (
        f"\nPROJECT MISSION ({project['title']} — Step {step['order']}: {step['title']}): "
        f"Teach across {subjects}. {step.get('brief', '')}"
    )
