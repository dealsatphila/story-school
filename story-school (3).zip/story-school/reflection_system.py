"""Reflection system — metacognition prompts after adventures and activities."""

from __future__ import annotations

import json
import time
import uuid
from typing import Any, Optional

REFLECTION_OPTIONS: list[dict[str, str]] = [
    {
        "id": "knew_already",
        "label": "I knew this already",
        "emoji": "✅",
        "description": "This felt familiar — I connected it to what I already know.",
    },
    {
        "id": "learned_new",
        "label": "I learned something new",
        "emoji": "💡",
        "description": "I discovered a fresh idea or fact.",
    },
    {
        "id": "want_more",
        "label": "I want to learn more",
        "emoji": "🔎",
        "description": "This sparked curiosity — I want to explore further.",
    },
    {
        "id": "difficult",
        "label": "It was difficult",
        "emoji": "🌱",
        "description": "Some parts were tricky — and that's okay.",
    },
    {
        "id": "want_challenge",
        "label": "I want another challenge",
        "emoji": "⚡",
        "description": "I'm ready for something harder!",
    },
]

ACTIVITY_PROMPTS: dict[str, dict[str, str]] = {
    "adventure": {
        "emoji": "🗺️",
        "question": "What was the most interesting thing you learned?",
        "subtitle": "Thinking about your learning helps it stick — there are no wrong answers.",
    },
    "story": {
        "emoji": "📖",
        "question": "What stood out most from this story?",
        "subtitle": "Your reflection helps Finn understand how you learn best.",
    },
    "story_world": {
        "emoji": "🌍",
        "question": "What did you discover in this Story World?",
        "subtitle": "Metacognition means thinking about your own thinking — great job pausing to reflect!",
    },
    "quiz": {
        "emoji": "🎯",
        "question": "How did this quiz feel?",
        "subtitle": "Honest reflections help us match challenges to you.",
    },
}

OPTION_IDS = {o["id"] for o in REFLECTION_OPTIONS}


def reflection_catalog() -> dict:
    return {
        "name": "Reflection",
        "emoji": "🪞",
        "description": (
            "Gentle end-of-activity prompts that build metacognition — "
            "thinking about what you learned, without tests or grades."
        ),
        "principles": [
            "No wrong answers — every reflection is valuable.",
            "Optional 'tell me in your own words' for deeper thinking.",
            "Finn responds with warmth, never judgment.",
            "Reflections inform pacing and challenges — not surveillance.",
        ],
        "options": REFLECTION_OPTIONS,
        "activities": ACTIVITY_PROMPTS,
        "skills": ["metacognition", "self-awareness", "goal-setting"],
    }


def validate_option(option_id: str) -> dict:
    oid = (option_id or "").strip()
    for opt in REFLECTION_OPTIONS:
        if opt["id"] == oid:
            return opt
    raise ValueError(f"Invalid reflection option: {option_id}")


def finn_reflection_reply(
    option: dict,
    *,
    child_name: str = "",
    topic: str = "",
    own_words: str = "",
) -> dict:
    """Warm Finn response + optional next-step hint (not a grade)."""
    name = child_name.strip() or "friend"
    topic_bit = f" about {topic}" if topic.strip() else ""
    words = (own_words or "").strip()
    oid = option["id"]

    replies = {
        "knew_already": (
            f"Nice, {name}! 🦊 Connecting new adventures to what you already know "
            f"is a superpower — that's how experts think{topic_bit}."
        ),
        "learned_new": (
            f"That's wonderful, {name}! 💡 Noticing what you learned{topic_bit} "
            f"helps your brain file it away for later."
        ),
        "want_more": (
            f"I love that curiosity, {name}! 🔎 Want to tap a wonder-spot or "
            f"explore a 'Tell me more' path{topic_bit}? Follow what fascinates you."
        ),
        "difficult": (
            f"Thank you for being honest, {name}. 🌱 Tricky parts mean your brain "
            f"is growing{topic_bit} — we can take it step by step, no rush."
        ),
        "want_challenge": (
            f"You're brave, {name}! ⚡ Ready for more? Try the quiz, a harder topic, "
            f"or replay the adventure with a twist{topic_bit}."
        ),
    }
    message = replies.get(oid, f"Thanks for reflecting, {name}! 🦊")

    next_step = None
    if oid == "want_more":
        next_step = {"action": "know_more", "label": "Explore curiosity paths", "emoji": "🔎"}
    elif oid == "want_challenge":
        next_step = {"action": "quiz", "label": "Take the quiz", "emoji": "🎯"}
    elif oid == "difficult":
        next_step = {"action": "review", "label": "Review with flashcards", "emoji": "🧠"}

    if words:
        snippet = words[:120] + ("…" if len(words) > 120 else "")
        message += (
            f"\n\nI heard you say: \"{snippet}\" — "
            f"putting ideas in your own words is one of the best ways to learn."
        )

    return {
        "message": message,
        "next_step": next_step,
        "option_id": oid,
    }


def own_words_prompt(
    grade: int,
    activity_type: str,
    topic: str,
    option_id: str,
    own_words: str,
    child_name: str = "",
) -> str:
    name = child_name.strip() or "the learner"
    return f"""You are Finn the Fox 🦊 responding to a Grade {grade} child's reflection after a {activity_type}.

They chose: {option_id}
Topic context: {topic or 'general learning'}
Their own words: {own_words.strip()}

Write 2–3 warm sentences that:
1. Acknowledge their specific idea (quote or echo a phrase they used).
2. Celebrate metacognition — thinking about their learning.
3. Offer one gentle next step if appropriate — never assign homework or shame.

Keep it under 80 words. No grades, no scores. Sign off as Finn 🦊 sometimes."""


def init_reflection_tables(conn) -> None:
    conn.execute("""
        CREATE TABLE IF NOT EXISTS learner_reflections (
            id TEXT PRIMARY KEY,
            learner_id TEXT NOT NULL,
            activity_type TEXT NOT NULL,
            grade INTEGER,
            subject TEXT,
            topic TEXT,
            option_id TEXT NOT NULL,
            own_words TEXT,
            finn_reply TEXT,
            meta_json TEXT,
            created_at REAL
        )
    """)
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_reflections_learner "
        "ON learner_reflections(learner_id, created_at DESC)"
    )


def save_reflection(
    conn,
    learner_id: str,
    activity_type: str,
    option_id: str,
    *,
    grade: int = 0,
    subject: str = "",
    topic: str = "",
    own_words: str = "",
    finn_reply: str = "",
    meta: Optional[dict] = None,
) -> str:
    rid = uuid.uuid4().hex[:12]
    conn.execute(
        """
        INSERT INTO learner_reflections
            (id, learner_id, activity_type, grade, subject, topic,
             option_id, own_words, finn_reply, meta_json, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            rid, learner_id.strip(), activity_type, grade, subject, topic,
            option_id, own_words.strip(), finn_reply,
            json.dumps(meta or {}), time.time(),
        ),
    )
    return rid


def list_reflections(conn, learner_id: str, limit: int = 20) -> list[dict]:
    rows = conn.execute(
        """
        SELECT id, activity_type, grade, subject, topic, option_id,
               own_words, created_at
        FROM learner_reflections
        WHERE learner_id = ?
        ORDER BY created_at DESC
        LIMIT ?
        """,
        (learner_id.strip(), limit),
    ).fetchall()
    return [
        {
            "id": r["id"],
            "activity_type": r["activity_type"],
            "grade": r["grade"],
            "subject": r["subject"],
            "topic": r["topic"],
            "option_id": r["option_id"],
            "has_own_words": bool((r["own_words"] or "").strip()),
            "created_at": r["created_at"],
        }
        for r in rows
    ]
