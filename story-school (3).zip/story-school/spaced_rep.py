"""Spaced repetition scheduling — 1 / 3 / 7 / 14 day review intervals."""

from __future__ import annotations

import hashlib
import json
import time
from typing import Optional

# Days until next review after each successful recall (level indexes into this list)
INTERVALS_DAYS = [1, 3, 7, 14]


def make_item_key(item_type: str, grade: int, subject: str, topic: str, identifier: str) -> str:
    return f"{item_type}|{grade}|{subject}|{topic}|{identifier}"


def question_identifier(question: str) -> str:
    return hashlib.sha256(question.strip().encode()).hexdigest()[:16]


def schedule_after_result(level: int, correct: bool) -> tuple[int, float]:
    """Return (new_level, due_at_unix). Wrong answers reset to 1-day interval."""
    now = time.time()
    if correct:
        new_level = min(level + 1, len(INTERVALS_DAYS) - 1)
        days = INTERVALS_DAYS[new_level]
        return new_level, now + days * 86400
    return 0, now + INTERVALS_DAYS[0] * 86400


def item_to_dict(row) -> dict:
    extra = {}
    if row["extra_json"]:
        try:
            extra = json.loads(row["extra_json"])
        except json.JSONDecodeError:
            extra = {}
    return {
        "item_key": row["item_key"],
        "item_type": row["item_type"],
        "grade": row["grade"],
        "subject": row["subject"],
        "topic": row["topic"],
        "prompt": row["prompt"],
        "answer": row["answer"],
        "level": row["level"],
        "due_at": row["due_at"],
        "last_result": row["last_result"],
        "extra": extra,
        "interval_days": INTERVALS_DAYS[min(row["level"], len(INTERVALS_DAYS) - 1)],
    }


def upsert_spaced_item(
    conn,
    learner_id: str,
    item_key: str,
    item_type: str,
    grade: int,
    subject: str,
    topic: str,
    prompt: str,
    answer: str,
    correct: bool,
    extra: Optional[dict] = None,
) -> dict:
    now = time.time()
    row = conn.execute(
        "SELECT level FROM spaced_items WHERE learner_id = ? AND item_key = ?",
        (learner_id, item_key),
    ).fetchone()
    level = int(row["level"]) if row else 0
    new_level, due_at = schedule_after_result(level, correct)

    conn.execute(
        """
        INSERT INTO spaced_items (
            learner_id, item_key, item_type, grade, subject, topic,
            prompt, answer, extra_json, level, due_at, last_result, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(learner_id, item_key) DO UPDATE SET
            prompt = excluded.prompt,
            answer = excluded.answer,
            extra_json = excluded.extra_json,
            level = excluded.level,
            due_at = excluded.due_at,
            last_result = excluded.last_result,
            updated_at = excluded.updated_at
        """,
        (
            learner_id, item_key, item_type, grade, subject, topic,
            prompt, answer, json.dumps(extra or {}), new_level, due_at,
            "correct" if correct else "wrong", now,
        ),
    )
    return {
        "item_key": item_key,
        "level": new_level,
        "due_at": due_at,
        "interval_days": INTERVALS_DAYS[min(new_level, len(INTERVALS_DAYS) - 1)],
        "last_result": "correct" if correct else "wrong",
    }


def list_due_items(conn, learner_id: str, limit: int = 50) -> list[dict]:
    now = time.time()
    rows = conn.execute(
        """
        SELECT item_key, item_type, grade, subject, topic, prompt, answer,
               extra_json, level, due_at, last_result
        FROM spaced_items
        WHERE learner_id = ? AND due_at <= ?
        ORDER BY due_at ASC
        LIMIT ?
        """,
        (learner_id, now, limit),
    ).fetchall()
    return [item_to_dict(r) for r in rows]


def count_due_items(conn, learner_id: str) -> int:
    now = time.time()
    row = conn.execute(
        "SELECT COUNT(*) AS c FROM spaced_items WHERE learner_id = ? AND due_at <= ?",
        (learner_id, now),
    ).fetchone()
    return int(row["c"]) if row else 0


def list_all_items(conn, learner_id: str, limit: int = 100) -> list[dict]:
    rows = conn.execute(
        """
        SELECT item_key, item_type, grade, subject, topic, prompt, answer,
               extra_json, level, due_at, last_result
        FROM spaced_items
        WHERE learner_id = ?
        ORDER BY due_at ASC
        LIMIT ?
        """,
        (learner_id, limit),
    ).fetchall()
    return [item_to_dict(r) for r in rows]
