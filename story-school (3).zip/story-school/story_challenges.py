"""Story World learning challenge types, validation, and answer checking."""

from __future__ import annotations

import copy
import random
import re
from typing import Any, Optional

CHALLENGE_CATEGORIES = ("mathematics", "language", "science", "reasoning")

INTERACTION_TYPES = frozenset({
    "none", "mcq", "numeric", "text", "fill_blank",
    "matching", "ordering", "drag_drop", "memory",
})

# activity_type -> category, interaction mode, display label
ACTIVITY_CATALOG: dict[str, dict[str, str]] = {
    # Mathematics
    "mcq": {"category": "mathematics", "interaction": "mcq", "label": "Multiple Choice"},
    "fill_blank": {"category": "mathematics", "interaction": "fill_blank", "label": "Fill in the Blank"},
    "drag_drop": {"category": "mathematics", "interaction": "drag_drop", "label": "Drag and Drop"},
    "number_order": {"category": "mathematics", "interaction": "ordering", "label": "Number Ordering"},
    "matching": {"category": "mathematics", "interaction": "matching", "label": "Matching"},
    "mental_math": {"category": "mathematics", "interaction": "numeric", "label": "Mental Math"},
    "word_problem": {"category": "mathematics", "interaction": "numeric", "label": "Word Problem"},
    "pattern_recognition": {"category": "mathematics", "interaction": "mcq", "label": "Pattern Recognition"},
    "geometry_puzzle": {"category": "mathematics", "interaction": "mcq", "label": "Geometry Puzzle"},
    "measurement": {"category": "mathematics", "interaction": "numeric", "label": "Measurement"},
    # Language
    "vocabulary": {"category": "language", "interaction": "mcq", "label": "Vocabulary"},
    "spelling": {"category": "language", "interaction": "fill_blank", "label": "Spelling"},
    "grammar": {"category": "language", "interaction": "mcq", "label": "Grammar"},
    "sentence_building": {"category": "language", "interaction": "ordering", "label": "Sentence Building"},
    "reading_comprehension": {"category": "language", "interaction": "mcq", "label": "Reading Comprehension"},
    "word_matching": {"category": "language", "interaction": "matching", "label": "Word Matching"},
    "synonyms": {"category": "language", "interaction": "matching", "label": "Synonyms"},
    "antonyms": {"category": "language", "interaction": "matching", "label": "Antonyms"},
    "story_sequencing": {"category": "language", "interaction": "ordering", "label": "Story Sequencing"},
    "pronunciation": {"category": "language", "interaction": "text", "label": "Pronunciation"},
    # Science
    "classification": {"category": "science", "interaction": "drag_drop", "label": "Classification"},
    "cause_effect": {"category": "science", "interaction": "matching", "label": "Cause & Effect"},
    "prediction": {"category": "science", "interaction": "mcq", "label": "Prediction"},
    "observation": {"category": "science", "interaction": "mcq", "label": "Observation"},
    "experiment": {"category": "science", "interaction": "ordering", "label": "Experiment Steps"},
    "diagram_labeling": {"category": "science", "interaction": "drag_drop", "label": "Diagram Labeling"},
    "scientific_reasoning": {"category": "science", "interaction": "text", "label": "Scientific Reasoning"},
    "hypothesis": {"category": "science", "interaction": "mcq", "label": "Hypothesis"},
    # General reasoning
    "logic_puzzle": {"category": "reasoning", "interaction": "mcq", "label": "Logic Puzzle"},
    "pattern_puzzle": {"category": "reasoning", "interaction": "mcq", "label": "Pattern Puzzle"},
    "memory_game": {"category": "reasoning", "interaction": "memory", "label": "Memory Game"},
    "deduction": {"category": "reasoning", "interaction": "mcq", "label": "Deduction"},
    "spatial_reasoning": {"category": "reasoning", "interaction": "ordering", "label": "Spatial Reasoning"},
    "problem_solving": {"category": "reasoning", "interaction": "text", "label": "Problem Solving"},
}

ACTIVITY_TYPE_NAMES = sorted(ACTIVITY_CATALOG.keys())

CATEGORY_LABELS = {
    "mathematics": "Mathematics",
    "language": "Language",
    "science": "Science",
    "reasoning": "Reasoning",
}

CATEGORY_EMOJI = {
    "mathematics": "🔢",
    "language": "📖",
    "science": "🔬",
    "reasoning": "🧩",
}

# Legacy type -> default activity
_LEGACY_TYPE_ACTIVITY = {
    "mcq": "mcq",
    "numeric": "mental_math",
    "text": "problem_solving",
}


def normalize_numeric_answer(text: str) -> str:
    return re.sub(r"\s+", "", str(text or "").strip().lower().replace(",", ""))


def get_interaction(challenge: dict) -> str:
    if (challenge.get("type") or "none").lower() == "none":
        return "none"
    at = (challenge.get("activity_type") or "").lower()
    if at in ACTIVITY_CATALOG:
        return ACTIVITY_CATALOG[at]["interaction"]
    ctype = (challenge.get("type") or "none").lower()
    if ctype in INTERACTION_TYPES:
        return ctype
    return "none"


def get_category(challenge: dict) -> str:
    at = (challenge.get("activity_type") or "").lower()
    if at in ACTIVITY_CATALOG:
        return ACTIVITY_CATALOG[at]["category"]
    cat = (challenge.get("category") or "").lower()
    if cat in CHALLENGE_CATEGORIES:
        return cat
    ctype = (challenge.get("type") or "").lower()
    if ctype == "numeric":
        return "mathematics"
    if ctype == "text":
        return "language"
    return "reasoning"


def get_activity_label(challenge: dict) -> str:
    at = (challenge.get("activity_type") or "").lower()
    if at in ACTIVITY_CATALOG:
        return ACTIVITY_CATALOG[at]["label"]
    ctype = (challenge.get("type") or "").lower()
    return _LEGACY_TYPE_ACTIVITY.get(ctype, ctype).replace("_", " ").title()


def normalize_challenge(challenge: dict) -> dict:
    """Fill activity_type/category from legacy type fields."""
    ch = copy.deepcopy(challenge or {})
    ctype = (ch.get("type") or "none").lower()
    if ctype not in INTERACTION_TYPES:
        ch["type"] = "none"
        ctype = "none"

    for key, default in (
        ("pairs", []),
        ("order_items", []),
        ("correct_order", []),
        ("drop_zones", []),
        ("drop_items", []),
        ("correct_placements", []),
        ("memory_pairs", []),
        ("blanks", []),
        ("options", ["", "", "", ""]),
        ("acceptable_answers", []),
        ("keywords", []),
        ("progressive_hints", []),
    ):
        if ch.get(key) is None:
            ch[key] = default

    if ctype == "none":
        if not ch.get("activity_type"):
            ch["activity_type"] = "mcq"
        if not ch.get("category"):
            ch["category"] = "reasoning"
        return ch

    if not ch.get("activity_type"):
        ch["activity_type"] = _LEGACY_TYPE_ACTIVITY.get(ctype, "problem_solving")

    if not ch.get("category"):
        ch["category"] = get_category(ch)

    interaction = get_interaction(ch)
    if interaction != "none" and ctype != interaction:
        ch["type"] = interaction

    return ch


def activity_catalog_for_api() -> dict:
    grouped: dict[str, list[dict]] = {c: [] for c in CHALLENGE_CATEGORIES}
    for key, meta in ACTIVITY_CATALOG.items():
        grouped[meta["category"]].append({
            "id": key,
            "label": meta["label"],
            "interaction": meta["interaction"],
        })
    return {
        "categories": [
            {"id": c, "label": CATEGORY_LABELS[c], "emoji": CATEGORY_EMOJI[c], "activities": grouped[c]}
            for c in CHALLENGE_CATEGORIES
        ],
        "interactions": sorted(INTERACTION_TYPES - {"none"}),
    }


def _check_mcq(challenge: dict, user_answer: Any) -> bool:
    try:
        return int(user_answer) == int(challenge.get("correct_index", -1))
    except (TypeError, ValueError):
        return False


def _check_numeric(challenge: dict, user_answer: Any) -> bool:
    correct = normalize_numeric_answer(challenge.get("correct_answer", ""))
    given = normalize_numeric_answer(str(user_answer))
    alts = [normalize_numeric_answer(a) for a in challenge.get("acceptable_answers", [])]
    return given == correct or given in alts


def _check_text(challenge: dict, user_answer: Any) -> bool:
    text = str(user_answer or "").strip().lower()
    if len(text) < 2:
        return False
    keywords = [k.strip().lower() for k in challenge.get("keywords", []) if k.strip()]
    if keywords:
        hits = sum(1 for k in keywords if k in text)
        return hits >= max(1, int(len(keywords) * 0.5))
    model = (challenge.get("correct_answer") or "").strip().lower()
    return bool(model and (model in text or text in model))


def _check_fill_blank(challenge: dict, user_answer: Any) -> bool:
    blanks = challenge.get("blanks") or []
    if blanks:
        if not isinstance(user_answer, dict):
            return False
        for blank in blanks:
            bid = blank.get("id") or ""
            expected = normalize_numeric_answer(blank.get("answer", ""))
            given = normalize_numeric_answer(str(user_answer.get(bid, "")))
            alts = [normalize_numeric_answer(a) for a in blank.get("acceptable_answers", [])]
            if given != expected and given not in alts:
                return False
        return True
    return _check_numeric(challenge, user_answer) or _check_text(challenge, user_answer)


def _check_matching(challenge: dict, user_answer: Any) -> bool:
    pairs = challenge.get("pairs") or []
    if not pairs or not isinstance(user_answer, dict):
        return False
    matches = user_answer.get("matches") or user_answer
    if not isinstance(matches, dict):
        return False
    for i, pair in enumerate(pairs):
        left_key = str(i)
        expected = (pair.get("right") or "").strip().lower()
        given = str(matches.get(left_key, "")).strip().lower()
        if given != expected:
            return False
    return True


def _check_ordering(challenge: dict, user_answer: Any) -> bool:
    correct = challenge.get("correct_order") or []
    if not correct or not isinstance(user_answer, list):
        return False
    try:
        user_order = [int(x) for x in user_answer]
    except (TypeError, ValueError):
        return False
    return user_order == [int(x) for x in correct]


def _check_drag_drop(challenge: dict, user_answer: Any) -> bool:
    expected = challenge.get("correct_placements") or []
    if not expected or not isinstance(user_answer, dict):
        return False
    for placement in expected:
        item_id = placement.get("item_id", "")
        zone_id = placement.get("zone_id", "")
        if str(user_answer.get(item_id, "")) != str(zone_id):
            return False
    return True


def _check_memory(challenge: dict, user_answer: Any) -> bool:
    pairs = challenge.get("memory_pairs") or []
    if not pairs:
        return False
    if isinstance(user_answer, dict):
        matched = user_answer.get("matched_ids") or []
    elif isinstance(user_answer, list):
        matched = user_answer
    else:
        return False
    expected_ids = {p.get("id") for p in pairs if p.get("id")}
    return expected_ids and set(matched) == expected_ids


def check_challenge_answer(challenge: dict, user_answer: Any) -> bool:
    ch = normalize_challenge(challenge)
    interaction = get_interaction(ch)
    if interaction == "none":
        return True
    if interaction == "mcq":
        return _check_mcq(ch, user_answer)
    if interaction == "numeric":
        return _check_numeric(ch, user_answer)
    if interaction == "text":
        return _check_text(ch, user_answer)
    if interaction == "fill_blank":
        return _check_fill_blank(ch, user_answer)
    if interaction == "matching":
        return _check_matching(ch, user_answer)
    if interaction == "ordering":
        return _check_ordering(ch, user_answer)
    if interaction == "drag_drop":
        return _check_drag_drop(ch, user_answer)
    if interaction == "memory":
        return _check_memory(ch, user_answer)
    return False


def _shuffle_deterministic(items: list, seed: str) -> list:
    out = list(items)
    rng = random.Random(seed)
    rng.shuffle(out)
    return out


def prepare_challenge_for_client(challenge: dict, scene_id: str = "") -> dict:
    """Strip answers and shape payload for interactive UI."""
    ch = normalize_challenge(challenge)
    interaction = get_interaction(ch)
    out = copy.deepcopy(ch)

    out.pop("correct_answer", None)
    out.pop("acceptable_answers", None)
    out.pop("keywords", None)
    out.pop("correct_order", None)
    out.pop("correct_placements", None)
    out.pop("pairs", None)
    out.pop("progressive_hints", None)

    if interaction == "mcq":
        out.pop("correct_index", None)
    elif interaction == "matching":
        pairs = ch.get("pairs") or []
        rights = [p.get("right", "") for p in pairs]
        out["match_left"] = [p.get("left", "") for p in pairs]
        out["match_right"] = _shuffle_deterministic(rights, f"{scene_id}:match")
    elif interaction == "ordering":
        items = ch.get("order_items") or []
        out["order_items"] = _shuffle_deterministic(items, f"{scene_id}:order")
    elif interaction == "drag_drop":
        zones = ch.get("drop_zones") or []
        items = ch.get("drop_items") or []
        out["drop_zones"] = zones
        out["drop_items"] = _shuffle_deterministic(items, f"{scene_id}:drop")
    elif interaction == "memory":
        cards = []
        for pair in ch.get("memory_pairs") or []:
            pid = pair.get("id", "")
            content = pair.get("content", "")
            emoji = pair.get("emoji", "")
            cards.append({"card_id": f"{pid}_a", "pair_id": pid, "face": content, "emoji": emoji})
            cards.append({"card_id": f"{pid}_b", "pair_id": pid, "face": content, "emoji": emoji})
        out["memory_cards"] = _shuffle_deterministic(cards, f"{scene_id}:mem")
        out.pop("memory_pairs", None)
    elif interaction == "fill_blank":
        for blank in out.get("blanks") or []:
            blank.pop("answer", None)
            blank.pop("acceptable_answers", None)

    return out


def validate_challenge_fields(challenge: dict, scene_id: str) -> None:
    ch = normalize_challenge(challenge)
    interaction = get_interaction(ch)
    if interaction == "none":
        return
    if not (ch.get("question") or "").strip():
        raise ValueError(f"Scene {scene_id} challenge needs a question")
    if not (ch.get("success_narrative") or "").strip():
        raise ValueError(f"Scene {scene_id} challenge needs success_narrative")
    if interaction == "mcq" and int(ch.get("correct_index", -1)) < 0:
        raise ValueError(f"Scene {scene_id} mcq needs correct_index")
    if interaction == "numeric" and not (ch.get("correct_answer") or "").strip():
        raise ValueError(f"Scene {scene_id} numeric challenge needs correct_answer")
    if interaction == "matching" and len(ch.get("pairs") or []) < 2:
        raise ValueError(f"Scene {scene_id} matching needs at least 2 pairs")
    if interaction == "ordering" and len(ch.get("order_items") or []) < 2:
        raise ValueError(f"Scene {scene_id} ordering needs at least 2 order_items")
    if interaction == "drag_drop":
        if len(ch.get("drop_zones") or []) < 1 or len(ch.get("drop_items") or []) < 1:
            raise ValueError(f"Scene {scene_id} drag_drop needs zones and items")
    if interaction == "memory" and len(ch.get("memory_pairs") or []) < 2:
        raise ValueError(f"Scene {scene_id} memory needs at least 2 memory_pairs")
