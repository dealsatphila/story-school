"""Interactive Story World — chapters, scenes, embedded challenges, and consequences."""

from __future__ import annotations

import copy
import json
import re
import time
import uuid
from typing import Any, Optional

from choices_consequences import build_choice_outcome, normalize_choice, normalize_dilemma, strip_scene_choices_for_client
from story_challenges import (
    check_challenge_answer,
    get_interaction,
    normalize_challenge,
    prepare_challenge_for_client,
    validate_challenge_fields,
)

CHALLENGE_TYPES = frozenset({
    "none", "mcq", "numeric", "text", "fill_blank",
    "matching", "ordering", "drag_drop", "memory",
})


def new_world_id() -> str:
    return uuid.uuid4().hex


def _scene_list(world: dict) -> list[dict]:
    scenes = []
    for ch in world.get("chapters", []):
        for sc in ch.get("scenes", []):
            scenes.append(sc)
    return scenes


def enrich_scene_for_playback(scene: dict, world: dict) -> dict:
    """Fill dialogue/hotspots/theme for older worlds or client playback."""
    sc = copy.deepcopy(scene)
    loc_id = sc.get("location_id", "")
    loc = next((l for l in world.get("locations", []) if l.get("id") == loc_id), None)

    if not sc.get("background_theme"):
        name = (loc.get("name") or "").lower() if loc else ""
        if "forest" in name or "wood" in name:
            sc["background_theme"] = "forest"
        elif "cave" in name:
            sc["background_theme"] = "cave"
        elif "mountain" in name:
            sc["background_theme"] = "mountain"
        elif "river" in name or "water" in name:
            sc["background_theme"] = "river"
        else:
            sc["background_theme"] = "village"

    if not sc.get("dialogue"):
        lines = [s.strip() for s in re.split(r'(?<=[.!?])\s+', sc.get("narrative", "")) if s.strip()]
        chars = sc.get("character_ids") or []
        sc["dialogue"] = []
        for i, line in enumerate(lines[:5] or [sc.get("narrative", "")]):
            cid = chars[i % len(chars)] if chars else "narrator"
            if i == 0 and chars:
                cid = "narrator"
            sc["dialogue"].append({"character_id": cid, "line": line, "mood": "neutral"})

    if sc.get("hotspots") is None:
        sc["hotspots"] = []
    if not sc["hotspots"]:
        objs = [o for o in world.get("objects", []) if o.get("location_id") == loc_id]
        positions = [(25, 55), (55, 40), (75, 65)]
        for i, obj in enumerate(objs[:3]):
            x, y = positions[i % len(positions)]
            sc["hotspots"].append({
                "object_id": obj.get("id", f"obj{i}"),
                "label": obj.get("name", "Object"),
                "emoji": obj.get("emoji", "✨"),
                "x_percent": x,
                "y_percent": y,
                "discovery_text": obj.get("description", "You examine it closely."),
                "reaction_emoji": "🔍",
            })

    normalized_choices = []
    for ch in sc.get("choices") or []:
        nc = normalize_choice(ch)
        if not nc.get("activity_type"):
            nc["activity_type"] = "story"
        normalized_choices.append(nc)
    sc["choices"] = normalized_choices
    dilemma = normalize_dilemma(sc.get("dilemma"))
    if dilemma:
        sc["dilemma"] = dilemma
    elif sc.get("dilemma"):
        del sc["dilemma"]
    return sc


def scene_by_id(world: dict, scene_id: str) -> Optional[dict]:
    for sc in _scene_list(world):
        if sc.get("scene_id") == scene_id:
            return sc
    return None


def default_progress(start_scene_id: str) -> dict:
    return {
        "current_scene_id": start_scene_id,
        "completed_scenes": [],
        "inventory": [],
        "xp_earned": 0,
        "choices_made": [],
        "status": "playing",
        "ending_id": None,
        "mistake_recovery": {},
        "mini_practices": {},
    }


def first_scene_id(world: dict) -> str:
    scenes = _scene_list(world)
    if not scenes:
        raise ValueError("Story world has no scenes")
    return scenes[0]["scene_id"]


def normalize_numeric_answer(text: str) -> str:
    from story_challenges import normalize_numeric_answer as _norm
    return _norm(text)


def strip_world_for_client(world: dict) -> dict:
    """Remove answer keys and shape challenges for the browser."""
    data = copy.deepcopy(world)
    for sc in _scene_list(data):
        sid = sc.get("scene_id", "")
        sc["challenge"] = prepare_challenge_for_client(sc.get("challenge") or {}, sid)
        stripped = strip_scene_choices_for_client(sc)
        sc["choices"] = stripped["choices"]
    return data


def validate_world(raw: dict) -> dict:
    title = (raw.get("title") or "").strip()
    if not title:
        raise ValueError("Story world needs a title")

    characters = raw.get("characters") or []
    locations = raw.get("locations") or []
    objects = raw.get("objects") or []
    if len(characters) < 1:
        raise ValueError("Need at least one character")
    if len(locations) < 1:
        raise ValueError("Need at least one location")

    chapters = raw.get("chapters") or []
    if not chapters:
        raise ValueError("Need at least one chapter")

    scene_ids = set()
    loc_ids = {loc["id"] for loc in locations if loc.get("id")}
    char_ids = {c["id"] for c in characters if c.get("id")}

    for ch in chapters:
        scenes = ch.get("scenes") or []
        if not scenes:
            raise ValueError(f"Chapter {ch.get('chapter_number')} has no scenes")
        for sc in scenes:
            sid = (sc.get("scene_id") or "").strip()
            if not sid or sid in scene_ids:
                raise ValueError(f"Invalid duplicate scene_id: {sid}")
            scene_ids.add(sid)
            if sc.get("location_id") not in loc_ids:
                raise ValueError(f"Scene {sid} references unknown location")
            for cid in sc.get("character_ids") or []:
                if cid not in char_ids:
                    raise ValueError(f"Scene {sid} references unknown character {cid}")
            challenge = normalize_challenge(sc.get("challenge") or {})
            interaction = get_interaction(challenge)
            if interaction not in CHALLENGE_TYPES:
                raise ValueError(f"Invalid challenge type: {interaction}")
            validate_challenge_fields(challenge, sid)

    endings = raw.get("endings") or []
    if not endings:
        raise ValueError("Need at least one story ending")

    return {
        "title": title,
        "synopsis": (raw.get("synopsis") or "").strip(),
        "characters": characters,
        "locations": locations,
        "objects": objects,
        "learning_objectives": list(raw.get("learning_objectives") or [])[:6],
        "chapters": chapters,
        "endings": endings,
    }


def apply_challenge_result(
    world: dict,
    progress: dict,
    scene_id: str,
    correct: bool,
) -> dict:
    scene = scene_by_id(world, scene_id)
    if not scene:
        raise ValueError("Scene not found")
    challenge = scene.get("challenge") or {}
    narrative = challenge.get("success_narrative" if correct else "failure_narrative", "")
    reward = None
    next_scene_id = None

    if correct:
        if scene_id not in progress["completed_scenes"]:
            progress["completed_scenes"].append(scene_id)
        xp = int(challenge.get("reward_xp") or 10)
        progress["xp_earned"] += xp
        item = (challenge.get("reward_item") or "").strip()
        if item and item not in progress["inventory"]:
            progress["inventory"].append(item)
        reward = {"xp": xp, "item": item or None}
        next_scene_id = scene.get("next_scene_id") or _next_scene_in_order(world, scene_id)
        if next_scene_id:
            progress["current_scene_id"] = next_scene_id
        else:
            progress["status"] = "complete"
            progress["ending_id"] = (world.get("endings") or [{}])[0].get("id")
    return {
        "correct": correct,
        "narrative": narrative,
        "explanation": challenge.get("explanation", ""),
        "reward": reward,
        "next_scene_id": next_scene_id,
        "progress": progress,
        "world_complete": progress.get("status") == "complete",
    }


def apply_choice(
    world: dict,
    progress: dict,
    scene_id: str,
    choice_id: str,
) -> dict:
    scene = scene_by_id(world, scene_id)
    if not scene:
        raise ValueError("Scene not found")
    choice = None
    for c in scene.get("choices") or []:
        if c.get("id") == choice_id:
            choice = c
            break
    if not choice:
        raise ValueError("Choice not found")

    progress["choices_made"].append({"scene_id": scene_id, "choice_id": choice_id})
    if scene_id not in progress["completed_scenes"]:
        progress["completed_scenes"].append(scene_id)

    xp = int(choice.get("reward_xp") or 5)
    progress["xp_earned"] += xp
    item = (choice.get("reward_item") or "").strip()
    if item and item not in progress["inventory"]:
        progress["inventory"].append(item)

    next_scene_id = (choice.get("next_scene_id") or "").strip() or (scene.get("next_scene_id") or "").strip()
    if choice.get("ending_id") and not next_scene_id:
        progress["status"] = "complete"
        progress["ending_id"] = choice.get("ending_id")
        next_scene_id = None
    elif next_scene_id:
        progress["current_scene_id"] = next_scene_id
    else:
        fallback = _next_scene_in_order(world, scene_id)
        if fallback:
            progress["current_scene_id"] = fallback
            next_scene_id = fallback
        else:
            progress["status"] = "complete"
            progress["ending_id"] = choice.get("ending_id") or (world.get("endings") or [{}])[0].get("id")
            next_scene_id = None

    return {
        "choice_id": choice_id,
        "consequence": choice.get("consequence", ""),
        "learning_note": choice.get("learning_note", ""),
        "outcome": build_choice_outcome(choice, scene),
        "reward": {"xp": xp, "item": item or None},
        "next_scene_id": next_scene_id,
        "progress": progress,
        "world_complete": progress.get("status") == "complete",
    }


def _next_scene_in_order(world: dict, scene_id: str) -> Optional[str]:
    scenes = _scene_list(world)
    ids = [s["scene_id"] for s in scenes]
    if scene_id not in ids:
        return None
    idx = ids.index(scene_id)
    if idx + 1 < len(ids):
        return ids[idx + 1]
    return None


def get_ending(world: dict, ending_id: Optional[str]) -> Optional[dict]:
    for e in world.get("endings") or []:
        if e.get("id") == ending_id:
            return e
    endings = world.get("endings") or []
    return endings[0] if endings else None


def save_session(conn, world_id: str, learner_id: str, cache_key: str, world: dict, progress: dict) -> None:
    now = time.time()
    conn.execute(
        """
        INSERT INTO story_world_sessions (world_id, learner_id, cache_key, world_json, progress_json, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(world_id) DO UPDATE SET
            progress_json = excluded.progress_json,
            updated_at = excluded.updated_at
        """,
        (
            world_id, learner_id, cache_key,
            json.dumps(world), json.dumps(progress), now, now,
        ),
    )


def load_session(conn, world_id: str, learner_id: str) -> Optional[tuple[dict, dict]]:
    row = conn.execute(
        "SELECT world_json, progress_json FROM story_world_sessions WHERE world_id = ? AND learner_id = ?",
        (world_id, learner_id),
    ).fetchone()
    if not row:
        return None
    return json.loads(row["world_json"]), json.loads(row["progress_json"])
