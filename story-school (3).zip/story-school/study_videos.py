"""Curated age-appropriate YouTube study links for CBSE topics."""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class StudyVideo:
    title: str
    url: str
    channel: str
    min_grade: int
    max_grade: int
    subjects: tuple[str, ...]
    keywords: tuple[str, ...] = ()
    duration: str = ""
    description: str = ""


@dataclass(frozen=True)
class StudyChannel:
    title: str
    url: str
    channel: str
    min_grade: int
    max_grade: int
    subjects: tuple[str, ...]
    description: str = ""


# Trusted educational channels — used when no topic-specific video matches.
SUBJECT_CHANNELS: tuple[StudyChannel, ...] = (
    StudyChannel(
        "Khan Academy — Math & Science",
        "https://www.youtube.com/@khanacademy",
        "Khan Academy",
        6, 10, ("Mathematics", "Science"),
        "Clear explanations aligned with school math and science.",
    ),
    StudyChannel(
        "Khan Academy Kids",
        "https://www.youtube.com/@KhanAcademyKids",
        "Khan Academy Kids",
        5, 7, ("Mathematics", "Science", "English"),
        "Gentle videos for younger learners.",
    ),
    StudyChannel(
        "SciShow Kids",
        "https://www.youtube.com/@SciShowKids",
        "SciShow Kids",
        5, 8, ("Science",),
        "Fun science questions answered with facts and wonder.",
    ),
    StudyChannel(
        "Crash Course Kids",
        "https://www.youtube.com/@crashcoursekids",
        "Crash Course Kids",
        5, 8, ("Science", "Social Science"),
        "Animated explainers on earth, space, and ecosystems.",
    ),
    StudyChannel(
        "TED-Ed",
        "https://www.youtube.com/@TEDEd",
        "TED-Ed",
        7, 10, ("Science", "Social Science", "English"),
        "Short animated lessons on history, literature, and ideas.",
    ),
    StudyChannel(
        "National Geographic Kids",
        "https://www.youtube.com/@NatGeoKids",
        "National Geographic Kids",
        5, 8, ("Science", "Social Science"),
        "Animals, geography, and the natural world.",
    ),
    StudyChannel(
        "NCERT Official",
        "https://www.youtube.com/@NCERTOFFICIAL",
        "NCERT",
        5, 10, ("Mathematics", "Science", "Social Science", "English"),
        "Official NCERT channel for textbook-aligned content.",
    ),
    StudyChannel(
        "Learn Bright",
        "https://www.youtube.com/@LearnBright",
        "Learn Bright",
        5, 7, ("Mathematics", "Science", "English", "Social Science"),
        "Bright, classroom-style videos for primary grades.",
    ),
    StudyChannel(
        "BYJU'S",
        "https://www.youtube.com/@BYJUS",
        "BYJU'S",
        6, 10, ("Mathematics", "Science", "Social Science"),
        "Popular CBSE-style lessons for middle and senior grades.",
    ),
)


# Topic-specific picks from trusted channels (stable, curriculum-aligned).
CURATED_VIDEOS: tuple[StudyVideo, ...] = (
    # Mathematics
    StudyVideo(
        "What are Fractions?",
        "https://www.youtube.com/watch?v=ccUqqeijX7s",
        "Khan Academy", 4, 7, ("Mathematics",), ("fraction", "numerator", "denominator"),
        "4 min", "Visual intro to parts of a whole.",
    ),
    StudyVideo(
        "Adding and Subtracting Fractions",
        "https://www.youtube.com/watch?v=5juto2ze8Lg",
        "Khan Academy", 5, 8, ("Mathematics",), ("fraction", "add", "subtract"),
        "6 min", "Step-by-step fraction operations.",
    ),
    StudyVideo(
        "Introduction to Decimals",
        "https://www.youtube.com/watch?v=6ziPFXJEa8A",
        "Khan Academy", 5, 8, ("Mathematics",), ("decimal", "place value"),
        "5 min", "Tenths, hundredths, and comparing decimals.",
    ),
    StudyVideo(
        "Prime Numbers and Factorization",
        "https://www.youtube.com/watch?v=mIStB5X4U8M",
        "Khan Academy", 6, 8, ("Mathematics",), ("prime", "factor", "multiple", "hcf", "lcm"),
        "7 min", "Divisors, primes, and factor trees.",
    ),
    StudyVideo(
        "Perimeter and Area",
        "https://www.youtube.com/watch?v=rSVMrTLSsIE",
        "Khan Academy", 5, 8, ("Mathematics",), ("perimeter", "area", "rectangle", "mensuration"),
        "8 min", "Measuring around and inside shapes.",
    ),
    StudyVideo(
        "Angles: Acute, Obtuse, and Right",
        "https://www.youtube.com/watch?v=DGKwdYSYPFc",
        "Khan Academy", 6, 8, ("Mathematics",), ("angle", "degree", "geometry"),
        "5 min", "Types of angles and how to measure them.",
    ),
    StudyVideo(
        "Symmetry",
        "https://www.youtube.com/watch?v=1i0p-kZ0GvE",
        "Learn Bright", 5, 7, ("Mathematics",), ("symmetry", "line of symmetry"),
        "4 min", "Mirror lines and symmetrical shapes.",
    ),
    StudyVideo(
        "Bar Graphs and Data",
        "https://www.youtube.com/watch?v=oIurNvdHDoQ",
        "Learn Bright", 5, 7, ("Mathematics",), ("data", "graph", "bar", "pictograph", "chart"),
        "5 min", "Reading and building simple graphs.",
    ),
    StudyVideo(
        "Negative Numbers",
        "https://www.youtube.com/watch?v=Hlal9ME2Aig",
        "Khan Academy", 6, 8, ("Mathematics",), ("integer", "negative", "number line"),
        "6 min", "Numbers below zero on the number line.",
    ),
    # Science
    StudyVideo(
        "Photosynthesis",
        "https://www.youtube.com/watch?v=UPBMG5EYydo",
        "SciShow Kids", 5, 8, ("Science",), ("photosynthesis", "plant", "chlorophyll", "leaf"),
        "4 min", "How plants make food from sunlight.",
    ),
    StudyVideo(
        "Food Chains and Ecosystems",
        "https://www.youtube.com/watch?v=6n1ZHZiwdlA",
        "Peekaboo Kidz", 5, 7, ("Science",), ("food chain", "ecosystem", "producer", "consumer"),
        "5 min", "Who eats whom in nature?",
    ),
    StudyVideo(
        "Magnets and Magnetism",
        "https://www.youtube.com/watch?v=y5AzW1OPLbY",
        "SciShow Kids", 6, 8, ("Science",), ("magnet", "magnetic", "pole"),
        "4 min", "Attract, repel, and magnetic fields.",
    ),
    StudyVideo(
        "States of Matter",
        "https://www.youtube.com/watch?v=wclY8F-UoTE",
        "Learn Bright", 5, 7, ("Science",), ("matter", "solid", "liquid", "gas", "state"),
        "5 min", "Solids, liquids, and gases explained.",
    ),
    StudyVideo(
        "The Solar System",
        "https://www.youtube.com/watch?v=libKVRa01L8",
        "National Geographic Kids", 5, 8, ("Science",), ("solar", "planet", "space", "sun", "earth"),
        "4 min", "A tour of planets and the Sun.",
    ),
    StudyVideo(
        "The Water Cycle",
        "https://www.youtube.com/watch?v=al-do-HGuIk",
        "SciShow Kids", 5, 7, ("Science",), ("water cycle", "evaporation", "condensation", "rain"),
        "4 min", "How water moves around Earth.",
    ),
    StudyVideo(
        "Digestive System",
        "https://www.youtube.com/watch?v=SBzTW8fHEGs",
        "Peekaboo Kidz", 5, 8, ("Science",), ("digest", "digestion", "stomach", "nutrient", "food"),
        "6 min", "The journey of food through your body.",
    ),
    StudyVideo(
        "Electricity Basics",
        "https://www.youtube.com/watch?v=mc979OhitAg",
        "SciShow Kids", 6, 8, ("Science",), ("electric", "electricity", "circuit", "current"),
        "4 min", "Circuits, conductors, and safety.",
    ),
    StudyVideo(
        "Light and Shadows",
        "https://www.youtube.com/watch?v=ltxqQbiI6-o",
        "Homeschool Pop", 5, 7, ("Science",), ("light", "shadow", "reflection"),
        "5 min", "How light travels and makes shadows.",
    ),
    StudyVideo(
        "Seed Germination",
        "https://www.youtube.com/watch?v=JSeP7e4r7Sg",
        "SciShow Kids", 5, 7, ("Science",), ("seed", "germination", "plant", "grow"),
        "4 min", "How a seed becomes a plant.",
    ),
    StudyVideo(
        "Adaptation in Animals",
        "https://www.youtube.com/watch?v=J9OPyQJ6aQY",
        "Crash Course Kids", 6, 8, ("Science",), ("adaptation", "habitat", "living", "organism"),
        "5 min", "How animals survive in their habitats.",
    ),
    # Social Science
    StudyVideo(
        "Maps and Globes",
        "https://www.youtube.com/watch?v=0vEn0h4zXlI",
        "Homeschool Pop", 5, 7, ("Social Science",), ("map", "globe", "geography", "location"),
        "6 min", "Reading maps, keys, and directions.",
    ),
    StudyVideo(
        "Weather vs Climate",
        "https://www.youtube.com/watch?v=EGeEfD3ggk4",
        "National Geographic Kids", 6, 8, ("Social Science",), ("climate", "weather"),
        "4 min", "Today's weather vs long-term climate.",
    ),
    StudyVideo(
        "The Indian Constitution",
        "https://www.youtube.com/watch?v=0WnD8IGcwAQ",
        "BYJU'S", 8, 10, ("Social Science",), ("constitution", "democracy", "republic", "preamble"),
        "8 min", "Founding ideas of India's democracy.",
    ),
    StudyVideo(
        "The Mughal Empire",
        "https://www.youtube.com/watch?v=JVxIpewSNME",
        "BYJU'S", 7, 9, ("Social Science",), ("mughal", "akbar", "history", "medieval"),
        "10 min", "Overview of Mughal rulers and culture.",
    ),
    StudyVideo(
        "French Revolution (overview)",
        "https://www.youtube.com/watch?v=8qRZcFTlD6k",
        "TED-Ed", 9, 10, ("Social Science",), ("french revolution", "revolution", "history"),
        "6 min", "Animated summary of causes and events.",
    ),
    StudyVideo(
        "Democracy Explained",
        "https://www.youtube.com/watch?v=4IBegL_V6AA",
        "TED-Ed", 7, 10, ("Social Science",), ("democracy", "government", "civics", "election"),
        "5 min", "What makes a democratic system.",
    ),
    # English
    StudyVideo(
        "Parts of Speech",
        "https://www.youtube.com/watch?v=8jetiorQ6aI",
        "Learn Bright", 5, 7, ("English",), ("grammar", "noun", "verb", "adjective", "parts of speech"),
        "6 min", "Nouns, verbs, adjectives, and more.",
    ),
    StudyVideo(
        "What is a Metaphor?",
        "https://www.youtube.com/watch?v=wvqQM00_BjI",
        "TED-Ed", 7, 10, ("English",), ("metaphor", "simile", "figurative", "literature", "poetry"),
        "5 min", "Figurative language in stories and poems.",
    ),
    StudyVideo(
        "How to Write a Paragraph",
        "https://www.youtube.com/watch?v=9P0rPbR0MXI",
        "Learn Bright", 5, 8, ("English",), ("writing", "paragraph", "composition", "essay"),
        "5 min", "Topic sentence, details, and closing.",
    ),
)


def _tokenize(text: str) -> set[str]:
    return {t for t in re.findall(r"[a-z0-9]+", (text or "").lower()) if len(t) > 2}


def _score_video(topic: str, video: StudyVideo) -> float:
    topic_tokens = _tokenize(topic)
    if not topic_tokens:
        return 0.0
    title_tokens = _tokenize(video.title)
    keyword_tokens: set[str] = set()
    for kw in video.keywords:
        keyword_tokens.update(_tokenize(kw))
    overlap_title = len(topic_tokens & title_tokens)
    overlap_kw = len(topic_tokens & keyword_tokens)
    return overlap_title * 2.0 + overlap_kw * 4.0


def _grade_ok(grade: int, min_g: int, max_g: int) -> bool:
    return min_g <= grade <= max_g


def _subject_ok(subject: str, subjects: tuple[str, ...]) -> bool:
    return subject in subjects


def external_links_allowed(controls: Optional[dict]) -> bool:
    """Whether parent controls allow curated external study links."""
    if not controls:
        return True
    filters = controls.get("content_filters") or {}
    return bool(filters.get("external_links", False))


def lookup_study_videos(
    grade: int,
    subject: str,
    topic: str,
    *,
    max_videos: int = 3,
    max_channels: int = 2,
) -> dict:
    """Return curated YouTube picks for a topic, plus trusted channel fallbacks."""
    topic = (topic or "").strip()
    scored: list[tuple[float, StudyVideo]] = []
    for video in CURATED_VIDEOS:
        if not _grade_ok(grade, video.min_grade, video.max_grade):
            continue
        if not _subject_ok(subject, video.subjects):
            continue
        score = _score_video(topic, video)
        if score > 0:
            scored.append((score, video))

    scored.sort(key=lambda x: x[0], reverse=True)
    videos = [
        {
            "title": v.title,
            "url": v.url,
            "channel": v.channel,
            "duration": v.duration,
            "description": v.description,
            "match_score": round(s, 1),
        }
        for s, v in scored[:max_videos]
    ]

    channels: list[dict] = []
    seen_urls: set[str] = set()
    for ch in SUBJECT_CHANNELS:
        if not _grade_ok(grade, ch.min_grade, ch.max_grade):
            continue
        if not _subject_ok(subject, ch.subjects):
            continue
        if ch.url in seen_urls:
            continue
        seen_urls.add(ch.url)
        channels.append({
            "title": ch.title,
            "url": ch.url,
            "channel": ch.channel,
            "description": ch.description,
        })
        if len(channels) >= max_channels:
            break

    note = None
    if not videos and channels:
        note = "Browse these trusted channels for more on this topic."
    elif videos:
        note = "Curated for your grade — watch with a grown-up when possible."
    elif not videos and not channels:
        note = "No curated videos for this subject yet — try NCERT or ask Finn!"

    return {
        "grade": grade,
        "subject": subject,
        "topic": topic,
        "videos": videos,
        "channels": channels,
        "note": note,
        "safety": (
            "Age-appropriate picks from trusted educational channels. "
            "Parents can disable external links in Parent Controls."
        ),
    }


def study_videos_catalog() -> dict:
    return {
        "name": "Further Study Videos",
        "description": (
            "Curated, age-appropriate YouTube videos from trusted educational "
            "channels for deeper learning and research."
        ),
        "trusted_channels": [
            {"name": ch.channel, "url": ch.url, "subjects": list(ch.subjects)}
            for ch in SUBJECT_CHANNELS
        ],
        "video_count": len(CURATED_VIDEOS),
        "safety_note": (
            "All links open on YouTube in a new tab. "
            "We recommend watching together with a parent or teacher."
        ),
    }
