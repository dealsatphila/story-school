"""Subject checkpoint gates — after every 3 topics, a 20-question exam unlocks the next batch."""

from __future__ import annotations

import json
import time
import uuid
from typing import Any, Optional

from syllabus import CBSE_SYLLABUS

TOPICS_PER_BATCH = 3
GATE_QUESTION_COUNT = 20
GATE_PASS_PCT = 80
GATE_MCQ_COUNT = 12
GATE_SUBJECTIVE_COUNT = 4
GATE_DESCRIPTIVE_COUNT = 4


def get_subject_topics(grade: int, subject: str) -> list[str]:
    grade_data = CBSE_SYLLABUS.get(grade) or CBSE_SYLLABUS.get(str(grade), {})
    subj = grade_data.get(subject)
    if not subj:
        return []
    return list(subj.get("topics", []))


def gate_key(grade: int, subject: str, gate_num: int) -> str:
    return f"{grade}|{subject}|{gate_num}"


def topics_for_gate(grade: int, subject: str, gate_num: int) -> list[str]:
    topics = get_subject_topics(grade, subject)
    start = gate_num * TOPICS_PER_BATCH
    return topics[start : start + TOPICS_PER_BATCH]


def gates_required_before_topic(topic_index: int) -> int:
    """How many gates (0-based) must be passed before this topic index."""
    return topic_index // TOPICS_PER_BATCH


def get_quiz_completed_topics(conn, learner_id: str, grade: int, subject: str) -> set[str]:
    rows = conn.execute(
        """
        SELECT topic FROM learning_progress
        WHERE learner_id = ? AND grade = ? AND subject = ? AND quiz_done = 1
        """,
        (learner_id.strip(), grade, subject),
    ).fetchall()
    return {r["topic"] for r in rows}


def is_gate_passed(conn, learner_id: str, grade: int, subject: str, gate_num: int) -> bool:
    row = conn.execute(
        """
        SELECT passed FROM subject_gate_results
        WHERE learner_id = ? AND gate_key = ? AND passed = 1
        """,
        (learner_id.strip(), gate_key(grade, subject, gate_num)),
    ).fetchone()
    return bool(row)


def gate_ready_to_take(conn, learner_id: str, grade: int, subject: str, gate_num: int) -> tuple[bool, str]:
    batch = topics_for_gate(grade, subject, gate_num)
    if len(batch) < TOPICS_PER_BATCH:
        return False, "This checkpoint is not available for this subject."
    completed = get_quiz_completed_topics(conn, learner_id, grade, subject)
    missing = [t for t in batch if t not in completed]
    if missing:
        return False, f"Finish the quiz for: {', '.join(missing)}"
    if is_gate_passed(conn, learner_id, grade, subject, gate_num):
        return False, "You already passed this checkpoint."
    return True, ""


def topic_is_unlocked(conn, learner_id: str, grade: int, subject: str, topic_index: int) -> bool:
    # Topic locks were removed: a learner can pick ANY topic in a subject
    # (e.g. jump straight to what they're studying in school) without first
    # clearing earlier checkpoints. The subject checkpoint still exists as an
    # OPTIONAL bonus once a batch of 3 topics is finished (see build_gate_status
    # / pending_gate) — it no longer gates topic access. Kept as a function so
    # every caller (_topic_access_guard, build_gate_status) stays unchanged.
    return True


def build_gate_status(conn, learner_id: str, grade: int, subject: str) -> dict:
    topics = get_subject_topics(grade, subject)
    topic_locks = []
    for i, topic in enumerate(topics):
        unlocked = topic_is_unlocked(conn, learner_id, grade, subject, i)
        gate_blocking = None
        if not unlocked:
            gate_blocking = gates_required_before_topic(i) - 1
        topic_locks.append({
            "index": i,
            "topic": topic,
            "unlocked": unlocked,
            "gate_num": gate_blocking,
        })

    completed = get_quiz_completed_topics(conn, learner_id, grade, subject)
    completed_in_order = [t for t in topics if t in completed]

    pending_gate: Optional[dict] = None
    max_gate = max(0, (len(topics) - 1) // TOPICS_PER_BATCH)
    for g in range(max_gate + 1):
        if is_gate_passed(conn, learner_id, grade, subject, g):
            continue
        ready, reason = gate_ready_to_take(conn, learner_id, grade, subject, g)
        batch = topics_for_gate(grade, subject, g)
        if len(batch) < TOPICS_PER_BATCH:
            break
        pending_gate = {
            "gate_num": g,
            "topics": batch,
            "ready": ready,
            "reason": reason if not ready else "",
            "passed": False,
        }
        if ready or len([t for t in batch if t in completed]) == TOPICS_PER_BATCH:
            break
        if not ready and len([t for t in batch if t in completed]) < TOPICS_PER_BATCH:
            pending_gate = None
            break

    passed_gates = []
    for g in range(max_gate + 1):
        if is_gate_passed(conn, learner_id, grade, subject, g):
            row = conn.execute(
                """
                SELECT pct, score, total, updated_at FROM subject_gate_results
                WHERE learner_id = ? AND gate_key = ?
                """,
                (learner_id.strip(), gate_key(grade, subject, g)),
            ).fetchone()
            passed_gates.append({
                "gate_num": g,
                "topics": topics_for_gate(grade, subject, g),
                "pct": row["pct"] if row else None,
                "score": row["score"] if row else None,
                "total": row["total"] if row else None,
                "updated_at": row["updated_at"] if row else None,
            })

    return {
        "grade": grade,
        "subject": subject,
        "topics_per_batch": TOPICS_PER_BATCH,
        "pass_pct": GATE_PASS_PCT,
        "question_count": GATE_QUESTION_COUNT,
        "completed_topics": completed_in_order,
        "completed_count": len(completed_in_order),
        "topic_locks": topic_locks,
        "pending_gate": pending_gate,
        "passed_gates": passed_gates,
    }


def strip_exam_for_client(exam: dict) -> dict:
    """Remove grading keys before sending to the browser."""
    public_questions = []
    for q in exam.get("questions", []):
        item: dict[str, Any] = {"type": q["type"], "question": q["question"]}
        if q["type"] == "mcq":
            item["options"] = q.get("options", [])
        elif q["type"] == "subjective":
            item["hint"] = "Short answer (2–4 sentences)"
        else:
            item["hint"] = "Detailed answer (1 short paragraph)"
        public_questions.append(item)
    return {
        "exam_id": exam["exam_id"],
        "gate_num": exam["gate_num"],
        "topics": exam["topics"],
        "questions": public_questions,
        "question_count": len(public_questions),
        "pass_pct": GATE_PASS_PCT,
    }


def grade_text_answer(q: dict, answer: Any) -> int:
    text = str(answer or "").strip()
    min_len = 20 if q["type"] == "descriptive" else 8
    if len(text) < min_len:
        return 0
    keywords = [k.strip().lower() for k in (q.get("keywords") or []) if k.strip()]
    lower = text.lower()
    if keywords:
        hits = sum(1 for k in keywords if k in lower)
        need = max(1, int(len(keywords) * (0.55 if q["type"] == "subjective" else 0.45)))
        return 1 if hits >= need else 0
    model_words = [w for w in (q.get("model_answer") or "").lower().split() if len(w) > 3]
    if not model_words:
        return 0
    user_words = set(lower.split())
    overlap = sum(1 for w in model_words if w in user_words)
    return 1 if overlap / len(model_words) >= 0.35 else 0


def grade_gate_exam(questions: list[dict], answers: list[Any]) -> dict:
    results = []
    score = 0
    for i, q in enumerate(questions):
        ans = answers[i] if i < len(answers) else None
        if q["type"] == "mcq":
            try:
                ok = int(ans) == int(q["correct_index"])
            except (TypeError, ValueError):
                ok = False
            pts = 1 if ok else 0
        else:
            pts = grade_text_answer(q, ans)
        score += pts
        results.append({"index": i, "correct": bool(pts), "type": q["type"]})
    total = len(questions)
    pct = round((score / total) * 100) if total else 0
    return {
        "score": score,
        "total": total,
        "pct": pct,
        "passed": pct >= GATE_PASS_PCT,
        "results": results,
    }


def validate_gate_questions(raw: list) -> list[dict]:
    if len(raw) != GATE_QUESTION_COUNT:
        raise ValueError(f"Expected {GATE_QUESTION_COUNT} questions, got {len(raw)}")
    counts = {"mcq": 0, "subjective": 0, "descriptive": 0}
    validated = []
    for q in raw:
        qtype = (q.get("type") or "").strip().lower()
        if qtype not in counts:
            raise ValueError(f"Invalid question type: {qtype}")
        counts[qtype] += 1
        question = (q.get("question") or "").strip()
        if not question:
            raise ValueError("Empty question")
        item: dict[str, Any] = {"type": qtype, "question": question}
        if qtype == "mcq":
            options = q.get("options") or []
            if len(options) != 4:
                raise ValueError("MCQ must have 4 options")
            ci = int(q.get("correct_index", -1))
            if ci not in range(4):
                raise ValueError("Invalid correct_index")
            item["options"] = options
            item["correct_index"] = ci
            item["explanation"] = (q.get("explanation") or "").strip()
        else:
            item["model_answer"] = (q.get("model_answer") or "").strip()
            item["keywords"] = [str(k).strip() for k in (q.get("keywords") or []) if str(k).strip()]
            if not item["model_answer"]:
                raise ValueError(f"{qtype} question needs model_answer")
        validated.append(item)
    if counts != {
        "mcq": GATE_MCQ_COUNT,
        "subjective": GATE_SUBJECTIVE_COUNT,
        "descriptive": GATE_DESCRIPTIVE_COUNT,
    }:
        raise ValueError(f"Wrong mix: {counts}")
    return validated


def store_gate_result(
    conn,
    learner_id: str,
    grade: int,
    subject: str,
    gate_num: int,
    topics: list[str],
    score: int,
    total: int,
    pct: int,
    passed: bool,
) -> None:
    now = time.time()
    gkey = gate_key(grade, subject, gate_num)
    conn.execute(
        """
        INSERT INTO subject_gate_results (
            learner_id, gate_key, grade, subject, gate_num, topics_json,
            score, total, pct, passed, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(learner_id, gate_key) DO UPDATE SET
            score = excluded.score,
            total = excluded.total,
            pct = excluded.pct,
            passed = MAX(subject_gate_results.passed, excluded.passed),
            updated_at = excluded.updated_at
        """,
        (
            learner_id.strip(), gkey, grade, subject, gate_num,
            json.dumps(topics), score, total, pct, 1 if passed else 0, now,
        ),
    )


def new_exam_id() -> str:
    return uuid.uuid4().hex
