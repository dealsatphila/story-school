"""Shared pytest setup.

Seed a fake ``OPENAI_API_KEY`` before any test module imports ``main``.
``main`` validates that the active AI provider has a key at import time (via
``ai_config.validate_active_provider``); several test modules import ``main``
without setting one. ``setdefault`` never overrides a real key, so this only
affects key-less environments (local dev, CI) and leaves production startup
validation untouched.
"""

import os

os.environ.setdefault("OPENAI_API_KEY", "test-key-for-pytest")
