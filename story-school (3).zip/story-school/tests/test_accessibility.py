"""Tests for accessibility preferences."""

import pytest

from accessibility import (
    accessibility_catalog,
    accessibility_prompt_block,
    body_classes_for_prefs,
    css_variables_for_prefs,
    default_accessibility_preferences,
    effective_content_language,
    normalize_accessibility_preferences,
)
import main


def test_default_preferences():
    prefs = default_accessibility_preferences()
    assert prefs["text_size_scale"] == 1.0
    assert prefs["audio_narration"] is True
    assert prefs["captions_enabled"] is True
    assert prefs["ui_theme"] == "default"


def test_normalize_legacy_migration():
    prefs = normalize_accessibility_preferences({
        "fontScale": 1.3,
        "highContrast": True,
        "dyslexia": True,
    })
    assert prefs["text_size_scale"] == 1.3
    assert prefs["high_contrast"] is True
    assert prefs["font_family"] == "dyslexia"


def test_prompt_block_reading_assistance():
    block = accessibility_prompt_block({
        "reading_assistance": True,
        "simplified_language": True,
    })
    assert "READING" in block
    assert "short sentences" in block.lower()


def test_css_and_body_classes():
    prefs = normalize_accessibility_preferences({
        "high_contrast": True,
        "reduced_motion": True,
        "color_independent_ui": True,
    })
    css = css_variables_for_prefs(prefs)
    assert "--base-font-scale" in css
    classes = body_classes_for_prefs(prefs)
    assert "high-contrast" in classes
    assert "reduced-motion" in classes
    assert "a11y-color-safe" in classes


def test_effective_content_language():
    prefs = {"preferred_content_language": "hindi"}
    assert effective_content_language(prefs, "english", "english") == "hindi"


def test_normalize_ui_theme():
    assert normalize_accessibility_preferences({"ui_theme": "ocean"})["ui_theme"] == "ocean"
    assert normalize_accessibility_preferences({"ui_theme": "bogus"})["ui_theme"] == "default"
    classes = body_classes_for_prefs({"ui_theme": "midnight"})
    assert "ui-theme-midnight" in classes
    assert "ui-theme-dark" in classes


def test_catalog():
    cat = accessibility_catalog()
    assert "font_families" in cat
    assert len(cat["features"]) >= 10
    assert len(cat["ui_themes"]) >= 8


def test_accessibility_api(tmp_path, monkeypatch):
    cache_path = tmp_path / "a11y_api.db"
    monkeypatch.setattr(main, "CACHE_DB", cache_path)
    main.init_cache()
    from fastapi.testclient import TestClient
    client = TestClient(main.app)

    cat = client.get("/api/accessibility/catalog")
    assert cat.status_code == 200

    learner = "a11y-learner"
    get_res = client.get("/api/accessibility/preferences", params={"learner_id": learner})
    assert get_res.status_code == 200
    assert get_res.json()["preferences"]["high_contrast"] is False

    put = client.put("/api/accessibility/preferences", json={
        "learner_id": learner,
        "preferences": {
            "high_contrast": True,
            "reduced_motion": True,
            "reading_assistance": True,
            "text_size_scale": 1.5,
        },
    })
    assert put.status_code == 200
    data = put.json()
    assert data["preferences"]["high_contrast"] is True
    assert "high-contrast" in data["body_classes"]

    block = accessibility_prompt_block(put.json()["preferences"])
    assert block
