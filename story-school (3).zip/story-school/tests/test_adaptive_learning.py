"""Tests for adaptive learning engine."""

from adaptive_learning import (
    apply_event,
    default_concept_state,
    infer_concept_tag,
    mastery_label,
    recommend_difficulty,
    status_message,
)


def test_infer_multiplication_tag():
    assert infer_concept_tag("Mathematics", "Multiplication of fractions") == "multiplication"
    assert infer_concept_tag("Mathematics", "Addition of whole numbers") == "addition"


def test_struggling_lowers_tier():
    state = default_concept_state(5, "Mathematics", "Multiplication", "multiplication")
    state["challenge_tier"] = 4
    state["difficulty"] = "hard"
    for _ in range(3):
        state = apply_event(state, {"correct": False, "hints": 1, "attempts": 2, "response_ms": 50000})
    assert state["challenge_tier"] < 4
    assert state["difficulty"] in ("easy", "medium")
    assert state["struggling"]


def test_excelling_raises_tier():
    state = default_concept_state(5, "Mathematics", "Multiplication", "multiplication")
    for _ in range(4):
        state = apply_event(state, {"correct": True, "hints": 0, "attempts": 1, "response_ms": 3000})
    assert state["challenge_tier"] >= 3
    assert state["success_streak"] >= 3


def test_status_message_struggling():
    state = default_concept_state(5, "Mathematics", "Multiplication", "multiplication")
    state = apply_event(state, {"correct": False, "hints": 0, "attempts": 1, "response_ms": 1000})
    state["struggling"] = True
    msg = status_message(state)
    assert "visual groups" in msg or "step by step" in msg


def test_recommend_difficulty_fallback():
    assert recommend_difficulty(None, "hard") == "hard"
