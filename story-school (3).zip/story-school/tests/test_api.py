import os
import sys

# Ensure app imports work without a live API key during tests
os.environ.setdefault("OPENAI_API_KEY", "test-key-for-pytest")

import pytest
from fastapi.testclient import TestClient

import main

client = TestClient(main.app)


@pytest.fixture(autouse=True)
def _use_temp_cache(tmp_path, monkeypatch):
    cache_path = tmp_path / "test_cache.db"
    monkeypatch.setattr(main, "CACHE_DB", cache_path)
    main.init_cache()


def test_syllabus_endpoint():
    res = client.get("/api/syllabus")
    assert res.status_code == 200
    data = res.json()
    assert "5" in data
    assert "Mathematics" in data["5"]
    assert "Hindi" in data["5"]
    assert "Kannada" in data["5"]
    assert "Sanskrit" in data["5"]
    assert "Social Studies" in data["5"]
    assert "History" in data["5"]
    assert "Geography" in data["5"]
    assert "Environmental Science" in data["5"]
    assert "Financial Literacy" in data["5"]
    assert "Coding and Computational Thinking" in data["5"]
    assert "Critical Thinking" in data["5"]
    assert "Problem Solving" in data["5"]
    assert "Creativity" in data["5"]
    assert "Communication" in data["5"]
    assert "Emotional and Social Learning" in data["5"]
    assert "Life Skills" in data["5"]
    assert len(data["5"]["Hindi"]["topics"]) >= 10


def test_languages_include_hindi():
    res = client.get("/api/languages")
    data = res.json()
    assert "hindi" in data
    assert "kannada" in data
    assert "sanskrit" in data


def test_genres_endpoint():
    assert client.get("/api/genres").status_code == 200


def test_json_schemas_strict_required_fields():
    """OpenAI strict json_schema requires every property key to appear in required."""

    def walk_schema(schema: dict, path: str) -> list[str]:
        issues: list[str] = []
        if not isinstance(schema, dict):
            return issues
        if schema.get("type") == "object" and "properties" in schema:
            props = set(schema["properties"].keys())
            required = set(schema.get("required", []))
            missing = props - required
            if missing:
                issues.append(f"{path}: missing in required: {sorted(missing)}")
        for key, val in schema.get("properties", {}).items():
            issues.extend(walk_schema(val, f"{path}.{key}"))
        if "items" in schema:
            issues.extend(walk_schema(schema["items"], f"{path}[]"))
        return issues

    from ai_config import SCHEMAS

    all_issues: list[str] = []
    for name, schema in SCHEMAS.items():
        all_issues.extend(walk_schema(schema, name))
    assert all_issues == [], "\n".join(all_issues)


def test_quiz_generate_with_learner_id(monkeypatch):
    sample_q = {
        "question": "What is 1/2 + 1/4?",
        "options": ["1/4", "3/4", "1/2", "1"],
        "correct_index": 1,
        "explanation": "Same denominator after converting.",
    }

    def _fake_complete_json(*_args, **_kwargs):
        return {"questions": [sample_q] * 4}

    monkeypatch.setattr(main, "complete_json", _fake_complete_json)
    res = client.post("/api/quiz", json={
        "grade": 5,
        "subject": "Mathematics",
        "topic": "Fractions",
        "learner_id": "quiz-learner-1",
        "genre": "adventure",
    })
    assert res.status_code == 200
    data = res.json()
    assert len(data["quiz"]["questions"]) == 4


def test_quiz_submit_invalid_score():
    res = client.post("/api/quiz/submit", json={
        "grade": 5, "subject": "Math", "topic": "Fractions",
        "score": 10, "total": 5,
    })
    assert res.status_code == 400


def test_quiz_submit_stores_mastery():
    res = client.post("/api/quiz/submit", json={
        "grade": 5, "subject": "Mathematics", "topic": "Fractions",
        "score": 8, "total": 8,
    })
    assert res.status_code == 200
    data = res.json()
    assert data["ok"] is True
    assert data["tier"] == "gold"
    assert data["mastery"]["tier"] == "gold"


def test_ncert_chapter_match():
    from ncert import lookup_ncert_chapter

    result = lookup_ncert_chapter(5, "Mathematics", "Fractions")
    assert result is not None
    assert result["chapter_num"] == 2
    assert "Fraction" in result["chapter_title"]
    assert result["pdf_url"].endswith("eemm102.pdf")


def test_ncert_endpoint():
    res = client.get("/api/ncert", params={
        "grade": 5, "subject": "Mathematics", "topic": "Fractions",
    })
    assert res.status_code == 200
    data = res.json()
    assert data["chapter_num"] == 2
    assert "pdf_url" in data


def test_ncert_endpoint_unknown_subject():
    res = client.get("/api/ncert", params={
        "grade": 5, "subject": "Sanskrit", "topic": "Verbs",
    })
    assert res.status_code == 404


def test_ai_models_endpoint():
    res = client.get("/api/ai/models")
    assert res.status_code == 200
    data = res.json()
    assert "story" in data
    assert "fast" in data
    assert data["routing"]["quiz"] == data["fast"]
    assert data["routing"]["story_stream"] == data["story"]


def test_ai_settings_endpoint():
    # GET exposes the current selection plus the catalog for the picker.
    res = client.get("/api/ai/settings")
    assert res.status_code == 200
    data = res.json()
    assert "provider" in data
    assert "story" in data["models"] and "fast" in data["models"]
    assert isinstance(data["catalog"], list) and data["catalog"]
    # Only OPENAI_API_KEY is set in the test env.
    assert "openai" in data["configured"]
    assert "anthropic" not in data["configured"]

    # Switching to a provider without a configured key is rejected.
    res = client.post("/api/ai/settings", json={"provider": "anthropic"})
    assert res.status_code == 400

    # An empty model id is rejected.
    res = client.post("/api/ai/settings", json={"fast": "   "})
    assert res.status_code == 400

    # A valid model change within the configured provider is applied...
    original_fast = data["models"]["fast"]
    res = client.post("/api/ai/settings", json={"fast": "gpt-4o-mini-test"})
    assert res.status_code == 200
    assert res.json()["models"]["fast"] == "gpt-4o-mini-test"
    # ...then restored so the process-global state doesn't leak into other tests.
    restore = client.post("/api/ai/settings", json={"fast": original_fast})
    assert restore.status_code == 200


def test_ncert_grounding_context():
    from ncert import ncert_grounding_context

    ctx = ncert_grounding_context(5, "Mathematics", "Fractions")
    assert "Maths Mela" in ctx
    assert "Chapter 2" in ctx
    assert "NCERT PDF" in ctx


def test_difficulties_endpoint():
    res = client.get("/api/difficulties")
    assert res.status_code == 200
    data = res.json()
    assert "easy" in data
    assert "medium" in data
    assert "hard" in data


def test_progress_record_and_list():
    learner = "test-learner-progress"
    main.record_learning_step(learner, 5, "Mathematics", "Fractions", "medium", "story")
    main.record_learning_step(
        learner, 5, "Mathematics", "Fractions", "medium", "quiz",
        quiz_tier="silver", quiz_pct=75,
    )
    topics = main.list_learning_progress(learner)
    assert len(topics) >= 1
    frac = next(t for t in topics if t["topic"] == "Fractions")
    assert frac["steps"]["story"] is True
    assert frac["steps"]["quiz"] is True
    assert frac["quiz_tier"] == "silver"
    assert frac["completion_pct"] == 50


def test_progress_api():
    learner = "test-learner-api"
    res = client.post("/api/progress", json={
        "learner_id": learner,
        "grade": 6, "subject": "Science", "topic": "Photosynthesis",
        "step": "mindmap", "difficulty": "hard",
    })
    assert res.status_code == 200
    data = client.get("/api/progress", params={"learner_id": learner}).json()
    assert any(t["topic"] == "Photosynthesis" for t in data["topics"])


def test_story_stream_cache_hit():
    key = main._story_cache_key(
        5, "Mathematics", "Fractions", "english", "realistic", "", "medium",
    )
    main.store_cached_story(key, 5, "Mathematics", "Fractions", "english", "realistic", "", "Cached story text")

    with client.stream("GET", "/api/explain/stream", params={
        "grade": 5, "subject": "Mathematics", "topic": "Fractions",
        "language": "english", "genre": "realistic", "novel_name": "",
    }) as res:
        assert res.status_code == 200
        body = res.read().decode("utf-8")
        assert "event: token" in body
        assert "Cached story text" in body
        assert "event: done" in body


def test_spaced_rules():
    res = client.get("/api/spaced/rules")
    assert res.status_code == 200
    assert res.json()["intervals_days"] == [1, 3, 7, 14]


def test_spaced_rate_review_and_due():
    learner = "test-spaced-learner"
    rate = client.post("/api/spaced/rate", json={
        "learner_id": learner,
        "grade": 5,
        "subject": "Mathematics",
        "topic": "Fractions",
        "item_type": "flashcard",
        "identifier": "0",
        "prompt": "What is 1/2 + 1/4?",
        "answer": "3/4",
        "correct": False,
    })
    assert rate.status_code == 200
    assert rate.json()["ok"] is True

    conn = main._get_conn()
    try:
        conn.execute(
            "UPDATE spaced_items SET due_at = 0 WHERE learner_id = ?",
            (learner,),
        )
        conn.commit()
    finally:
        conn.close()

    due = client.get("/api/spaced/due", params={"learner_id": learner})
    assert due.status_code == 200
    data = due.json()
    assert data["due_count"] >= 1
    item_key = data["items"][0]["item_key"]

    review = client.post("/api/spaced/review", json={
        "learner_id": learner,
        "item_key": item_key,
        "correct": True,
    })
    assert review.status_code == 200
    assert review.json()["ok"] is True
    assert review.json()["item"]["last_result"] == "correct"


def test_quiz_submit_seeds_spaced_wrong_items():
    learner = "test-spaced-quiz"
    res = client.post("/api/quiz/submit", json={
        "grade": 5,
        "subject": "Mathematics",
        "topic": "Fractions",
        "score": 6,
        "total": 8,
        "learner_id": learner,
        "wrong_items": [
            {
                "question": "Which fraction is largest?",
                "answer": "3/4",
                "explanation": "Compare numerators when denominators match.",
            },
        ],
    })
    assert res.status_code == 200

    conn = main._get_conn()
    try:
        conn.execute(
            "UPDATE spaced_items SET due_at = 0 WHERE learner_id = ?",
            (learner,),
        )
        conn.commit()
        row = conn.execute(
            "SELECT COUNT(*) AS c FROM spaced_items WHERE learner_id = ? AND item_type = 'quiz'",
            (learner,),
        ).fetchone()
        assert int(row["c"]) == 1
    finally:
        conn.close()

    due = client.get("/api/spaced/due", params={"learner_id": learner})
    assert due.json()["due_count"] == 1
    assert due.json()["items"][0]["item_type"] == "quiz"
    assert due.json()["items"][0]["extra"]["explanation"]


def test_topics_never_locked_but_checkpoint_offered():
    """Locks were removed: every topic is selectable from the start, regardless
    of prior progress. The subject checkpoint still surfaces as an OPTIONAL bonus
    once a batch of 3 topics is quiz-completed — it just no longer gates access."""
    learner = "gate-lock-learner"
    grade = 5
    subject = "Mathematics"
    from subject_gate import build_gate_status, get_subject_topics, topic_is_unlocked

    topics = get_subject_topics(grade, subject)
    assert len(topics) >= 4

    conn = main._get_conn()
    try:
        # Nothing completed yet — every topic is already unlocked (no gating).
        status0 = build_gate_status(conn, learner, grade, subject)
        assert all(lock["unlocked"] for lock in status0["topic_locks"])
        assert topic_is_unlocked(conn, learner, grade, subject, 3) is True
        assert status0["pending_gate"] is None
    finally:
        conn.close()

    for t in topics[:3]:
        main.record_learning_step(
            learner, grade, subject, t, "medium", "quiz", quiz_tier="gold", quiz_pct=90,
        )

    conn = main._get_conn()
    try:
        status = build_gate_status(conn, learner, grade, subject)
        # Still unlocked — finishing (or not) a batch never locks later topics.
        assert status["topic_locks"][3]["unlocked"] is True
        # The optional checkpoint is offered after the batch is complete.
        assert status["pending_gate"]["ready"] is True
        assert status["pending_gate"]["gate_num"] == 0
    finally:
        conn.close()


def test_subject_gate_status_api():
    learner = "gate-api-learner"
    res = client.get("/api/subject-gate/status", params={
        "learner_id": learner, "grade": 5, "subject": "Mathematics",
    })
    assert res.status_code == 200
    data = res.json()
    assert data["topics_per_batch"] == 3
    assert data["pass_pct"] == 80
    assert data["question_count"] == 20


def test_grade_gate_exam_mixed():
    from subject_gate import grade_gate_exam

    questions = [
        {
            "type": "mcq",
            "question": "2+2?",
            "options": ["3", "4", "5", "6"],
            "correct_index": 1,
        },
        {
            "type": "subjective",
            "question": "What is photosynthesis?",
            "model_answer": "Plants make food using sunlight",
            "keywords": ["plants", "sunlight", "chlorophyll", "food"],
        },
        {
            "type": "descriptive",
            "question": "Explain the water cycle.",
            "model_answer": "Water evaporates forms clouds and falls as rain",
            "keywords": ["evaporation", "condensation", "precipitation", "clouds"],
        },
    ]
    answers = [1, "Plants use sunlight and chlorophyll to make food", "Water evaporates into clouds and returns as precipitation"]
    result = grade_gate_exam(questions, answers)
    assert result["total"] == 3
    assert result["score"] == 3
    assert result["passed"] is True


def test_child_profile_save_and_normalize():
    from child_profile import child_profile_prompt_block, normalize_child_profile

    learner = "child-profile-test"
    res = client.put("/api/child-profile", json={
        "learner_id": learner,
        "name": "Aarav",
        "age": 10,
        "grade": 6,
        "preferred_language": "hindi",
        "reading_level": "developing",
        "interests": ["cricket", "space"],
        "favorite_characters": ["Spider-Man"],
        "favorite_animals": ["dolphin"],
        "favorite_colors_themes": ["blue", "space"],
        "learning_goals": ["fractions", "confidence"],
    })
    assert res.status_code == 200
    data = res.json()
    assert data["profile"]["name"] == "Aarav"
    assert data["profile"]["grade"] == 6
    assert "cricket" in data["profile"]["interests"]

    get_res = client.get("/api/child-profile", params={"learner_id": learner})
    assert get_res.json()["profile"]["name"] == "Aarav"

    block = child_profile_prompt_block(normalize_child_profile(data["profile"]))
    assert "Aarav" in block
    assert "cricket" in block


def test_child_profile_options():
    res = client.get("/api/child-profile/options")
    assert res.status_code == 200
    data = res.json()
    assert "reading_levels" in data
    assert "grade_level" in data["reading_levels"]
    assert data["grades"] == [5, 6, 7, 8, 9, 10]
    assert "story_themes" in data
    assert len(data["story_themes"]) == 17


def test_interests_catalog_and_events():
    learner = "interest-api-test"
    catalog = client.get("/api/interests/catalog")
    assert catalog.status_code == 200
    assert len(catalog.json()["story_themes"]) == 17

    res = client.post("/api/interests/event", json={
        "learner_id": learner,
        "event_type": "theme_pick",
        "payload": {"themes": ["space", "robots"]},
    })
    assert res.status_code == 200
    assert res.json()["ok"] is True

    get_res = client.get("/api/interests", params={"learner_id": learner})
    assert get_res.status_code == 200
    model = get_res.json()
    assert "top_themes" in model
    assert model["summary"]


def test_child_profile_saves_interest_fields():
    learner = "interest-profile-test"
    res = client.put("/api/child-profile", json={
        "learner_id": learner,
        "name": "Riya",
        "favorite_themes": ["magic", "princesses"],
        "favorite_story_types": ["fantasy"],
        "preferred_difficulty": "easy",
        "audio_narration": True,
        "audio_music": False,
        "audio_sfx": True,
    })
    assert res.status_code == 200
    profile = res.json()["profile"]
    assert "magic" in profile["favorite_themes"]
    assert profile["preferred_difficulty"] == "easy"
    assert profile["audio_music"] is False

    model = client.get("/api/interests", params={"learner_id": learner}).json()
    theme_ids = [t["id"] for t in model["top_themes"]]
    assert "magic" in theme_ids


def test_tutor_character_and_coach_routes():
    catalog = client.get("/api/tutor")
    assert catalog.status_code == 200
    assert catalog.json()["character"]["full_name"] == "Finn the Fox"

    coach = client.post("/api/tutor/coach", json={
        "coach_type": "hint",
        "topic": "Fractions",
        "question": "What is half of 10?",
        "hint": "Think of sharing equally",
    })
    assert coach.status_code == 200
    data = coach.json()
    assert data["emoji"] == "🦊"
    assert data["message"]
    assert data["follow_up"]


def test_mistake_analyze_route():
    res = client.post("/api/mistake/analyze", json={
        "challenge": {
            "type": "mcq",
            "question": "3 groups of 4 stars — total?",
            "options": ["7", "12", "16", "34"],
            "correct_index": 1,
            "explanation": "Multiply 3 × 4 = 12.",
            "hint": "Equal groups",
        },
        "user_answer": 2,
        "context": "quiz",
    })
    assert res.status_code == 200
    ml = res.json()["mistake_learning"]
    assert ml["headline"]
    assert ml["diagnosis"]
    assert ml["mini_practice"]


def test_progressive_hints_catalog_and_quiz_reveal():
    from main import _quiz_cache_key, store_cached_quiz

    cat = client.get("/api/hints/catalog")
    assert cat.status_code == 200
    assert cat.json()["max_level"] == 5

    qkey = _quiz_cache_key(5, "Mathematics", "Fractions", "english", "medium")
    store_cached_quiz(qkey, 5, "Mathematics", "Fractions", "english", {
        "questions": [{
            "question": "What is 1/2 of 10?",
            "options": ["2", "5", "10", "20"],
            "correct_index": 1,
            "explanation": "Half of 10 is 5.",
            "hint": "Split into two equal parts.",
        }],
    })

    hint_res = client.post("/api/hints/reveal", json={
        "context": "quiz",
        "learner_id": "hint-test-learner",
        "grade": 5,
        "subject": "Mathematics",
        "topic": "Fractions",
        "language": "english",
        "difficulty": "medium",
        "question_index": 0,
        "current_level": 0,
    })
    assert hint_res.status_code == 200
    data = hint_res.json()
    assert data["level"] == 1
    assert data["name"] == "Small clue"
    assert data["finn"]
    assert not data["reveals_answer"]

    hint5 = client.post("/api/hints/reveal", json={
        "context": "quiz",
        "grade": 5,
        "subject": "Mathematics",
        "topic": "Fractions",
        "language": "english",
        "difficulty": "medium",
        "question_index": 0,
        "current_level": 4,
    })
    assert hint5.status_code == 200
    assert hint5.json()["level"] == 5
    assert hint5.json()["reveals_answer"] is True


def test_story_world_activity_types_route():
    from main import app
    from fastapi.testclient import TestClient
    client = TestClient(app)
    res = client.get("/api/story-world/activity-types")
    assert res.status_code == 200
    data = res.json()
    assert len(data["categories"]) == 4


def test_adaptive_status_route():
    from main import app
    from fastapi.testclient import TestClient
    client = TestClient(app)
    res = client.get(
        "/api/adaptive/status",
        params={
            "learner_id": "test-learner-adaptive",
            "grade": 5,
            "subject": "Mathematics",
            "topic": "Multiplication",
        },
    )
    assert res.status_code == 200
    data = res.json()
    assert data["recommended_difficulty"] in ("easy", "medium", "hard")
    assert "message" in data


def test_gamification_catalog_route():
    from main import app
    from fastapi.testclient import TestClient
    client = TestClient(app)
    res = client.get("/api/gamification/catalog")
    assert res.status_code == 200
    assert "unlocks" in res.json()


def _sw_challenge(**overrides):
    base = {
        "activity_type": "mcq",
        "category": "reasoning",
        "pairs": [],
        "order_items": [],
        "correct_order": [],
        "drop_zones": [],
        "drop_items": [],
        "correct_placements": [],
        "memory_pairs": [],
        "blanks": [],
    }
    base.update(overrides)
    return base


def test_story_world_challenge_and_choice():
    from story_world import (
        apply_challenge_result,
        apply_choice,
        check_challenge_answer,
        default_progress,
        enrich_scene_for_playback,
        first_scene_id,
        validate_world,
    )

    world = validate_world({
        "title": "The Hidden Door",
        "synopsis": "Maya finds a magical door.",
        "characters": [
            {"id": "maya", "name": "Maya", "emoji": "👧", "role": "hero", "description": "curious"},
            {"id": "owl", "name": "Owl", "emoji": "🦉", "role": "guide", "description": "wise"},
        ],
        "locations": [
            {"id": "door", "name": "Hidden Door", "emoji": "🚪", "description": "glowing"},
            {"id": "hall", "name": "Hall", "emoji": "🏛️", "description": "wide"},
        ],
        "objects": [
            {"id": "key", "name": "Brass Key", "emoji": "🗝️", "location_id": "door", "description": "shiny"},
        ],
        "learning_objectives": ["Find one quarter of a set", "Solve numeric puzzles"],
        "chapters": [{
            "chapter_number": 1,
            "title": "The Hidden Door",
            "scenes": [
                {
                    "scene_id": "ch1_s1",
                    "title": "A Strange Glow",
                    "location_id": "door",
                    "background_theme": "village",
                    "character_ids": ["maya"],
                    "narrative": "Maya discovers a door.",
                    "dialogue": [
                        {"character_id": "maya", "line": "Maya discovers a door.", "mood": "curious"},
                        {"character_id": "narrator", "line": "A soft glow pulses from the cracks.", "mood": "neutral"},
                    ],
                    "hotspots": [],
                    "learning_objective": "Quarters",
                    "next_scene_id": "ch1_s2",
                    "challenge": _sw_challenge(
                        type="numeric",
                        activity_type="mental_math",
                        category="mathematics",
                        question="24 stars, one quarter blue. How many blue?",
                        hint="Divide by 4",
                        options=["", "", "", ""],
                        correct_index=-1,
                        correct_answer="6",
                        acceptable_answers=["six"],
                        keywords=[],
                        success_narrative="The door opens!",
                        failure_narrative="The door rumbles shut.",
                        explanation="24 ÷ 4 = 6",
                        reward_xp=15,
                        reward_item="brass key",
                    ),
                    "choices": [],
                },
                {
                    "scene_id": "ch1_s2",
                    "title": "The Hall",
                    "location_id": "hall",
                    "background_theme": "castle",
                    "character_ids": ["maya", "owl"],
                    "narrative": "A hall stretches ahead.",
                    "dialogue": [
                        {"character_id": "owl", "line": "Three paths lie ahead.", "mood": "curious"},
                        {"character_id": "maya", "line": "Which way should we go?", "mood": "worried"},
                    ],
                    "hotspots": [],
                    "learning_objective": "Choices matter",
                    "next_scene_id": "",
                    "challenge": _sw_challenge(
                        type="none",
                        question="", hint="",
                        options=["", "", "", ""],
                        correct_index=-1, correct_answer="",
                        acceptable_answers=[], keywords=[],
                        success_narrative="", failure_narrative="",
                        explanation="", reward_xp=0, reward_item="",
                    ),
                    "choices": [{
                        "id": "left", "text": "Go left", "emoji": "⬅️",
                        "consequence": "You find a library.",
                        "learning_note": "Exploring helps learning.",
                        "next_scene_id": "", "reward_xp": 5, "reward_item": "",
                        "ending_id": "end_hero", "activity_type": "explore",
                    }],
                },
            ],
        }, {
            "chapter_number": 2,
            "title": "Finale",
            "scenes": [{
                "scene_id": "ch2_s1",
                "title": "End",
                "location_id": "hall",
                "background_theme": "castle",
                "character_ids": ["maya"],
                "narrative": "The end.",
                "dialogue": [
                    {"character_id": "narrator", "line": "The end.", "mood": "happy"},
                    {"character_id": "maya", "line": "We did it!", "mood": "excited"},
                ],
                "hotspots": [],
                "learning_objective": "Review",
                "next_scene_id": "",
                "challenge": _sw_challenge(
                    type="none",
                    question="", hint="",
                    options=["", "", "", ""],
                    correct_index=-1, correct_answer="",
                    acceptable_answers=[], keywords=[],
                    success_narrative="", failure_narrative="",
                    explanation="", reward_xp=0, reward_item="",
                ),
                "choices": [],
            }],
        }],
        "endings": [{
            "id": "end_hero", "title": "Fraction Hero", "emoji": "🏆",
            "narrative": "Maya mastered fractions!",
        }],
    })

    assert check_challenge_answer(world["chapters"][0]["scenes"][0]["challenge"], "6")
    assert not check_challenge_answer(world["chapters"][0]["scenes"][0]["challenge"], "5")

    start = first_scene_id(world)
    progress = default_progress(start)
    result = apply_challenge_result(world, progress, "ch1_s1", True)
    assert result["correct"] is True
    assert "brass key" in result["progress"]["inventory"]
    assert result["next_scene_id"] == "ch1_s2"

    choice_result = apply_choice(world, result["progress"], "ch1_s2", "left")
    assert choice_result["world_complete"] is True
    assert choice_result.get("outcome")
    assert choice_result["outcome"]["consequence"]

    enriched = enrich_scene_for_playback(world["chapters"][0]["scenes"][0], world)
    assert enriched["background_theme"] == "village"
    assert len(enriched["dialogue"]) >= 2


def test_companion_catalog_and_growth():
    cat = client.get("/api/companion/catalog")
    assert cat.status_code == 200
    data = cat.json()
    assert len(data["attributes"]) == 7
    assert "clothes" in data["unlock_types"]

    learner = "companion-api-learner"
    view = client.get("/api/companion", params={"learner_id": learner, "level": 1, "coins": 50})
    assert view.status_code == 200
    assert view.json()["companion"]["name"] == "Spark"

    event = client.post("/api/companion/event", json={
        "learner_id": learner,
        "event_type": "quiz_gold",
    })
    assert event.status_code == 200
    body = event.json()
    assert body["ok"] is True
    assert body["companion"]["attributes"]["knowledge"] >= 2

    put = client.put("/api/companion", json={
        "learner_id": learner,
        "name": "Blaze",
        "species": "fox",
        "emoji": "🔥",
    })
    assert put.status_code == 200
    assert put.json()["companion"]["name"] == "Blaze"


def test_companion_purchase_and_equip():
    learner = "companion-shop-learner"
    client.post("/api/companion/event", json={
        "learner_id": learner,
        "event_type": "quiz_gold",
    })
    for _ in range(3):
        client.post("/api/companion/event", json={
            "learner_id": learner,
            "event_type": "doubt_asked",
        })

    buy = client.post("/api/companion/purchase", json={
        "learner_id": learner,
        "unlock_id": "magnifying_glass",
        "coins": 50,
        "level": 1,
    })
    assert buy.status_code == 200
    assert buy.json()["coins_spent"] == 10

    equip = client.post("/api/companion/equip", json={
        "learner_id": learner,
        "unlock_id": "magnifying_glass",
    })
    assert equip.status_code == 200
    assert equip.json()["companion"]["equipped"]["accessories"] == "magnifying_glass"


def test_choices_catalog():
    res = client.get("/api/choices/catalog")
    assert res.status_code == 200
    data = res.json()
    assert len(data["skills"]) == 5
    assert "ethics" in {s["id"] for s in data["skills"]}


def test_multimodal_catalog_and_preferences():
    cat = client.get("/api/multimodal/catalog")
    assert cat.status_code == 200
    assert len(cat.json()["modalities"]) == 5

    learner = "mm-prefs-learner"
    get_res = client.get("/api/multimodal/preferences", params={"learner_id": learner})
    assert get_res.status_code == 200
    assert get_res.json()["preferences"]["listening"]["speed"] == 1.0

    put_res = client.put("/api/multimodal/preferences", json={
        "learner_id": learner,
        "preferences": {"listening": {"speed": 1.3, "comprehension_checks": False}},
    })
    assert put_res.status_code == 200
    assert put_res.json()["preferences"]["listening"]["speed"] == 1.3

    fb = client.post("/api/multimodal/writing/feedback", json={
        "prompt_id": "short_answer",
        "text": "Fractions show parts of a whole.",
        "topic": "Fractions",
    })
    assert fb.status_code == 200
    assert fb.json()["ok"] is True

    comp = client.get("/api/multimodal/comprehension")
    assert comp.status_code == 200
    assert comp.json()["reflection_question"]


def test_parent_dashboard_api():
    learner = "parent-dash-api"
    client.post("/api/progress/profile", json={
        "learner_id": learner,
        "profile": {
            "totalXP": 100,
            "level": 1,
            "streak": 2,
            "stats": {"stories": 3, "quizzes": 1},
            "badges": ["first_story"],
        },
    })
    client.post("/api/progress", json={
        "learner_id": learner,
        "grade": 6,
        "subject": "Mathematics",
        "topic": "Fractions",
        "difficulty": "medium",
        "step": "quiz",
        "quiz_tier": "silver",
        "quiz_pct": 75,
    })
    res = client.get("/api/parent/dashboard", params={"learner_id": learner})
    assert res.status_code == 200
    data = res.json()
    assert data["learner_id"] == learner
    assert data["stories_completed"] == 3
    assert "topic_insights" in data
    assert "privacy_note" in data
    assert any(b.get("topic") == "Fractions" for b in data["topic_insights"])


def test_parent_controls_api():
    learner = "parent-controls-api"
    cat = client.get("/api/parent/controls/catalog")
    assert cat.status_code == 200
    assert "content_filters" in cat.json()

    get_res = client.get("/api/parent/controls", params={"learner_id": learner})
    assert get_res.status_code == 200
    assert get_res.json()["controls"]["daily_learning_minutes"] == 45

    put = client.put("/api/parent/controls", json={
        "learner_id": learner,
        "controls": {
            "daily_learning_minutes": 30,
            "learning_goals": ["fractions"],
            "bedtime_enabled": True,
            "blocked_subjects": ["Hindi"],
        },
        "pin": "4321",
    })
    assert put.status_code == 200
    assert put.json()["controls"]["daily_learning_minutes"] == 30

    status = client.get("/api/parent/controls/status", params={"learner_id": learner})
    assert status.status_code == 200
    assert status.json()["usage"]["daily_limit_minutes"] == 30

    session = client.post("/api/parent/controls/session", json={
        "learner_id": learner,
        "minutes": 5,
    })
    assert session.status_code == 200
    assert session.json()["usage"]["minutes_used"] == 5

    pin_fail = client.put("/api/parent/controls", json={
        "learner_id": learner,
        "controls": {"daily_learning_minutes": 20},
    })
    assert pin_fail.status_code == 403

    report = client.get("/api/parent/report", params={"learner_id": learner})
    assert report.status_code == 200
    assert "summary" in report.json()


def test_project_adventures_api():
    cat = client.get("/api/projects/catalog")
    assert cat.status_code == 200
    assert any(p["id"] == "build_a_rocket" for p in cat.json()["projects"])

    learner = "project-api-learner"
    start = client.post("/api/projects/start", json={
        "learner_id": learner,
        "project_id": "build_a_rocket",
    })
    assert start.status_code == 200
    assert start.json()["active"]["project_id"] == "build_a_rocket"

    step = client.post("/api/projects/step/complete", json={
        "learner_id": learner,
        "project_id": "build_a_rocket",
        "step_id": "learn_planets",
        "choice_id": "jupiter",
    })
    assert step.status_code == 200
    assert step.json()["step_complete"] is True
    assert step.json()["view"]["active"]["completed_steps"] == 1

    get_res = client.get("/api/projects", params={"learner_id": learner})
    assert get_res.status_code == 200
    assert get_res.json()["active"]["current_step"]["id"] == "calculate_distance"

