"""Tests for hidden assessment engine."""

import pytest

from assessment_engine import (
    SKILL_DIMENSIONS,
    assessment_catalog,
    build_learning_profile,
    observe_gameplay,
)
import main


@pytest.fixture
def conn(tmp_path, monkeypatch):
    cache_path = tmp_path / "assessment.db"
    monkeypatch.setattr(main, "CACHE_DB", cache_path)
    main.init_cache()
    return main._get_conn()


def test_observe_and_profile(conn):
    lid = "assess-learner-1"
    observe_gameplay(
        conn, lid, "story_challenge",
        grade=6, subject="Mathematics", topic="Fractions",
        correct=True, attempts=1,
    )
    observe_gameplay(
        conn, lid, "quiz",
        grade=6, subject="Mathematics", topic="Fractions",
        correct=True, attempts=1,
    )
    observe_gameplay(
        conn, lid, "dilemma_choice",
        grade=6, subject="Science", topic="Forces",
        correct=True,
        payload={"prediction": True, "reflection": True},
    )
    observe_gameplay(
        conn, lid, "story_challenge",
        grade=6, subject="Mathematics", topic="Fractions",
        correct=False, attempts=2,
    )
    observe_gameplay(
        conn, lid, "story_challenge",
        grade=6, subject="Mathematics", topic="Fractions",
        correct=True, attempts=3,
    )
    conn.commit()

    profile = build_learning_profile(conn, lid)
    assert profile["learner_id"] == lid
    assert profile["total_signals"] >= 5
    assert len(profile["dimensions"]) == len(SKILL_DIMENSIONS)
    assert "no separate tests" in profile["assessment_note"].lower()

    apply_dim = next(d for d in profile["dimensions"] if d["dimension"] == "apply_knowledge")
    assert apply_dim["evidence_count"] >= 2
    assert apply_dim["score"] is not None


def test_catalog():
    cat = assessment_catalog()
    assert len(cat["dimensions"]) == 8
    assert "quiz" in cat["sources"]


def test_assessment_api(tmp_path, monkeypatch):
    cache_path = tmp_path / "assessment_api.db"
    monkeypatch.setattr(main, "CACHE_DB", cache_path)
    main.init_cache()
    from fastapi.testclient import TestClient
    client = TestClient(main.app)

    learner = "assess-api"
    for _ in range(2):
        client.post("/api/assessment/observe", json={
            "learner_id": learner,
            "source": "adventure_choice",
            "grade": 6,
            "subject": "Science",
            "topic": "Plants",
            "correct": True,
            "payload": {"prediction": True},
        })

    profile = client.get("/api/assessment/profile", params={"learner_id": learner})
    assert profile.status_code == 200
    assert profile.json()["total_signals"] >= 2

    dash = client.get("/api/parent/dashboard", params={"learner_id": learner})
    assert dash.status_code == 200
    assert "learning_profile" in dash.json()
