"""Tests for child story creator."""

import os

os.environ.setdefault("OPENAI_API_KEY", "test-key-for-pytest")

from fastapi.testclient import TestClient

import main
from child_story_creator import (
    creator_catalog,
    validate_choices,
    validate_continued_story,
    validate_generated_story,
)

client = TestClient(main.app)


def test_creator_catalog():
    cat = creator_catalog()
    assert cat["emoji"] == "✍️"
    assert len(cat["choices"]["heroes"]) >= 5
    assert len(cat["skills_taught"]) == 5


def test_validate_choices():
    choices = validate_choices({
        "hero": "brave_kid",
        "animal": "fox",
        "location": "enchanted_forest",
        "problem": "solve_mystery",
        "theme": "friendship",
    })
    assert choices["hero"]["name"] == "Brave Kid"
    assert choices["animal"]["emoji"] == "🦊"


def test_validate_choices_missing():
    try:
        validate_choices({"hero": "brave_kid"})
        assert False, "should raise"
    except ValueError:
        pass


def test_validate_generated_story():
    result = validate_generated_story({
        "title": "The Brave Fox",
        "story": "Once upon a time…",
        "vocabulary": [{"word": "mystery", "definition": "something puzzling"}],
        "structure": {
            "beginning": "Meet the hero",
            "middle": "The problem grows",
            "ending": "Theme shines",
        },
        "skills_practiced": ["writing", "creativity"],
        "praise": "Wonderful choices!",
    })
    assert result["title"] == "The Brave Fox"
    assert result["structure"]["middle"] == "The problem grows"


def test_validate_continued_story():
    result = validate_continued_story({
        "title": "Next Chapter",
        "child_words_preserved": "glowing door",
        "story": "The door opened…",
        "vocabulary": [{"word": "portal", "definition": "a magical doorway"}],
        "skills_feedback": {
            "creativity": "Great original idea!",
            "sequencing": "Clear order of events.",
            "vocabulary": "Nice word choices.",
            "narrative_structure": "Strong beginning.",
            "writing": "Keep going!",
        },
        "praise": "You are an author!",
    }, "They found a glowing door.")
    assert result["child_draft"] == "They found a glowing door."
    assert "creativity" in result["skills_feedback"]


def test_create_story_catalog_api():
    res = client.get("/api/create-story/catalog")
    assert res.status_code == 200
    assert "choices" in res.json()


def test_continue_requires_draft():
    res = client.post("/api/create-story/continue", json={
        "grade": 5,
        "child_draft": "hi",
    })
    assert res.status_code == 400
