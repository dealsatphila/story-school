"""Tests for choices & consequences system."""

from choices_consequences import (
    adventure_consequence_user_message,
    build_choice_outcome,
    catalog_for_api,
    normalize_choice,
    normalize_dilemma,
    strip_choice_for_client,
)
from story_world import enrich_scene_for_playback, strip_world_for_client


def test_normalize_dilemma_and_choice():
    dilemma = normalize_dilemma({
        "setup": "The village well is almost dry.",
        "skills": ["ethics", "resource_management", "bogus"],
    })
    assert dilemma["setup"].startswith("The village")
    assert dilemma["skills"] == ["ethics", "resource_management"]

    ch = normalize_choice({
        "id": "b",
        "text": "Give more to those who need it most",
        "emoji": "💧",
        "consequence": "The elders thank you, but some fields stay thirsty.",
        "learning_note": "Fairness can mean unequal shares when needs differ.",
        "skill_tags": ["ethics", "critical_thinking"],
        "who_affected": ["farmers", "children"],
        "immediate_effects": ["Hospital gets water", "Some crops wilt"],
        "reflection_question": "Who would you ask before deciding?",
        "values_tradeoff": "Need vs equality",
        "next_scene_id": "ch2_s1",
        "reward_xp": 10,
        "reward_item": "",
        "ending_id": "",
        "activity_type": "story",
    })
    assert ch["skill_tags"] == ["ethics", "critical_thinking"]
    assert len(ch["immediate_effects"]) == 2


def test_strip_choice_hides_spoilers():
    ch = normalize_choice({
        "id": "a", "text": "Equal shares", "emoji": "⚖️",
        "consequence": "SECRET", "learning_note": "SECRET NOTE",
        "skill_tags": ["ethics"],
        "next_scene_id": "", "reward_xp": 5, "reward_item": "",
        "ending_id": "", "activity_type": "story",
    })
    client = strip_choice_for_client(ch)
    assert "consequence" not in client
    assert "learning_note" not in client
    assert client["text"] == "Equal shares"


def test_build_choice_outcome_enriches_skills():
    ch = normalize_choice({
        "id": "c", "text": "Find more water", "emoji": "🪣",
        "consequence": "Everyone digs a channel together.",
        "learning_note": "Cooperation can grow resources.",
        "skill_tags": ["resource_management", "decision_making"],
        "next_scene_id": "ch2_s2", "reward_xp": 8, "reward_item": "",
        "ending_id": "", "activity_type": "story",
    })
    scene = {"dilemma": {"setup": "Low water", "skills": ["resource_management"]}}
    outcome = build_choice_outcome(ch, scene)
    assert outcome["skill_tags"][0]["name"] == "Resource management"
    assert outcome["reflection_question"] == "" or isinstance(outcome["reflection_question"], str)


def test_strip_world_for_client_removes_consequences():
    world = {
        "title": "Test",
        "characters": [{"id": "n", "name": "N", "emoji": "🦊", "role": "guide", "description": "x"}],
        "locations": [{"id": "v", "name": "Village", "emoji": "🏡", "description": "x"}],
        "objects": [],
        "learning_objectives": [],
        "chapters": [{
            "chapter_number": 1,
            "scenes": [{
                "scene_id": "ch1_s1",
                "title": "Dilemma",
                "location_id": "v",
                "character_ids": ["n"],
                "narrative": "Water is scarce.",
                "challenge": {"type": "none"},
                "choices": [{
                    "id": "a", "text": "Share equally", "emoji": "⚖️",
                    "consequence": "Everyone gets a little.",
                    "learning_note": "Equality matters.",
                    "next_scene_id": "", "reward_xp": 5, "reward_item": "",
                    "ending_id": "", "activity_type": "story",
                }],
            }],
        }],
        "endings": [{"id": "end1", "title": "Done", "emoji": "🌟", "narrative": "The end."}],
    }
    client = strip_world_for_client(world)
    choice = client["chapters"][0]["scenes"][0]["choices"][0]
    assert "consequence" not in choice


def test_catalog_and_adventure_message():
    cat = catalog_for_api()
    assert len(cat["skills"]) == 5
    msg = adventure_consequence_user_message("Give everyone equal water")
    assert "CONSEQUENCES" in msg
    assert "equal water" in msg
