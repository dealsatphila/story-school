"""Unit tests for story companion development."""

from companion import (
    ATTRIBUTE_KEYS,
    COMPANION_UNLOCKS,
    UNLOCK_TYPES,
    apply_companion_event,
    companion_catalog,
    default_companion,
    equip_item,
    meets_requirements,
    normalize_companion,
    purchase_unlock,
    top_attributes,
)


def test_default_companion_has_narrative_attributes():
    c = default_companion()
    assert set(c["attributes"].keys()) == set(ATTRIBUTE_KEYS)
    assert all(v == 0 for v in c["attributes"].values())
    assert "starter_scarf" in c["unlocked"]


def test_apply_companion_event_grows_attributes():
    c = default_companion()
    updated, growth = apply_companion_event(c, "quiz_gold")
    assert updated["attributes"]["knowledge"] == 2
    assert updated["attributes"]["persistence"] == 1
    assert len(growth) == 2
    assert "adventure" in growth[0]["message"].lower()


def test_purchase_requires_coins_and_attributes():
    c = default_companion()
    item = next(u for u in COMPANION_UNLOCKS if u["id"] == "explorer_cap")
    updated, spent, err = purchase_unlock(c, item["id"], coins=100, level=1)
    assert err == "Companion needs more adventure growth first"
    assert spent == 0

    c["attributes"]["curiosity"] = 3
    updated, spent, err = purchase_unlock(c, item["id"], coins=5, level=1)
    assert err == f"Need {item['cost_coins']} coins"

    updated, spent, err = purchase_unlock(c, item["id"], coins=20, level=1)
    assert err is None
    assert spent == item["cost_coins"]
    assert item["id"] in updated["unlocked"]


def test_equip_item_by_type():
    c = default_companion()
    c["unlocked"].append("explorer_cap")
    c["attributes"]["curiosity"] = 3
    updated, err = equip_item(c, "explorer_cap")
    assert err is None
    assert updated["equipped"]["clothes"] == "explorer_cap"


def test_companion_catalog_covers_unlock_types():
    cat = companion_catalog()
    assert len(cat["attributes"]) == len(ATTRIBUTE_KEYS)
    assert set(cat["unlock_types"]) == set(UNLOCK_TYPES)
    total = sum(len(v) for v in cat["unlocks_by_type"].values())
    assert total == len(COMPANION_UNLOCKS)
    assert "not a judgment" in cat["narrative_note"].lower()


def test_top_attributes_ranked():
    c = default_companion()
    c["attributes"]["courage"] = 5
    c["attributes"]["kindness"] = 3
    tops = top_attributes(c, 2)
    assert tops[0]["id"] == "courage"
    assert tops[1]["id"] == "kindness"


def test_normalize_preserves_starter_unlocks():
    c = normalize_companion({"name": "Luna", "unlocked": []})
    assert c["name"] == "Luna"
    assert "starter_scarf" in c["unlocked"]


def test_meets_requirements():
    c = default_companion()
    c["attributes"]["knowledge"] = 4
    item = next(u for u in COMPANION_UNLOCKS if u["id"] == "star_hoodie")
    assert meets_requirements(c, item)
    c["attributes"]["knowledge"] = 2
    assert not meets_requirements(c, item)
