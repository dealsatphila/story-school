"""TestClient tests for the document-upload route (POST /api/document/generate).

Fully offline: main.complete_text / main.complete_json are monkeypatched, so no
provider SDK or network is touched. Mirrors the temp-cache fixture from test_api.py
because the story branch reads the learner profile from the DB.
"""

import os

os.environ.setdefault("OPENAI_API_KEY", "test-key-for-pytest")

import pytest
from fastapi.testclient import TestClient

import main

client = TestClient(main.app)


@pytest.fixture(autouse=True)
def _use_temp_cache(tmp_path, monkeypatch):
    cache_path = tmp_path / "test_cache.db"
    monkeypatch.setattr(main, "CACHE_DB", cache_path)
    main.init_cache()


_TXT = b"Photosynthesis is how green plants make their own food using sunlight."


def _fake_question_set():
    return {
        "title": "Photosynthesis Practice Set",
        "source_pattern": "5 MCQs with four options each at easy difficulty.",
        "questions": [
            {
                "type": "mcq",
                "question": "Which gas do plants absorb for photosynthesis?",
                "options": ["Oxygen", "Carbon dioxide", "Nitrogen", "Hydrogen"],
                "correct_index": 1,
                "model_answer": "Carbon dioxide",
                "keywords": ["carbon dioxide", "CO2"],
                "difficulty": "medium",
                "explanation": "Plants take in carbon dioxide from the air.",
            },
            {
                "type": "short_answer",
                "question": "Name the green pigment that captures light.",
                "options": [],
                "correct_index": -1,
                "model_answer": "Chlorophyll",
                "keywords": ["chlorophyll"],
                "difficulty": "medium",
                "explanation": "Chlorophyll absorbs light energy.",
            },
        ],
    }


def test_document_story_returns_story_text(monkeypatch):
    captured = {}

    def fake_complete_text(tier, instructions, messages):
        captured["tier"] = tier
        return "# A Sunny Tale\nProfessor Giggles explains photosynthesis..."

    monkeypatch.setattr(main, "complete_text", fake_complete_text)

    res = client.post(
        "/api/document/generate",
        data={
            "action": "story",
            "grade": "6",
            "subject": "Science",
            "topic": "Photosynthesis",
            "language": "english",
            "genre": "adventure",
            "difficulty": "medium",
            "learner_id": "",
        },
        files={"file": ("chapter.txt", _TXT, "text/plain")},
    )

    assert res.status_code == 200
    data = res.json()
    assert data["mode"] == "story"
    assert "Professor Giggles" in data["story"]
    assert data["source_filename"] == "chapter.txt"
    assert captured["tier"] == "story"


def test_document_questions_returns_question_set(monkeypatch):
    captured = {}

    def fake_complete_json(tier, schema_name, instructions, messages):
        captured["tier"] = tier
        captured["schema"] = schema_name
        return _fake_question_set()

    monkeypatch.setattr(main, "complete_json", fake_complete_json)

    res = client.post(
        "/api/document/generate",
        data={
            "action": "questions",
            "grade": "7",
            "subject": "Science",
            "difficulty": "medium",
            "learner_id": "",
        },
        files={"file": ("bank.txt", _TXT, "text/plain")},
    )

    assert res.status_code == 200
    data = res.json()
    assert data["mode"] == "questions"
    assert data["source_filename"] == "bank.txt"
    qset = data["question_set"]
    assert qset["title"]
    assert qset["source_pattern"]
    assert len(qset["questions"]) == 2
    assert qset["questions"][0]["type"] == "mcq"
    # The route must route to the fast tier + question_set schema.
    assert captured["tier"] == "fast"
    assert captured["schema"] == "question_set"


def test_document_unsupported_file_type_400(monkeypatch):
    # Should be rejected before any LLM call.
    monkeypatch.setattr(main, "complete_text", lambda *a, **k: pytest.fail("LLM should not run"))

    res = client.post(
        "/api/document/generate",
        data={"action": "story", "grade": "6"},
        files={"file": ("slides.pptx", b"binary-bytes", "application/octet-stream")},
    )
    assert res.status_code == 400


def test_document_unknown_action_400():
    res = client.post(
        "/api/document/generate",
        data={"action": "translate", "grade": "6"},
        files={"file": ("chapter.txt", _TXT, "text/plain")},
    )
    assert res.status_code == 400


def test_document_empty_text_400():
    # A .txt with only whitespace cleans to "" -> friendly 400 (scanned-PDF path).
    res = client.post(
        "/api/document/generate",
        data={"action": "story", "grade": "6"},
        files={"file": ("blank.txt", b"   \n\n  \t ", "text/plain")},
    )
    assert res.status_code == 400


def test_document_missing_file_422():
    # FastAPI enforces the required File(...) -> 422 before our handler runs.
    res = client.post(
        "/api/document/generate",
        data={"action": "story", "grade": "6"},
    )
    assert res.status_code == 422
