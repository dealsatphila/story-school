"""Offline tests for document text extraction (document_ingest)."""

import os
from io import BytesIO

os.environ.setdefault("OPENAI_API_KEY", "test-key-for-pytest")

import pytest

import document_ingest


def test_file_ext_lowercases_and_handles_missing():
    assert document_ingest.file_ext("Chapter.PDF") == ".pdf"
    assert document_ingest.file_ext("bank.DOCX") == ".docx"
    assert document_ingest.file_ext("notes.txt") == ".txt"
    assert document_ingest.file_ext("noextension") == ""
    assert document_ingest.file_ext("") == ""


def test_extract_txt_decodes_utf8():
    data = "Photosynthesis is how plants make food.".encode("utf-8")
    text = document_ingest.extract_text("chapter.txt", data)
    assert "Photosynthesis" in text


def test_extract_txt_survives_bad_bytes():
    # Invalid UTF-8 shouldn't raise — errors are replaced.
    text = document_ingest.extract_text("weird.txt", b"\xff\xfe bad bytes")
    assert isinstance(text, str)


def test_extract_docx_reads_paragraphs_and_tables():
    import docx

    d = docx.Document()
    d.add_paragraph("Photosynthesis is how plants make food.")
    d.add_paragraph("Chlorophyll captures sunlight.")
    table = d.add_table(rows=1, cols=2)
    table.rows[0].cells[0].text = "Reactant"
    table.rows[0].cells[1].text = "Carbon dioxide"
    buf = BytesIO()
    d.save(buf)

    text = document_ingest.extract_text("chapter.docx", buf.getvalue())
    assert "Photosynthesis" in text
    assert "Chlorophyll" in text
    assert "Carbon dioxide" in text  # table cell text is included


def test_extract_pdf_dispatch_returns_string():
    import pypdf

    # A blank page has no text layer; we only assert the .pdf branch runs and
    # returns a string (mirrors the scanned-PDF case the route treats as empty).
    writer = pypdf.PdfWriter()
    writer.add_blank_page(width=200, height=200)
    buf = BytesIO()
    writer.write(buf)

    text = document_ingest.extract_text("blank.pdf", buf.getvalue())
    assert isinstance(text, str)


def test_extract_unsupported_extension_raises():
    with pytest.raises(ValueError):
        document_ingest.extract_text("slides.pptx", b"anything")


def test_clean_text_collapses_whitespace():
    messy = "Hello   world\n\n\n\n\nLine2\t\ttabbed   "
    out = document_ingest.clean_text(messy)
    assert "Hello world" in out
    assert "\t" not in out
    assert "\n\n\n" not in out
    assert not out.endswith(" ")


def test_clean_text_truncates_to_max_chars():
    big = "word " * 20000  # ~100k chars
    out = document_ingest.clean_text(big)
    assert len(out) <= document_ingest.MAX_CHARS


def test_clean_text_empty_returns_empty():
    assert document_ingest.clean_text("") == ""
    assert document_ingest.clean_text("   \n\n \t ") == ""
