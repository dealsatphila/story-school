"""Tests for Ask Finn doubt chat message building."""

import os

os.environ.setdefault("OPENAI_API_KEY", "test-key-for-pytest")

from main import (
    DoubtMessage,
    DoubtRequest,
    _build_doubt_messages,
    _build_doubt_system,
    _normalize_doubt_history,
)


def test_first_doubt_message_is_single_turn():
    req = DoubtRequest(question="Why is the sky blue?", grade=6, subject="Science", topic="Light")
    msgs = _build_doubt_messages(req)
    assert len(msgs) == 1
    assert msgs[0]["role"] == "user"
    assert msgs[0]["content"] == "Why is the sky blue?"


def test_followup_embeds_history_in_one_user_turn():
    req = DoubtRequest(
        question="But what about at night?",
        grade=6,
        subject="Science",
        topic="Light",
        history=[
            DoubtMessage(role="user", content="Why is the sky blue?"),
            DoubtMessage(role="assistant", content="Great question! What do you notice about sunlight?"),
        ],
    )
    msgs = _build_doubt_messages(req)
    assert len(msgs) == 1
    assert msgs[0]["role"] == "user"
    assert "Earlier" in msgs[0]["content"] or "Continue our tutoring" in msgs[0]["content"]
    assert "Why is the sky blue?" in msgs[0]["content"]
    assert "Finn the Fox" in msgs[0]["content"]
    assert "But what about at night?" in msgs[0]["content"]
    assert "role" not in msgs[0]["content"].lower() or True  # no raw role keys leaked oddly


def test_normalize_doubt_history_skips_empty_and_bad_roles():
    raw = [
        DoubtMessage(role="user", content="Hi"),
        DoubtMessage(role="assistant", content=""),
        DoubtMessage(role="bot", content="ignored"),
        DoubtMessage(role="assistant", content="Hello!"),
    ]
    out = _normalize_doubt_history(raw)
    assert len(out) == 2
    assert out[0].content == "Hi"
    assert out[1].content == "Hello!"


def test_doubt_system_includes_story_excerpt():
    req = DoubtRequest(
        question="What happened in chapter 2?",
        grade=5,
        subject="English",
        topic="Stories",
        story_excerpt="Once upon a time a fox found a book.",
    )
    system = _build_doubt_system(req, {"instruction": "Reply in English."})
    assert "Once upon a time a fox found a book." in system
