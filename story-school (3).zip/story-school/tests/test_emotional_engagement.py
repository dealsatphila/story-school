"""Tests for emotional engagement module."""

from emotional_engagement import (
    EMOTIONAL_HOOKS,
    emotional_engagement_prompt_block,
    engagement_catalog,
    hooks_for_context,
    soft_gate_fail_message,
    soft_streak_message,
    supportive_wrong_answer_message,
)


def test_all_hooks_defined():
    assert len(EMOTIONAL_HOOKS) == 10
    assert "curiosity" in EMOTIONAL_HOOKS
    assert "empathy" in EMOTIONAL_HOOKS


def test_prompt_includes_ethical_rules():
    block = emotional_engagement_prompt_block("mystery")
    assert "NEVER use manipulative" in block
    assert "Curiosity" in block or "curiosity" in block.lower()
    assert "Mystery" in block


def test_genre_hook_emphasis():
    hooks = hooks_for_context("animals")
    assert hooks[0] == "empathy"


def test_soft_messages():
    assert "Welcome back" in soft_streak_message(1, returning_after_gap=True)
    assert "no rush" in soft_gate_fail_message().lower()
    assert supportive_wrong_answer_message()


def test_catalog():
    cat = engagement_catalog()
    assert len(cat["hooks"]) == 10
    assert "Streak-loss anxiety" in cat["avoid"]


def test_engagement_api():
    from fastapi.testclient import TestClient
    import main
    client = TestClient(main.app)
    res = client.get("/api/engagement/catalog")
    assert res.status_code == 200
    assert len(res.json()["hooks"]) == 10
