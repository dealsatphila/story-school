"""Tests for Phase 1 gamification."""

from gamification import (
    explorer_headline,
    explorer_rank_name,
    gamification_catalog,
    gate_pass_message,
    quiz_tier_message,
)


def test_explorer_headline_level_7():
    assert explorer_rank_name(7) == "Explorer"
    assert explorer_headline(7) == "⭐ Explorer Level 7"


def test_gamification_catalog():
    data = gamification_catalog()
    assert len(data["categories"] if "categories" in data else data["unlocks"]) >= 1
    assert "explorer_ranks" in data
    assert len(data["unlocks"]) >= 5
    assert "coins" in data["currencies"]


def test_narrative_messages():
    assert "Crystal" not in quiz_tier_message("gold")
    assert "🔓" in quiz_tier_message("silver")
    assert "🔓" in gate_pass_message("Science")
