"""Tests for progressive hint system."""

from hint_system import (
    MAX_HINT_LEVEL,
    hint_catalog,
    quiz_question_to_challenge,
    reveal_hint,
    synthesize_progressive_hints,
)


def _sample_mcq():
    return {
        "type": "mcq",
        "activity_type": "mcq",
        "category": "mathematics",
        "question": "What is 12 ÷ 3?",
        "hint": "Think about equal groups.",
        "explanation": "Divide 12 into 3 equal groups. Each group has 4.",
        "options": ["2", "3", "4", "6"],
        "correct_index": 2,
        "correct_answer": "",
    }


def test_hint_catalog_has_five_levels():
    cat = hint_catalog()
    assert cat["max_level"] == 5
    assert len(cat["levels"]) == 5
    assert cat["levels"][0]["name"] == "Small clue"
    assert cat["levels"][4]["name"] == "Answer + explanation"


def test_synthesize_five_hints():
    hints = synthesize_progressive_hints(_sample_mcq())
    assert len(hints) == 5
    assert "groups" in hints[0].lower() or "equal" in hints[0].lower()
    assert hints[4]  # level 5 has content


def test_stored_progressive_hints_used():
    ch = _sample_mcq()
    ch["progressive_hints"] = [
        "L1 custom", "L2 custom", "L3 custom", "L4 custom", "L5 custom",
    ]
    hints = synthesize_progressive_hints(ch)
    assert hints[0] == "L1 custom"
    assert hints[4] == "L5 custom"


def test_reveal_hint_levels():
    ch = _sample_mcq()
    r1 = reveal_hint(ch, 1)
    r5 = reveal_hint(ch, 5)
    assert r1["level"] == 1
    assert r1["next_level"] == 2
    assert r5["level"] == 5
    assert r5["next_level"] is None
    assert r5["reveals_answer"] is True
    assert "4" in r5["text"]


def test_level_one_does_not_reveal_answer_only():
    ch = _sample_mcq()
    r1 = reveal_hint(ch, 1)
    assert r1["reveals_answer"] is False
    # Level 1 should not be the full answer string alone
    assert r1["text"] != "4"


def test_quiz_question_adapter():
    q = {
        "question": "Which is a mammal?",
        "options": ["Shark", "Dolphin", "Trout", "Frog"],
        "correct_index": 1,
        "explanation": "Dolphins breathe air.",
        "hint": "Think about breathing.",
    }
    ch = quiz_question_to_challenge(q)
    hints = synthesize_progressive_hints(ch)
    assert len(hints) == MAX_HINT_LEVEL
