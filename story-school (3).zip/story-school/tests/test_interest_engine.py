"""Tests for Child Interest Engine preference model."""

import sqlite3

from interest_engine import (
    STORY_THEMES,
    apply_event,
    build_interest_model,
    default_preferences,
    infer_themes_from_text,
    init_interest_tables,
    interest_catalog,
    interest_prompt_block,
    interest_summary,
    merge_explicit_from_profile,
    record_interest_event,
    sync_explicit_profile,
    top_themes,
)


def _conn():
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    init_interest_tables(conn)
    return conn


def test_infer_themes_from_text():
    found = infer_themes_from_text("A rocket flies to a distant planet")
    assert "space" in found
    found2 = infer_themes_from_text("The dinosaur museum had fossils")
    assert "dinosaurs" in found2


def test_merge_explicit_profile_themes():
    prefs = default_preferences()
    profile = {
        "favorite_themes": ["space", "robots"],
        "favorite_story_types": ["scifi"],
        "interests": ["cricket"],
        "favorite_characters": ["Astro Bot"],
        "reading_level": "advanced",
        "preferred_difficulty": "hard",
        "audio_narration": False,
        "audio_music": True,
        "audio_sfx": False,
    }
    merged = merge_explicit_from_profile(prefs, profile)
    assert merged["favorite_themes"]["space"] >= 4.0
    assert merged["favorite_themes"]["robots"] >= 4.0
    assert merged["favorite_story_types"]["scifi"] >= 4.0
    assert merged["favorite_characters"]["astro_bot"] >= 3.0
    assert merged["reading_preferences"]["reading_level"] == "advanced"
    assert merged["preferred_difficulty"] == "hard"
    assert merged["audio_preferences"]["narration"] is False
    assert merged["audio_preferences"]["sfx"] is False


def test_apply_event_bumps_weights():
    prefs = default_preferences()
    prefs = apply_event(prefs, "genre_pick", {"genre": "scifi"})
    assert prefs["favorite_story_types"]["scifi"] >= 3.0
    assert prefs["favorite_themes"]["space"] >= 1.5

    prefs = apply_event(prefs, "activity_complete", {"activity_type": "mcq"})
    assert prefs["favorite_activity_types"]["mcq"] >= 2.5


def test_top_themes_and_summary():
    prefs = default_preferences()
    prefs = merge_explicit_from_profile(prefs, {"favorite_themes": ["space", "dinosaurs"]})
    themes = top_themes(prefs, 2)
    assert len(themes) >= 2
    assert themes[0]["emoji"]
    assert "space" in interest_summary(prefs).lower() or "🚀" in interest_summary(prefs)


def test_interest_prompt_block_includes_themes():
    prefs = merge_explicit_from_profile(
        default_preferences(),
        {"favorite_themes": ["magic", "fantasy"], "favorite_characters": ["Luna"]},
    )
    block = interest_prompt_block({"preferences": prefs})
    assert "CHILD INTEREST ENGINE" in block
    assert "Magic" in block or "magic" in block


def test_record_and_build_model():
    conn = _conn()
    learner = "interest-learner-1"
    profile = {"favorite_themes": ["ocean"], "preferred_difficulty": "easy"}
    record_interest_event(conn, learner, "subject_pick", {"subject": "Science"}, profile=profile)
    record_interest_event(conn, learner, "genre_pick", {"genre": "documentary"}, profile=profile)
    model = build_interest_model(conn, learner, profile)
    assert model["preferred_difficulty"] == "easy"
    assert model["top_subjects"]
    assert model["summary"]
    conn.close()


def test_sync_explicit_profile():
    conn = _conn()
    learner = "interest-sync"
    profile = {"favorite_themes": ["pirates", "adventure"]}
    sync_explicit_profile(conn, learner, profile)
    model = build_interest_model(conn, learner, profile)
    theme_ids = [t["id"] for t in model["top_themes"]]
    assert "pirates" in theme_ids
    conn.close()


def test_interest_catalog_has_all_themes():
    catalog = interest_catalog()
    assert len(catalog["story_themes"]) == len(STORY_THEMES) == 17
    assert "story_types" in catalog
    assert "activity_types" in catalog
