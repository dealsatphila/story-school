"""Tests for I Want to Know More curiosity paths."""

import os

os.environ.setdefault("OPENAI_API_KEY", "test-key-for-pytest")

from fastapi.testclient import TestClient

import main
from know_more import (
    extract_sparks_from_story,
    exploration_cache_key,
    merge_sparks,
    strip_know_more_markers,
    validate_exploration,
    validate_sparks,
)

client = TestClient(main.app)


def test_extract_sparks_from_markers():
    story = (
        "Once upon a time… {{KNOW_MORE: Why did dinosaurs become extinct?}}\n"
        "And then… {{KNOW_MORE: What is an asteroid?}}"
    )
    sparks = extract_sparks_from_story(story)
    assert len(sparks) == 2
    assert sparks[0]["question"] == "Why did dinosaurs become extinct?"
    assert sparks[0]["emoji"] == "🦖"


def test_strip_markers():
    text = "Hello {{KNOW_MORE: Why?}} world"
    assert "{{KNOW_MORE" not in strip_know_more_markers(text)


def test_validate_sparks_and_exploration():
    sparks = validate_sparks({
        "sparks": [
            {"question": "Why is the sky blue?", "emoji": "🌤️"},
            {"question": "How do clouds form?", "emoji": "☁️"},
        ]
    })
    assert len(sparks) == 2

    exploration = validate_exploration({
        "title": "Asteroids",
        "emoji": "☄️",
        "content": "Long ago, a space rock…",
        "fun_fact": "The Chicxulub crater is in Mexico.",
        "follow_ups": [
            {"question": "Want to explore the solar system?", "emoji": "🪐", "preview": "Planets and orbits"},
        ],
    }, "What is an asteroid?", depth=2)
    assert exploration["title"] == "Asteroids"
    assert len(exploration["follow_ups"]) == 1
    assert exploration["depth"] == 2


def test_merge_sparks_dedupes():
    a = [{"id": "1", "question": "Why?", "emoji": "🤔"}]
    b = [{"id": "2", "question": "Why?", "emoji": "❓"}, {"id": "3", "question": "How?", "emoji": "🛠️"}]
    merged = merge_sparks(a, b)
    assert len(merged) == 2


def test_cache_key_stable():
    k1 = exploration_cache_key(5, "Why?", ["Dinosaurs"])
    k2 = exploration_cache_key(5, "Why?", ["Dinosaurs"])
    assert k1 == k2


def test_know_more_catalog_api():
    res = client.get("/api/know-more/catalog")
    assert res.status_code == 200
    data = res.json()
    assert data["emoji"] == "🔎"
    assert data["max_depth"] >= 4


def test_sparks_from_embedded_story(tmp_path, monkeypatch):
    cache_path = tmp_path / "km_cache.db"
    monkeypatch.setattr(main, "CACHE_DB", cache_path)
    main.init_cache()

    story = (
        "Story text {{KNOW_MORE: Why did dinosaurs become extinct?}} "
        "and {{KNOW_MORE: What is an asteroid?}}"
    )
    res = client.post("/api/know-more/sparks", json={
        "grade": 5,
        "subject": "Science",
        "topic": "Dinosaurs",
        "story_text": story,
    })
    assert res.status_code == 200
    data = res.json()
    assert data["source"] == "embedded"
    assert len(data["sparks"]) >= 1
