"""Tests for Mistake → Learning system."""

from mistake_learning import (
    analyze_mistake,
    build_mini_practice,
    check_mini_practice,
    record_wrong_attempt,
    mark_mini_practice_done,
)


def _groups_challenge():
    return {
        "type": "mcq",
        "activity_type": "mental_math",
        "category": "mathematics",
        "question": "There are 3 groups of 4 stars. How many stars in total?",
        "hint": "Think equal groups.",
        "explanation": "Multiply 3 × 4 = 12. Three groups of four.",
        "options": ["7", "12", "16", "34"],
        "correct_index": 1,
        "correct_answer": "12",
    }


def test_analyze_mistake_not_just_wrong():
    ch = _groups_challenge()
    # User picked 12 from wrong index? index 2 is "16", index 3 is "34"
    # User picked 12 at index 1 would be correct. Pick index 2 = 16
    result = analyze_mistake(ch, 2)
    assert result["headline"]
    assert result["diagnosis"]
    assert "Wrong" not in result["diagnosis"] or "Almost" in result["headline"]
    assert result["visual_tip"]
    assert "draw" in result["visual_tip"].lower() or "group" in result["visual_tip"].lower()


def test_analyze_multiplication_misconception():
    ch = _groups_challenge()
  # 3*4=12 correct; user might answer 12 via wrong reasoning - pick 16 (index 2)
    result = analyze_mistake(ch, 2)
    assert len(result["finn_message"]) > 50


def test_build_mini_practice_has_client_payload():
    bundle = build_mini_practice(_groups_challenge(), "ch1_s1")
    assert "full" in bundle
    assert "client" in bundle
    assert bundle["client"]["question"]
    assert "correct_index" not in bundle["client"]


def test_mini_practice_flow_in_progress():
    progress = {"mistake_recovery": {}, "mini_practices": {}}
    bundle = build_mini_practice(_groups_challenge(), "ch1_s1")
    record_wrong_attempt(progress, "ch1_s1", bundle)
    assert progress["mini_practices"]["ch1_s1"]
    assert not progress["mistake_recovery"]["ch1_s1"]["retry_unlocked"]

    mini = progress["mini_practices"]["ch1_s1"]
    correct_idx = mini["correct_index"]
    assert check_mini_practice(mini, correct_idx)

    mark_mini_practice_done(progress, "ch1_s1")
    assert progress["mistake_recovery"]["ch1_s1"]["retry_unlocked"]


def test_numeric_wrong_diagnosis():
    ch = {
        "type": "numeric",
        "activity_type": "mental_math",
        "category": "mathematics",
        "question": "3 groups of 4 apples. How many apples?",
        "hint": "Groups",
        "explanation": "3 × 4 = 12",
        "options": [],
        "correct_index": -1,
        "correct_answer": "12",
        "acceptable_answers": [],
    }
    result = analyze_mistake(ch, "12")  # correct numeric - but let's test wrong
    wrong = analyze_mistake(ch, "7")
    assert wrong["diagnosis"]
    assert wrong["remembrance"]
