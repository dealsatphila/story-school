"""Tests for multimodal learning."""

from multimodal_learning import (
    build_writing_feedback,
    character_voice_settings,
    default_multimodal_preferences,
    extract_vocabulary,
    multimodal_catalog,
    multimodal_prompt_block,
    normalize_multimodal_preferences,
    strip_multimodal_markers,
)


def test_default_preferences_all_modalities():
    prefs = default_multimodal_preferences()
    assert set(prefs.keys()) == {"reading", "listening", "visual", "speaking", "writing"}
    assert prefs["listening"]["speed"] == 1.0


def test_normalize_clamps_listen_speed():
    prefs = normalize_multimodal_preferences({
        "listening": {"speed": 9.0, "narration": True},
    })
    assert prefs["listening"]["speed"] == 1.6


def test_extract_vocabulary_markers():
    text = "The {{VOCAB: fraction|a part of a whole}} was tasty."
    words = extract_vocabulary(text)
    assert len(words) == 1
    assert words[0]["word"] == "fraction"


def test_strip_markers_for_tts():
    raw = "See {{VOCAB: pi|3.14}} and {{ANIMATE: spin}}"
    clean = strip_multimodal_markers(raw)
    assert "VOCAB" not in clean
    assert "pi" in clean


def test_multimodal_prompt_includes_vocab_and_diagram():
    block = multimodal_prompt_block()
    assert "VOCAB" in block
    assert "DIAGRAM" in block


def test_catalog_lists_five_modalities():
    cat = multimodal_catalog()
    assert len(cat["modalities"]) == 5
    assert len(cat["writing_prompts"]) >= 3


def test_writing_feedback_encourages_longer_responses():
    short = build_writing_feedback("short_answer", "Hi", topic="Fractions")
    assert short["ok"] is True
    long = build_writing_feedback(
        "complete_story",
        " ".join(["word"] * 30),
        topic="Fractions",
    )
    assert long["word_count"] == 30
    assert "Wonderful" in long["message"]


def test_character_voice_varies_by_role():
    narrator = character_voice_settings("narrator")
    fox = character_voice_settings("finn_fox", "excited")
    assert fox["pitch"] != narrator["pitch"]
