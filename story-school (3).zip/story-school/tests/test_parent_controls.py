"""Tests for parent controls."""

import json
from datetime import datetime

import pytest

from parent_controls import (
    build_progress_report,
    build_usage_status,
    default_parent_controls,
    get_effective_difficulty,
    get_parent_controls,
    is_bedtime_active,
    is_subject_allowed,
    normalize_parent_controls,
    record_session_minutes,
    save_parent_controls,
    verify_parent_pin,
)
import main


@pytest.fixture
def conn(tmp_path, monkeypatch):
    cache_path = tmp_path / "parent_ctrl.db"
    monkeypatch.setattr(main, "CACHE_DB", cache_path)
    main.init_cache()
    return main._get_conn()


def test_normalize_defaults():
    c = normalize_parent_controls(None)
    assert c["daily_learning_minutes"] == 45
    assert c["content_filters"]["external_links"] is False


def test_subject_allow_block():
    controls = normalize_parent_controls({
        "allowed_subjects": ["Mathematics"],
        "blocked_subjects": ["Hindi"],
    })
    assert is_subject_allowed(controls, "Mathematics")
    assert not is_subject_allowed(controls, "Science")
    assert not is_subject_allowed(controls, "Hindi")


def test_difficulty_cap_and_lock():
    controls = normalize_parent_controls({
        "difficulty_mode": "cap",
        "max_difficulty": "medium",
    })
    assert get_effective_difficulty(controls, "hard") == "medium"

    locked = normalize_parent_controls({
        "difficulty_mode": "lock",
        "locked_difficulty": "easy",
    })
    assert get_effective_difficulty(locked, "hard", "hard") == "easy"


def test_bedtime_overnight_window():
    controls = normalize_parent_controls({
        "bedtime_enabled": True,
        "bedtime_start": "21:00",
        "bedtime_end": "07:00",
    })
    assert is_bedtime_active(controls, datetime(2026, 1, 1, 22, 0))
    assert not is_bedtime_active(controls, datetime(2026, 1, 1, 10, 0))


def test_save_controls_and_pin(conn):
    lid = "parent-ctrl-1"
    saved = save_parent_controls(conn, lid, default_parent_controls(), pin="1234")
    assert saved["learning_goals"] == []
    conn.commit()
    assert verify_parent_pin(conn, lid, "1234")
    assert not verify_parent_pin(conn, lid, "0000")

    with pytest.raises(PermissionError):
        save_parent_controls(conn, lid, {"daily_learning_minutes": 30})
    save_parent_controls(conn, lid, {"daily_learning_minutes": 30}, current_pin="1234")
    conn.commit()
    assert get_parent_controls(conn, lid)["daily_learning_minutes"] == 30


def test_session_minutes_and_usage(conn):
    lid = "parent-ctrl-2"
    save_parent_controls(conn, lid, {"daily_learning_minutes": 10, "screen_time_limit_minutes": 0})
    record_session_minutes(conn, lid, 6)
    record_session_minutes(conn, lid, 5)
    conn.commit()
    status = build_usage_status(conn, lid)
    assert status["minutes_used_today"] == 11
    assert status["can_learn"] is False
    assert status["blocked_reason"] == "daily_limit"


def test_progress_report(conn):
    lid = "parent-ctrl-3"
    conn.execute(
        """INSERT INTO learner_profile (learner_id, profile_json, updated_at)
           VALUES (?, ?, ?)""",
        (lid, json.dumps({"stats": {"stories": 2}, "streak": 1}), 1.0),
    )
    record_session_minutes(conn, lid, 3)
    conn.commit()
    report = build_progress_report(conn, lid, days=7)
    assert report["learner_id"] == lid
    assert report["summary"]["stories_completed"] == 2
    assert len(report["daily_usage"]) >= 1
