"""Tests for parent dashboard — actionable insights, not raw scores."""

import json
import time

import pytest

from adaptive_learning import concept_key, save_concept_state
from child_profile import save_child_profile
from interest_engine import record_interest_event
from parent_dashboard import (
    build_parent_dashboard,
    build_topic_insights,
    estimate_learning_minutes,
)
import main


@pytest.fixture
def conn(tmp_path, monkeypatch):
    cache_path = tmp_path / "parent_dash.db"
    monkeypatch.setattr(main, "CACHE_DB", cache_path)
    main.init_cache()
    return main._get_conn()


def test_build_topic_insights_fractions():
    insights = build_topic_insights(
        "Fractions",
        "Mathematics",
        quiz_tier="gold",
        quiz_pct=95,
        concept_state={"mastery_score": 0.8, "recent_misses": 0},
    )
    assert len(insights) == 3
    assert insights[0]["status"] == "green"
    assert "basic fractions" in insights[0]["message"]
    assert insights[0]["emoji"] == "🟢"


def test_estimate_learning_minutes():
    est = estimate_learning_minutes({
        "stats": {"stories": 5, "quizzes": 2, "adventures": 1},
        "daysActive": {"2026-01-01": True, "2026-01-02": True},
    })
    assert est["total_minutes"] == 5 * 8 + 2 * 6 + 12
    assert est["days_active"] == 2
    assert "not screen monitoring" in est["note"].lower()


def test_build_parent_dashboard_empty(conn):
    dash = build_parent_dashboard(conn, "learner-parent-1")
    assert dash["learner_id"] == "learner-parent-1"
    assert dash["stories_completed"] == 0
    assert "privacy_note" in dash
    assert isinstance(dash["topic_insights"], list)
    assert isinstance(dash["skills"], dict)


def test_build_parent_dashboard_with_progress(conn):
    lid = "learner-parent-2"
    now = time.time()
    conn.execute(
        """INSERT INTO learning_progress
           (learner_id, topic_key, grade, subject, topic, difficulty,
            story_done, mindmap_done, flashcards_done, quiz_done,
            quiz_tier, quiz_pct, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, 1, 1, 0, 1, ?, ?, ?)""",
        (lid, "6|Mathematics|Fractions", 6, "Mathematics", "Fractions", "medium",
         "gold", 92, now),
    )
    save_child_profile(conn, lid, {
        "name": "Aarav",
        "age": 11,
        "grade": 6,
        "reading_level": "grade_level",
        "preferred_language": "english",
    })
    tag = "fractions"
    state = {
        "concept_key": concept_key(6, "Mathematics", "Fractions", tag),
        "grade": 6,
        "subject": "Mathematics",
        "topic": "Fractions",
        "concept_tag": tag,
        "mastery_score": 0.72,
        "recent_misses": 1,
    }
    save_concept_state(conn, lid, state)
    conn.execute(
        """INSERT INTO learner_profile (learner_id, profile_json, updated_at)
           VALUES (?, ?, ?)""",
        (lid, json.dumps({
            "totalXP": 200,
            "level": 2,
            "streak": 3,
            "stats": {"stories": 4, "quizzes": 2},
            "badges": ["first_story", "quiz_gold"],
        }), now),
    )
    record_interest_event(conn, lid, "theme_pick", {"theme": "space"})
    conn.commit()

    dash = build_parent_dashboard(conn, lid)
    assert dash["child_name"] == "Aarav"
    assert dash["stories_completed"] == 4
    assert dash["time_spent"]["total_minutes"] > 0
    assert dash["skills"]["practiced_count"] >= 1
    assert any(b["topic"] == "Fractions" for b in dash["topic_insights"])
    frac = next(b for b in dash["topic_insights"] if b["topic"] == "Fractions")
    assert len(frac["insights"]) == 3
    assert any(i["emoji"] in ("🟢", "🟡", "🔴") for i in frac["insights"])
    assert dash["reading_progress"]["stories_read"] == 4
    assert dash["recent_achievements"]
