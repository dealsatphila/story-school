"""Tests for project-based adventures."""

from project_adventures import (
    complete_step,
    default_learner_projects,
    project_catalog,
    start_project,
    steps_with_status,
    validate_step_submission,
    PROJECT_BY_ID,
)


def test_catalog_includes_build_a_rocket():
    cat = project_catalog()
    ids = {p["id"] for p in cat["projects"]}
    assert "build_a_rocket" in ids
    rocket = PROJECT_BY_ID["build_a_rocket"]
    assert len(rocket["steps"]) == 7
    assert rocket["steps"][0]["id"] == "learn_planets"


def test_start_project_sets_first_step():
    state, _ = start_project(default_learner_projects(), "build_a_rocket")
    run = state["projects"]["build_a_rocket"]
    assert run["current_step_id"] == "learn_planets"
    assert state["active_project_id"] == "build_a_rocket"


def test_complete_rocket_steps_flow():
    state, _ = start_project(default_learner_projects(), "build_a_rocket")

    state, r1 = complete_step(state, "build_a_rocket", "learn_planets", {"choice_id": "moon"})
    assert r1["ok"] is True
    assert "learn_planets" in state["projects"]["build_a_rocket"]["completed_steps"]
    assert state["projects"]["build_a_rocket"]["current_step_id"] == "calculate_distance"

    state, r2 = complete_step(state, "build_a_rocket", "calculate_distance", {"answer": "10"})
    assert r2["ok"] is True

    # New calendar day — continue mission
    state["projects"]["build_a_rocket"]["daily_log"] = {}
    state, r3 = complete_step(
        state, "build_a_rocket", "design_rocket",
        {"design_id": "safety", "text": " ".join(["word"] * 22)},
    )
    assert r3["ok"] is True


def test_validate_numeric_wrong_answer():
    step = PROJECT_BY_ID["build_a_rocket"]["steps"][1]
    ok, msg, _ = validate_step_submission(step, {"answer": "99"})
    assert ok is False
    assert "Not quite" in msg


def test_daily_limit_blocks_extra_steps():
    from datetime import date

    state, _ = start_project(default_learner_projects(), "build_a_rocket")
    run = state["projects"]["build_a_rocket"]
    run["daily_log"] = {date.today().isoformat(): 2}
    state["projects"]["build_a_rocket"] = run
    try:
        complete_step(state, "build_a_rocket", "learn_planets", {"choice_id": "mars"})
        assert False, "should raise"
    except ValueError as e:
        assert "tomorrow" in str(e).lower()


def test_steps_with_status_locked_until_prior_done():
    state, _ = start_project(default_learner_projects(), "build_a_rocket")
    project = PROJECT_BY_ID["build_a_rocket"]
    statuses = {s["id"]: s["status"] for s in steps_with_status(project, state["projects"]["build_a_rocket"])}
    assert statuses["learn_planets"] == "active"
    assert statuses["calculate_distance"] == "locked"
