"""Tests for reflection system."""

import os

os.environ.setdefault("OPENAI_API_KEY", "test-key-for-pytest")

from fastapi.testclient import TestClient

import main
from reflection_system import (
    finn_reflection_reply,
    reflection_catalog,
    validate_option,
)

client = TestClient(main.app)


def test_reflection_catalog():
    cat = reflection_catalog()
    assert cat["emoji"] == "🪞"
    assert len(cat["options"]) == 5
    assert "adventure" in cat["activities"]


def test_validate_option():
    opt = validate_option("learned_new")
    assert opt["emoji"] == "💡"
    try:
        validate_option("invalid")
        assert False
    except ValueError:
        pass


def test_finn_reply_with_own_words():
    reply = finn_reflection_reply(
        validate_option("learned_new"),
        child_name="Asha",
        topic="Fractions",
        own_words="I finally understood how pizza slices work.",
    )
    assert "Asha" in reply["message"]
    assert "pizza" in reply["message"].lower()


def test_finn_reply_want_challenge():
    reply = finn_reflection_reply(validate_option("want_challenge"), child_name="Ravi")
    assert reply["next_step"]["action"] == "quiz"


def test_reflection_catalog_api():
    res = client.get("/api/reflection/catalog")
    assert res.status_code == 200
    assert len(res.json()["options"]) == 5


def test_reflection_submit(tmp_path, monkeypatch):
    cache_path = tmp_path / "refl_cache.db"
    monkeypatch.setattr(main, "CACHE_DB", cache_path)
    main.init_cache()

    res = client.post("/api/reflection/submit", json={
        "learner_id": "test-learner-refl",
        "activity_type": "adventure",
        "grade": 5,
        "subject": "Mathematics",
        "topic": "Fractions",
        "option_id": "learned_new",
        "own_words": "I learned that halves mean two equal parts.",
    })
    assert res.status_code == 200
    data = res.json()
    assert data["ok"] is True
    assert "finn_reply" in data

    mine = client.get("/api/reflection/mine?learner_id=test-learner-refl")
    assert mine.status_code == 200
    assert len(mine.json()["reflections"]) >= 1


def test_reflection_invalid_option():
    res = client.post("/api/reflection/submit", json={
        "learner_id": "x",
        "option_id": "not_real",
    })
    assert res.status_code == 400
