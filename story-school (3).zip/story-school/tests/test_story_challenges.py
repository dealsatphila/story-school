"""Tests for Story World learning challenge types."""

from story_challenges import (
    activity_catalog_for_api,
    check_challenge_answer,
    get_interaction,
    prepare_challenge_for_client,
)


def _base_challenge(**overrides):
    ch = {
        "type": "none",
        "activity_type": "mcq",
        "category": "reasoning",
        "question": "",
        "hint": "",
        "options": ["", "", "", ""],
        "correct_index": -1,
        "correct_answer": "",
        "acceptable_answers": [],
        "keywords": [],
        "pairs": [],
        "order_items": [],
        "correct_order": [],
        "drop_zones": [],
        "drop_items": [],
        "correct_placements": [],
        "memory_pairs": [],
        "blanks": [],
        "success_narrative": "ok",
        "failure_narrative": "try",
        "explanation": "",
        "reward_xp": 10,
        "reward_item": "",
    }
    ch.update(overrides)
    return ch


def test_activity_catalog_has_all_categories():
    data = activity_catalog_for_api()
    ids = {c["id"] for c in data["categories"]}
    assert ids == {"mathematics", "language", "science", "reasoning"}
    total = sum(len(c["activities"]) for c in data["categories"])
    assert total >= 30


def test_matching_challenge():
    ch = _base_challenge(
        type="matching",
        activity_type="word_matching",
        category="language",
        question="Match words",
        pairs=[
            {"left": "happy", "right": "glad"},
            {"left": "big", "right": "large"},
        ],
    )
    assert get_interaction(ch) == "matching"
    assert check_challenge_answer(ch, {"matches": {"0": "glad", "1": "large"}})
    assert not check_challenge_answer(ch, {"matches": {"0": "large", "1": "glad"}})


def test_ordering_challenge():
    ch = _base_challenge(
        type="ordering",
        activity_type="story_sequencing",
        category="language",
        question="Order events",
        order_items=["First", "Second", "Third"],
        correct_order=[0, 1, 2],
    )
    assert check_challenge_answer(ch, [0, 1, 2])
    assert not check_challenge_answer(ch, [2, 1, 0])


def test_drag_drop_challenge():
    ch = _base_challenge(
        type="drag_drop",
        activity_type="classification",
        category="science",
        question="Sort animals",
        drop_zones=[{"id": "land", "label": "Land", "emoji": "🌍"}],
        drop_items=[{"id": "dog", "label": "Dog", "emoji": "🐕"}],
        correct_placements=[{"item_id": "dog", "zone_id": "land"}],
    )
    assert check_challenge_answer(ch, {"dog": "land"})
    assert not check_challenge_answer(ch, {"dog": "water"})


def test_memory_challenge():
    ch = _base_challenge(
        type="memory",
        activity_type="memory_game",
        category="reasoning",
        question="Match pairs",
        memory_pairs=[
            {"id": "p1", "content": "Sun", "emoji": "☀️"},
            {"id": "p2", "content": "Moon", "emoji": "🌙"},
        ],
    )
    assert check_challenge_answer(ch, {"matched_ids": ["p1", "p2"]})
    assert not check_challenge_answer(ch, {"matched_ids": ["p1"]})


def test_fill_blank_multi():
    ch = _base_challenge(
        type="fill_blank",
        activity_type="spelling",
        category="language",
        question="Fill blanks",
        blanks=[
            {"id": "b1", "answer": "cat", "acceptable_answers": ["Cat"]},
            {"id": "b2", "answer": "dog", "acceptable_answers": []},
        ],
    )
    assert check_challenge_answer(ch, {"b1": "cat", "b2": "dog"})
    assert check_challenge_answer(ch, {"b1": "Cat", "b2": "dog"})
    assert not check_challenge_answer(ch, {"b1": "cat", "b2": "fish"})


def test_prepare_challenge_strips_answers():
    ch = _base_challenge(
        type="matching",
        activity_type="synonyms",
        category="language",
        question="Match",
        pairs=[{"left": "a", "right": "1"}, {"left": "b", "right": "2"}],
    )
    client = prepare_challenge_for_client(ch, "ch1_s1")
    assert "pairs" not in client
    assert client["match_left"] == ["a", "b"]
    assert set(client["match_right"]) == {"1", "2"}
