"""Tests for curated study video recommendations."""

import os

os.environ.setdefault("OPENAI_API_KEY", "test-key-for-pytest")

from study_videos import (
    external_links_allowed,
    lookup_study_videos,
    study_videos_catalog,
)


def test_catalog():
    cat = study_videos_catalog()
    assert cat["video_count"] >= 20
    assert len(cat["trusted_channels"]) >= 5


def test_lookup_fractions():
    result = lookup_study_videos(5, "Mathematics", "Fractions")
    assert result["videos"]
    assert any("fraction" in v["title"].lower() for v in result["videos"])
    assert result["channels"]


def test_lookup_photosynthesis():
    result = lookup_study_videos(6, "Science", "Photosynthesis in plants")
    assert result["videos"]
    assert result["videos"][0]["channel"] in ("SciShow Kids", "Khan Academy", "Peekaboo Kidz", "Learn Bright")


def test_lookup_unknown_topic_still_has_channels():
    result = lookup_study_videos(7, "Science", "xyzzy unknown topic")
    assert result["channels"]
    assert result["note"]


def test_grade_filtering():
    result = lookup_study_videos(10, "Science", "photosynthesis")
    for v in result["videos"]:
        assert v["url"].startswith("https://www.youtube.com/")


def test_external_links_parent_gate():
    assert external_links_allowed(None) is True
    assert external_links_allowed({"content_filters": {"external_links": True}}) is True
    assert external_links_allowed({"content_filters": {"external_links": False}}) is False


def test_study_videos_api():
    import main
    from fastapi.testclient import TestClient

    client = TestClient(main.app)
    res = client.get("/api/study-videos", params={
        "grade": 5,
        "subject": "Science",
        "topic": "Water Cycle",
    })
    assert res.status_code == 200
    data = res.json()
    assert data["videos"]
    assert "links_enabled" in data

    cat = client.get("/api/study-videos/catalog")
    assert cat.status_code == 200
