"""Tests for Finn the Fox AI tutor character."""

from tutor_character import (
    FINN,
    coach_message,
    finn_catalog,
    finn_doubt_prompt,
)


def test_finn_catalog():
    catalog = finn_catalog()
    assert catalog["character"]["id"] == "finn"
    assert catalog["character"]["emoji"] == "🦊"
    assert catalog["teaching_style"] == "socratic"
    assert len(catalog["capabilities"]) >= 8


def test_finn_doubt_prompt_is_socratic():
    prompt = finn_doubt_prompt()
    assert "Finn the Fox" in prompt
    assert "SOCRATIC" in prompt.upper()
    assert "think about this together" in prompt.lower()


def test_coach_hint_does_not_dump_answer():
    msg = coach_message("hint", question="What is 12 ÷ 3?", hint="Think groups of three")
    assert msg["emoji"] == "🦊"
    assert msg["follow_up"]
    assert "12" not in msg["message"] or "groups" in msg["message"].lower()


def test_coach_wrong_encourages_retry():
    msg = coach_message("wrong", attempt=1, question="Name the capital")
    lower = msg["message"].lower()
    assert any(w in lower for w in ("not quite", "try", "close", "mistake", "off"))
    assert msg["coach_type"] == "wrong"


def test_coach_celebrate():
    msg = coach_message("celebrate", child_name="Aarav")
    assert "Aarav" in msg["message"] or "🦊" in msg["message"]
    assert msg["coach_type"] == "celebrate"


def test_coach_quiz_done_tiers():
    high = coach_message("quiz_done", correct=95)
    low = coach_message("quiz_done", correct=40)
    assert high["message"] != low["message"]
