"""Finn the Fox — friendly recurring AI tutor (Socratic, not answer-dispensing)."""

from __future__ import annotations

import random
from typing import Any, Optional

FINN = {
    "id": "finn",
    "name": "Finn",
    "full_name": "Finn the Fox",
    "emoji": "🦊",
    "tagline": "Let's think about this together!",
    "role": "tutor",
}

FINN_CAPABILITIES = [
    {"id": "explain", "label": "Explain concepts", "emoji": "💡"},
    {"id": "hint", "label": "Give hints", "emoji": "🔎"},
    {"id": "ask", "label": "Ask questions", "emoji": "❓"},
    {"id": "encourage", "label": "Encourage", "emoji": "🌟"},
    {"id": "celebrate", "label": "Celebrate success", "emoji": "🎉"},
    {"id": "mistakes", "label": "Explain mistakes kindly", "emoji": "🤗"},
    {"id": "examples", "label": "Give examples", "emoji": "📎"},
    {"id": "jokes", "label": "Tell jokes", "emoji": "😄"},
    {"id": "clues", "label": "Provide clues", "emoji": "🧩"},
    {"id": "reflect", "label": "Ask reflective questions", "emoji": "🪞"},
]

FINN_DOUBT_PROMPT = """You are Finn the Fox 🦊, StorySchool's friendly recurring tutor.

PERSONALITY: Warm, curious, playful — like a clever fox guide who loves puzzles and never rushes.
You speak to children (CBSE grades 5–10) with respect and wonder.

CRITICAL — SOCRATIC TUTORING (do NOT simply give answers):
1. Start by meeting the learner where they are:
   "Hmm… let's think about this together. What do you already know about this?"
2. Ask 1–2 guiding questions before revealing much — help them discover the idea.
3. Offer hints, clues, and small steps — NOT the full solution on the first try.
4. Use relatable examples, analogies, and (occasionally) a gentle fox-themed joke.
5. If they're stuck after trying, give a clearer explanation — but still end with a check question.
6. When they make a mistake, be kind: name what was good in their thinking, then nudge toward the fix.
7. Celebrate curiosity: "Great question!" / "I love how you're thinking!"
8. Keep answers concise (100–250 words) unless they need step-by-step scaffolding.
9. Use Markdown. ASCII diagrams in code blocks when visuals help.
10. If the question is off-topic or inappropriate, gently redirect.
11. Occasionally sign as Finn 🦊 — not every sentence.

NEVER: dump the final answer immediately, lecture like a textbook, or shame the learner."""


FINN_STORY_WORLD_SNIPPET = """
FINN THE FOX (in-world tutor voice for challenges):
- When a scene has a puzzle/challenge, Finn may whisper hints in success_narrative or failure_narrative.
- Hints should be Socratic questions or clues — not the answer.
- Example failure_narrative tone: "Hmm… not quite! What if you tried thinking about it like…?"
- Example success_narrative: "You figured it out! 🦊 What made you choose that?"
"""


def finn_doubt_prompt() -> str:
    return FINN_DOUBT_PROMPT


def finn_catalog() -> dict:
    return {
        "character": FINN,
        "capabilities": FINN_CAPABILITIES,
        "teaching_style": "socratic",
        "sample_openers": [
            "Hmm… let's think about this together. What do you know already?",
            "Ooh, good puzzle! What clue jumps out at you first?",
            "Let's sniff out the answer step by step — what's your first guess?",
        ],
    }


def _pick(pool: list[str]) -> str:
    return random.choice(pool) if pool else ""


def coach_message(
    coach_type: str,
    *,
    topic: str = "",
    subject: str = "",
    question: str = "",
    hint: str = "",
    attempt: int = 1,
    correct: Optional[bool] = None,
    child_name: str = "",
) -> dict[str, Any]:
    """Template-based Finn coaching (fast, consistent, Socratic)."""
    name_bit = f", {child_name}" if child_name else ""
    topic_bit = f" about {topic}" if topic else ""
    q_snip = (question[:80] + "…") if len(question) > 80 else question

    follow_up = ""
    message = ""

    if coach_type == "encourage":
        message = _pick([
            f"Hey{name_bit}! I'm Finn 🦊 — ready to explore{topic_bit} together?",
            f"Hi{name_bit}! Finn here 🦊. Ask me anything — we'll figure it out as a team.",
            f"Welcome back{name_bit}! 🦊 What are you curious about today?",
        ])
        follow_up = _pick([
            "What's one thing you already know about this?",
            "Where should we start — the tricky part or the big picture?",
        ])

    elif coach_type == "hint":
        if hint:
            message = _pick([
                f"Hmm… let's think together 🦊. Here's a clue: {hint}",
                f"Good effort! Sniff this hint: {hint}",
                f"Not giving away the answer yet! 🦊 Try this clue: {hint}",
            ])
        else:
            message = _pick([
                "Hmm… let's think about this together. What do you know already?",
                "What part of the question feels clearest to you? Start there! 🦊",
                "If you had to guess one step, what would it be?",
            ])
        follow_up = _pick([
            "What happens if you try that idea?",
            "Can you explain your thinking out loud?",
            "What would Finn the fox notice first in this puzzle?",
        ])

    elif coach_type == "clue":
        message = _pick([
            "Here's a tiny clue 🦊 — don't peek at the full answer yet!",
            "Let's break it into smaller bites. What's the first piece?",
            "Fox tip: look for a pattern or a word you recognise.",
        ])
        if hint:
            message += f" {hint}"
        follow_up = "What does that clue make you think of?"

    elif coach_type == "wrong":
        if attempt >= 3 and hint:
            message = _pick([
                f"You're getting warmer! 🦊 Let's try another angle. Clue: {hint}",
                f"Brave tries! Here's something that might unlock it: {hint}",
            ])
        else:
            message = _pick([
                "Hmm… not quite — but I like that you're trying! 🦊 What part are you sure about?",
                "Close! Mistakes are how foxes learn to find trails. What would you change?",
                "Good thinking — just a little off. Can you spot which step might need a second look?",
            ])
        follow_up = _pick([
            "What if you approached it from a different angle?",
            "What do you know for certain so far?",
            "Want to try once more with a smaller step?",
        ])

    elif coach_type == "celebrate":
        message = _pick([
            f"Yes! You figured it out! 🦊🎉 Brilliant{name_bit}!",
            f"That's it! Your brain just made a new trail 🦊✨",
            f"Woohoo! 🦊 You didn't just guess — you *thought* it through!",
        ])
        follow_up = _pick([
            "What helped you get there?",
            "Could you teach this trick to a friend?",
            "Ready for the next puzzle?",
        ])

    elif coach_type == "reflect":
        message = _pick([
            "Before we move on — what was the key idea here? 🦊",
            "Nice work! Can you say it in your own words?",
            "Let's lock this in: what's the one thing you'll remember?",
        ])
        follow_up = "How would you use this in a real-life example?"

    elif coach_type == "quiz_wrong":
        message = _pick([
            "That one's tricky! 🦊 Which option felt *almost* right — and why?",
            "Not this time — but your reasoning matters. What made you pick that?",
            "Fox fact: wrong answers teach us where to look next. What clue did we miss?",
        ])
        if question:
            message += f" (Question: \"{q_snip}\")"
        follow_up = "Want to think it through once more before checking the answer?"

    elif coach_type == "quiz_done":
        pct = correct if isinstance(correct, int) else 0
        if pct >= 90:
            message = f"Outstanding{name_bit}! 🦊🎉 You really know this stuff!"
        elif pct >= 60:
            message = f"Solid work{name_bit}! 🦊 A few spots to polish — that's how we grow."
        else:
            message = f"Brave effort{name_bit}! 🦊 Every quiz is practice — let's hunt down those tricky bits."
        follow_up = "Which question would you like to understand better?"

    else:
        message = "Hmm… let's think about this together. What do you know already? 🦊"
        follow_up = "Tell me your first idea!"

    return {
        "speaker": FINN["full_name"],
        "emoji": FINN["emoji"],
        "message": message.strip(),
        "follow_up": follow_up.strip(),
        "coach_type": coach_type,
        "style": "socratic",
    }


def finn_wrapped_response(message: str, follow_up: str = "") -> str:
    """Format a Finn reply for chat display."""
    text = f"**{FINN['emoji']} {FINN['full_name']}:** {message}"
    if follow_up:
        text += f"\n\n*{follow_up}*"
    return text
